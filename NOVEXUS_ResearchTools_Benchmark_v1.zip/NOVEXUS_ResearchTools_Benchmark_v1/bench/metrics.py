"""Metric helpers and the good / medium / low verdict logic."""
from __future__ import annotations

import json
import math
import statistics
from pathlib import Path

THRESHOLDS = json.loads((Path(__file__).resolve().parent / "thresholds.json").read_text())


def rmse(y, p):
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(y, p)) / len(y))


def mae(y, p):
    return sum(abs(a - b) for a, b in zip(y, p)) / len(y)


def r2(y, p):
    m = statistics.fmean(y)
    ss_res = sum((a - b) ** 2 for a, b in zip(y, p))
    ss_tot = sum((a - m) ** 2 for a in y)
    return 1 - ss_res / ss_tot if ss_tot else float("nan")


def pearson(x, y):
    from scipy.stats import pearsonr
    return float(pearsonr(x, y)[0])


def spearman(x, y):
    from scipy.stats import spearmanr
    return float(spearmanr(x, y)[0])


def roc_auc(labels, scores):
    from sklearn.metrics import roc_auc_score
    if len(set(labels)) < 2:
        return float("nan")
    return float(roc_auc_score(labels, scores))


def enrichment_factor(labels, scores, fraction=0.01):
    """EF at the top `fraction` of the ranked list (at least one compound)."""
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    n = max(1, int(round(len(order) * fraction)))
    hits = sum(labels[i] for i in order[:n])
    total = sum(labels)
    return (hits / n) / (total / len(labels)) if total else float("nan")


def bedroc(labels, scores, alpha=20.0):
    """Truchon & Bayly 2007 BEDROC (alpha = 20 -> 80 % weight on the top 8 %)."""
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    N, n = len(labels), sum(labels)
    if n == 0 or n == N:
        return float("nan")
    ranks = [r + 1 for r, i in enumerate(order) if labels[i]]
    s = sum(math.exp(-alpha * r / N) for r in ranks)
    ra = n / N
    ri = (s / n) / ((1 / N) * (1 - math.exp(-alpha)) / (math.exp(alpha / N) - 1))
    factor = ra * math.sinh(alpha / 2) / (math.cosh(alpha / 2) - math.cosh(alpha / 2 - alpha * ra))
    return ri * factor + 1 / (1 - math.exp(alpha * (1 - ra)))


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else float("nan")
    r = tp / (tp + fn) if tp + fn else float("nan")
    f = 2 * p * r / (p + r) if (tp + fp) and (tp + fn) and (p + r) else 0.0
    return p, r, f


def verdict(metric_key: str, value) -> str:
    """Classify a primary metric with thresholds.json: GOOD / MEDIUM / LOW."""
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return "N/A"
    t = THRESHOLDS["metrics"][metric_key]
    if t["direction"] == "higher":
        return "GOOD" if value >= t["good"] else "MEDIUM" if value >= t["medium"] else "LOW"
    return "GOOD" if value <= t["good"] else "MEDIUM" if value <= t["medium"] else "LOW"


def rnd(x, n=4):
    try:
        return round(float(x), n)
    except (TypeError, ValueError):
        return x


# --------------------------------------------------------------------------- intervals
# Metrics that are proportions over `n` independent items, so a Wilson interval applies.
PROPORTION_METRICS = {
    "validity_pass_rate", "robustness_rate", "balanced_accuracy", "group_micro_f1",
    "motif_f1_vs_prosite", "duplicate_pair_f1", "charge_state_accuracy",
    "primer_qc_pass_rate", "pocket_top1_success_dcc4", "interaction_f1_vs_plip",
    "target_top10_hit_rate", "redock_success_rmsd2", "dockq_acceptable_rate",
}
AUC_METRICS = {"class_retrieval_auc"}
RHO_METRICS = {"crispr_spearman"}


def wilson(p, n, z=1.959963985):
    """Wilson score interval for a proportion (Wilson 1927); better than normal
    approximation at small n and near 0 or 1."""
    if not n or p is None or (isinstance(p, float) and math.isnan(p)):
        return None
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(max(0.0, p * (1 - p) / n + z * z / (4 * n * n))) / d
    return (max(0.0, c - h), min(1.0, c + h))


def auc_ci(auc, n, z=1.959963985):
    """Hanley--McNeil standard error, assuming balanced classes as a conservative default."""
    if not n or auc is None or (isinstance(auc, float) and math.isnan(auc)):
        return None
    n1 = n2 = n / 2.0
    q1 = auc / (2 - auc)
    q2 = 2 * auc * auc / (1 + auc)
    var = (auc * (1 - auc) + (n1 - 1) * (q1 - auc ** 2) + (n2 - 1) * (q2 - auc ** 2)) / (n1 * n2)
    se = math.sqrt(max(0.0, var))
    return (max(0.0, auc - z * se), min(1.0, auc + z * se))


def rho_ci(rho, n, z=1.959963985):
    """Fisher z interval for a rank correlation."""
    if not n or n < 4 or rho is None or (isinstance(rho, float) and math.isnan(rho)):
        return None
    if abs(rho) >= 1:
        return (rho, rho)
    zf = 0.5 * math.log((1 + rho) / (1 - rho))
    se = 1.0 / math.sqrt(n - 3)
    lo, hi = zf - z * se, zf + z * se
    t = lambda v: (math.exp(2 * v) - 1) / (math.exp(2 * v) + 1)  # noqa: E731
    return (t(lo), t(hi))


def interval_for(metric, value, n):
    """95 % interval appropriate to the metric, or None when none applies.

    The proportion intervals treat the n reported by each benchmark as independent
    trials. Where a benchmark counts several checks per molecule or per sequence this
    slightly understates the width, which is stated in the paper rather than hidden.
    """
    if metric in PROPORTION_METRICS:
        return wilson(value, n)
    if metric in AUC_METRICS:
        return auc_ci(value, n)
    if metric in RHO_METRICS:
        return rho_ci(value, n)
    return None


# --------------------------------------------------------------------------- bootstrap
def bootstrap_ci(samples, statistic, n_boot=4000, seed=2026, alpha=0.05, stratified=False):
    """Percentile bootstrap over the benchmark's own sampling unit.

    `samples` is a list of per-unit records (one molecule, one sequence pair, one
    template, one query). `statistic` maps a resampled list to the metric. Resampling
    whole units keeps checks that share a unit together, which a Wilson interval over
    raw checks does not.
    """
    import random as _r
    if not samples or len(samples) < 3:
        return None
    rng = _r.Random(seed)
    n = len(samples)
    strata = None
    if stratified:
        # samples are (group, ...) and each group is resampled within itself, so a
        # class with few members cannot vanish from a resample
        strata = {}
        for x in samples:
            strata.setdefault(x[0], []).append(x)
        if len(strata) < 2 or min(len(v) for v in strata.values()) < 3:
            return None
    vals = []
    for _ in range(n_boot):
        if strata:
            draw = [g[rng.randrange(len(g))] for g in strata.values() for _ in range(len(g))]
        else:
            draw = [samples[rng.randrange(n)] for _ in range(n)]
        try:
            v = statistic(draw)
        except Exception:  # noqa: BLE001 - a degenerate resample is simply skipped
            continue
        if v is not None and not (isinstance(v, float) and math.isnan(v)):
            vals.append(v)
    if len(vals) < n_boot // 10:
        return None
    vals.sort()
    lo = vals[int((alpha / 2) * len(vals))]
    hi = vals[min(len(vals) - 1, int((1 - alpha / 2) * len(vals)))]
    return (lo, hi)


# statistic builders for the sampling units the benchmarks expose
def stat_mean(draw):
    return statistics.fmean(draw)


def stat_rate(draw):
    """draw = list of (passed, total) per unit -> pooled pass rate."""
    p = sum(a for a, _ in draw)
    t = sum(b for _, b in draw)
    return p / t if t else None


def stat_microf1(draw):
    """draw = list of (tp, fp, fn) per unit -> pooled micro F1."""
    tp = sum(x[0] for x in draw)
    fp = sum(x[1] for x in draw)
    fn = sum(x[2] for x in draw)
    return prf(tp, fp, fn)[2]


def stat_rmse(draw):
    """draw = list of (observed, predicted)."""
    return math.sqrt(sum((a - b) ** 2 for a, b in draw) / len(draw))


def stat_spearman(draw):
    """draw = list of (x, y)."""
    xs = [a for a, _ in draw]
    ys = [b for _, b in draw]
    if len(set(xs)) < 2 or len(set(ys)) < 2:
        return None
    return spearman(xs, ys)


def stat_balanced(draw):
    """draw = list of (group, correct). Mean of the per-group accuracies, which is what
    balanced accuracy is -- not a single binomial proportion."""
    per = {}
    for g, c in draw:
        a, b = per.get(g, (0, 0))
        per[g] = (a + bool(c), b + 1)
    if len(per) < 2:
        return None
    return statistics.fmean(a / b for a, b in per.values() if b)


STATISTICS = {"mean": stat_mean, "rate": stat_rate, "micro_f1": stat_microf1,
              "rmse": stat_rmse, "spearman": stat_spearman, "balanced": stat_balanced}

"""Sequence-tool benchmarks (13 tools).

Ground truth comes from (i) simulated evolution with a known true alignment, (ii) planted
features with known coordinates, (iii) independent re-implementations written from the
published definitions (PROSITE patterns, REBASE cut sites, Pace extinction coefficients,
Ikai aliphatic index), (iv) independent libraries (pyteomics masses, `peptides`
instability index / Kyte-Doolittle GRAVY, Primer3 thermodynamics), (v) ExPASy ProtParam
literature values, and (vi) measured sgRNA activity (Doench et al. 2016).
"""
from __future__ import annotations

import csv
import math
import random
import re
import statistics
from collections import Counter, defaultdict

from ..engines import call
from ..metrics import prf, rnd, roc_auc, spearman

AA = "ACDEFGHIKLMNPQRSTVWY"
BG = dict(zip(AA, [.074, .025, .054, .054, .047, .074, .026, .068, .058, .099, .025, .045, .039, .034, .052, .057, .051, .073, .013, .032]))
COMP = str.maketrans("ACGTN", "TGCAN")


def rc(s):
    return s.translate(COMP)[::-1]


def rand_protein(rng, n):
    return "".join(rng.choices(AA, weights=[BG[a] for a in AA], k=n))


def rand_dna(rng, n, gc=0.5):
    return "".join(rng.choices("ACGT", weights=[(1 - gc) / 2, gc / 2, gc / 2, (1 - gc) / 2], k=n))


# ExPASy ProtParam literature anchors (mature sequences)
ANCHORS = [
    ("ubiquitin_human", "MQIFVKTLTGKTITLEVEPSDTIENVKAKIQDKEGIPPDQQRLIFAGKQLEDGRTLSDYNIQKESTLHLVLRLRGG", 8564.84, 6.56),
    ("lysozyme_hen_mature", "KVFGRCELAAAMKRHGLDNYRGYSLGNWVCAAKFESNFNTQATNRNTDGSTDYGILQINSRWWCNDGRTPGSRNLCNIPCSALLSSDITASVNCAKKIVSDGNGMNAWVAWRNRCKGTDVQAWIRGCRL", 14313.14, 9.32),
]


def _protein_reference(seq):
    import peptides
    from pyteomics import mass
    p = peptides.Peptide(seq)
    n = len(seq)
    c = Counter(seq)
    return {"mw": mass.calculate_mass(sequence=seq, average=True), "instability": p.instability_index(),
            "gravy": p.hydrophobicity("KyteDoolittle"), "aromaticity": (c["F"] + c["W"] + c["Y"]) / n,
            "aliphatic": 100 * (c["A"] + 2.9 * c["V"] + 3.9 * (c["I"] + c["L"])) / n,
            "ext_reduced": 5500 * c["W"] + 1490 * c["Y"], "ext_cystines": 5500 * c["W"] + 1490 * c["Y"] + 125 * (c["C"] // 2)}


# --------------------------------------------------------------------------- protein descriptors
def t_protein_properties(ctx):
    rng = random.Random(ctx["seed"])
    seqs = [(f"rand{i}", rand_protein(rng, rng.randint(30, 1200))) for i in range(40 if ctx["quick"] else 150)]
    checks = passed = 0
    fails, times = [], []
    for name, s in seqs:
        ok, out, dt = call("protein_properties", {"primary": s}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        ref = _protein_reference(s)
        tests = {"mw(rel<1e-4)": abs(out["molecular_weight_da"] - ref["mw"]) / ref["mw"] < 1e-4,
                 "instability(±0.01)": abs(out["instability_index"] - ref["instability"]) < 0.01,
                 "gravy(±0.001)": abs(out["gravy"] - ref["gravy"]) < 1.5e-3,
                 "aromaticity": abs(out["aromaticity"] - ref["aromaticity"]) < 1e-4, "length": out["length"] == len(s)}
        for k, v in tests.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"{name}: {k}")
    for name, s, mw, pi in ANCHORS:
        ok, out, _ = call("protein_properties", {"primary": s}, ctx["variant"])
        for k, v in {"ExPASy_MW(±1Da)": abs(out["molecular_weight_da"] - mw) <= 1.0, "ExPASy_pI(±0.02)": abs(out["isoelectric_point"] - pi) <= 0.02}.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"{name}: {k}")
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(seqs) + len(ANCHORS),
            "secondary": {"checks": checks}, "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "pyteomics average mass; `peptides` instability index & Kyte-Doolittle GRAVY; ExPASy ProtParam values for ubiquitin and lysozyme."}


def t_protparam(ctx):
    rng = random.Random(ctx["seed"] + 1)
    seqs = [(f"rand{i}", rand_protein(rng, rng.randint(30, 1500))) for i in range(30 if ctx["quick"] else 100)]
    checks = passed = 0
    fails, times = [], []
    for chunk in [seqs[i:i + 10] for i in range(0, len(seqs), 10)]:
        fasta = "".join(f">{n}\n{s}\n" for n, s in chunk)
        ok, out, dt = call("protparam", {"sequences": fasta}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        import json
        res = {r["name"]: r for r in json.loads(out["files"]["protparam.json"])}
        for n, s in chunk:
            r, ref = res[n], _protein_reference(s)
            tests = {"mw": abs(r["mw_da"] - ref["mw"]) / ref["mw"] < 1e-4, "instability": abs(r["instability_index"] - ref["instability"]) < 0.01,
                     "gravy": abs(r["gravy"] - ref["gravy"]) < 1.5e-3, "aliphatic": abs(r["aliphatic_index"] - ref["aliphatic"]) < 0.01,
                     "ext_reduced": r["ext_coeff_reduced"] == ref["ext_reduced"], "ext_cystines": r["ext_coeff_cystines"] == ref["ext_cystines"],
                     "aromaticity": abs(r["aromaticity"] - ref["aromaticity"]) < 1e-3}
            for k, v in tests.items():
                checks += 1
                passed += v
                if not v:
                    fails.append(f"{n}: {k}")
    for name, s, mw, pi in ANCHORS:
        ok, out, _ = call("protparam", {"sequences": f">{name}\n{s}\n"}, ctx["variant"])
        import json
        r = json.loads(out["files"]["protparam.json"])[0]
        for k, v in {"ExPASy_MW": abs(r["mw_da"] - mw) <= 1.0, "ExPASy_pI": abs(r["pi"] - pi) <= 0.02}.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"{name}: {k}")
    # transmembrane-segment detection on synthetic proteins with planted hydrophobic helices
    tp = fp = fn = 0
    for i in range(20):
        polar = "".join(rng.choices("DEKRNQSTGHP", k=400))
        planted = []
        s = list(polar)
        for k in range(rng.randint(1, 4)):
            start = 30 + k * 90 + rng.randint(0, 20)
            helix = "".join(rng.choices("LIVFAMW", weights=[5, 4, 4, 2, 3, 1, 1], k=21))
            s[start:start + 21] = helix
            planted.append((start + 1, start + 21))
        seq = "".join(s)
        ok, out, _ = call("protparam", {"sequences": f">tm{i}\n{seq}\n"}, ctx["variant"])
        import json
        segs = json.loads(out["files"]["protparam.json"])[0]["hydrophobic_segments"]
        pred = [tuple(int(x) for x in g.split("-")) for g in segs]
        hit = set()
        for a, b in planted:
            m = [j for j, (c, d) in enumerate(pred) if min(b, d) - max(a, c) >= 10]
            if m:
                tp += 1
                hit.update(m)
            else:
                fn += 1
        fp += len(pred) - len(hit)
    p, r, f = prf(tp, fp, fn)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(seqs) + len(ANCHORS),
            "secondary": {"checks": checks, "TM_segment_precision": rnd(p, 3), "TM_segment_recall": rnd(r, 3), "TM_segment_F1": rnd(f, 3)},
            "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "pyteomics, `peptides`, Ikai aliphatic index, Pace 1995 extinction coefficients, ExPASy anchors; planted TM helices."}


def t_peptide_profile(ctx):
    import peptides
    from pyteomics import mass
    rng = random.Random(ctx["seed"] + 2)
    checks = passed = 0
    fails, times = [], []
    peps = [rand_protein(rng, rng.randint(5, 60)) for _ in range(150 if not ctx["quick"] else 40)]
    peps += ["".join(rng.choices("LIVFAMW", k=rng.randint(8, 30))) for _ in range(20)]  # strongly hydrophobic
    for s in peps:
        ok, out, dt = call("peptide_profile", {"primary": s}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        gravy = round(float(peptides.Peptide(s).hydrophobicity("KyteDoolittle")), 9)  # avoid 1.0000000000000002 artefacts
        tests = {"liability_flags": [gravy > 1, s.count("C") > 1, ("NG" in s or "DG" in s), "M" in s] ==
                 [any("hydrophobic" in w for w in out["warnings"]), any("cysteines" in w for w in out["warnings"]),
                  any("Asn-Gly" in w for w in out["warnings"]), any("Methionine" in w for w in out["warnings"])],
                 "mass": abs(out["mass_da"] - mass.calculate_mass(sequence=s, average=True)) / out["mass_da"] < 1e-4,
                 "gravy": abs(out["gravy"] - gravy) < 1.5e-3}
        for k, v in tests.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"{s}: {k}")
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(peps),
            "secondary": {"checks": checks}, "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Independent liability rules re-derived from the tool's stated definitions; pyteomics mass; `peptides` GRAVY."}


# --------------------------------------------------------------------------- motifs
def _prosite_reference(s):
    """Explicit position loops (no regex) for the tool's five motif definitions; N-glyc per PROSITE PS00001."""
    hits = set()
    n = len(s)
    for i in range(n):
        if i + 3 < n and s[i] == "N" and s[i + 1] != "P" and s[i + 2] in "ST" and s[i + 3] != "P":
            hits.add(("nglyc", i + 1))
        if i + 3 < n and s[i] in "ST" and s[i + 3] in "DE":
            hits.add(("ck2", i + 1))
        if i + 2 < n and s[i] in "ST" and s[i + 2] in "RK":
            hits.add(("pkc", i + 1))
        if i + 3 < n and s[i] == "Y" and s[i + 3] in "LIVMF":
            hits.add(("yxxphi", i + 1))
        if i + 2 < n and s[i] == "R" and s[i + 2] == "R":
            hits.add(("rxr", i + 1))
    return hits


def _motif_kind(label):
    l = label.lower()
    return "nglyc" if "glyc" in l else "ck2" if "casein" in l else "pkc" if "kinase c" in l else "yxxphi" if "tyrosine" in l else "rxr"


def t_motif_scanner(ctx):
    rng = random.Random(ctx["seed"] + 3)
    tp = fp = fn = 0
    per = defaultdict(lambda: [0, 0, 0])
    fails, times = [], []
    for i in range(60 if not ctx["quick"] else 20):
        s = list(rand_protein(rng, rng.randint(80, 250)))
        for _ in range(4):  # plant edge cases: N-x-S/T followed by P, and motifs at the C-terminus
            p = rng.randint(0, len(s) - 5)
            s[p:p + 4] = list(rng.choice(["NASP", "NGTP", "NKSA", "SAAE", "TRK", "YAAL"]))
        s = "".join(s)
        ok, out, dt = call("motif_scanner", {"primary": s}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        pred = {(_motif_kind(h["motif"]), h["position_1based"]) for h in out["rows"]}
        ref = _prosite_reference(s)
        for k in set(x[0] for x in ref | pred):
            a = {x for x in pred if x[0] == k}
            b = {x for x in ref if x[0] == k}
            per[k][0] += len(a & b)
            per[k][1] += len(a - b)
            per[k][2] += len(b - a)
        tp += len(pred & ref)
        fp += len(pred - ref)
        fn += len(ref - pred)
        for x in list(pred - ref)[:1]:
            fails.append(f"seq{i}: extra {x}")
    p, r, f = prf(tp, fp, fn)
    return {"primary_metric": "motif_f1_vs_prosite", "primary_value": f, "n": tp + fn,
            "secondary": {"precision": rnd(p), "recall": rnd(r), "per_motif_f1": {k: rnd(prf(*v)[2], 3) for k, v in per.items()}},
            "failures": fails[:15], "seconds_per_call": statistics.median(times),
            "reference": "Loop-based matcher of PROSITE PS00001 (N-{P}-[ST]-{P}), PS00006, PS00005 and the tool's YxxΦ / RxR definitions."}


# --------------------------------------------------------------------------- simulated evolution
def _evolve(root, d, rng, alphabet="protein"):
    """Return (descendant, true_pairs). d = fraction of root sites substituted; indel rate = d/10."""
    from Bio.Align import substitution_matrices
    seq = [(c, i) for i, c in enumerate(root)]
    if alphabet == "protein":
        M = substitution_matrices.load("BLOSUM62")
        trans = {a: ([b for b in AA if b != a], [BG[b] * 2 ** (M[a][b] / 2) for b in AA if b != a]) for a in AA}
    for pos in rng.sample(range(len(seq)), int(round(d * len(seq)))):
        c, o = seq[pos]
        if alphabet == "protein":
            seq[pos] = (rng.choices(trans[c][0], weights=trans[c][1])[0], o)
        else:
            seq[pos] = (rng.choice([b for b in "ACGT" if b != c]), o)
    n_events = int(round(len(root) * d / 10))
    for _ in range(n_events):
        L = min(8, 1 + int(rng.expovariate(1 / 1.5)))
        p = rng.randrange(len(seq))
        if rng.random() < 0.5:
            ins = rand_protein(rng, L) if alphabet == "protein" else rand_dna(rng, L)
            seq[p:p] = [(c, None) for c in ins]
        else:
            del seq[p:p + L]
    desc = "".join(c for c, _ in seq)
    pairs = {(o, j) for j, (_, o) in enumerate(seq) if o is not None}
    ident = sum(1 for (o, j) in pairs if root[o] == desc[j]) / max(1, len(pairs))
    return desc, pairs, ident


def _pairs_from_gapped(a, b):
    i = j = 0
    pairs = set()
    for x, y in zip(a, b):
        if x != "-" and y != "-":
            pairs.add((i, j))
        i += x != "-"
        j += y != "-"
    return pairs


def _parse_bio_alignment(text):
    """Parse Biopython's printed pairwise alignment (target/query blocks)."""
    t, q = [], []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[0] == "target":
            t.append(parts[2])
        elif len(parts) >= 3 and parts[0] == "query":
            q.append(parts[2])
    return "".join(t), "".join(q)


def _parse_blocks(text, n1="A", n2="B"):
    a, b = [], []
    for line in text.splitlines():
        if line.startswith(n1 + " "):
            a.append(line[len(n1):].strip())
        elif line.startswith(n2 + " "):
            b.append(line[len(n2):].strip())
    return "".join(a), "".join(b)


LEVELS = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6)


def _alignment_bench(ctx, tool, kind="protein"):
    rng = random.Random(ctx["seed"] + (4 if kind == "protein" else 5))
    reps = 6 if ctx["quick"] else 20
    q_by, idd_by, times = defaultdict(list), defaultdict(list), []
    for d in LEVELS:
        for _ in range(reps):
            root = rand_protein(rng, rng.randint(120, 300)) if kind == "protein" else rand_dna(rng, rng.randint(200, 600))
            desc, true, true_id = _evolve(root, d, rng, kind)
            if tool == "sequence_alignment":
                ok, out, dt = call(tool, {"primary": root, "secondary": desc, "mode": "global"}, ctx["variant"])
                if not ok:
                    return None, out
                a, b = _parse_bio_alignment(out["alignment"])
                idd_by[d].append(abs(out["identity_over_aligned_positions"] - true_id))
            else:
                ok, out, dt = call(tool, {"sequences": f">A\n{root}\n>B\n{desc}\n", "mode": "global"}, ctx["variant"])
                if not ok:
                    return None, out
                a, b = _parse_blocks(out["summary"]["alignment"])
            times.append(dt)
            if a.replace("-", "") != root or b.replace("-", "") != desc:
                return None, "alignment text could not be parsed back to the input sequences"
            pred = _pairs_from_gapped(a, b)
            q_by[d].append(len(pred & true) / len(true))
    return {"q_by": {d: statistics.fmean(v) for d, v in q_by.items()},
            "all_q": [v for vs in q_by.values() for v in vs],
            "id_err": {d: statistics.fmean(v) for d, v in idd_by.items()} if idd_by else None,
            "t": statistics.median(times)}, None


def t_sequence_alignment(ctx):
    res, err = _alignment_bench(ctx, "sequence_alignment", "protein")
    if res is None:
        return {"status": "ERROR", "error": err}
    q = statistics.fmean(res["q_by"].values())
    return {"primary_metric": "alignment_accuracy_q", "primary_value": q, "n": len(LEVELS) * (6 if ctx["quick"] else 20),
            "bootstrap": {"unit": "sequence pairs", "stat": "mean", "samples": res["all_q"]},
            "secondary": {**{f"Q@{int(d * 100)}%subst": rnd(v, 3) for d, v in res["q_by"].items()},
                          **{f"identity_abs_error@{int(d * 100)}%": rnd(v, 3) for d, v in res["id_err"].items()}},
            "seconds_per_call": res["t"],
            "reference": "Simulated protein evolution (BLOSUM62-weighted substitutions, indel rate = divergence/10) with known true alignment; Q = fraction of true residue pairs recovered."}


def t_align(ctx):
    res, err = _alignment_bench(ctx, "align", "protein")
    if res is None:
        return {"status": "ERROR", "error": err}
    dres, derr = _alignment_bench(ctx, "align", "dna")
    q = statistics.fmean(res["q_by"].values())
    sec = {f"protein_Q@{int(d * 100)}%": rnd(v, 3) for d, v in res["q_by"].items()}
    boot = {"unit": "sequence pairs", "stat": "mean", "samples": res["all_q"]}
    if dres:
        sec.update({f"dna_Q@{int(d * 100)}%": rnd(v, 3) for d, v in dres["q_by"].items()})
        sec["dna_mean_Q"] = rnd(statistics.fmean(dres["q_by"].values()), 3)
    import shutil
    sec["msa_mafft"] = "available" if shutil.which("mafft") else "not installed (MSA mode not benchmarked)"
    return {"primary_metric": "alignment_accuracy_q", "primary_value": q, "n": len(LEVELS) * (6 if ctx["quick"] else 20),
            "bootstrap": boot, "secondary": sec, "seconds_per_call": res["t"],
            "reference": "Same simulated-evolution protocol as sequence_alignment; DNA uses Jukes-Cantor substitutions."}


# --------------------------------------------------------------------------- primers
def _primer_qc(f, r, template):
    import primer3
    fails = []
    tf, tr = primer3.calc_tm(f), primer3.calc_tm(r)
    if not (57 <= tf <= 63 and 57 <= tr <= 63):
        fails.append("Tm_outside_57-63")
    if abs(tf - tr) > 3:
        fails.append("dTm>3")
    for p in (f, r):
        gc = (p.count("G") + p.count("C")) / len(p)
        if not 0.35 <= gc <= 0.65:
            fails.append("GC")
            break
    if max(primer3.calc_hairpin(f).tm, primer3.calc_hairpin(r).tm) >= 47:
        fails.append("hairpin_Tm>=47")
    if max(primer3.calc_homodimer(f).tm, primer3.calc_homodimer(r).tm) >= 47:
        fails.append("self_dimer_Tm>=47")
    if primer3.calc_heterodimer(f, r).tm >= 47:
        fails.append("pair_dimer_Tm>=47")
    both = template + "|" + rc(template)
    if both.count(f[-10:]) != 1 or both.count(r[-10:]) != 1:
        fails.append("3prime_10mer_not_unique")
    return fails


def _templates(rng, n):
    out = []
    for i in range(n):
        gc = [0.3, 0.4, 0.45, 0.5, 0.55, 0.6, 0.7][i % 7]
        out.append(rand_dna(rng, rng.randint(300, 1000), gc))
    return out


def t_primer_design(ctx):
    rng = random.Random(ctx["seed"] + 6)
    temps = _templates(rng, 35 if ctx["quick"] else 105)
    pairs = passed = with_pair = coord_err = 0
    reasons, times, per_template = Counter(), [], []
    for t in temps:
        ok, out, dt = call("primer_design", {"primary": t}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        rows = out["rows"]
        with_pair += bool(rows)
        t_pass = 0
        for p in rows:
            pairs += 1
            if t[p["left_0based"]:p["left_0based"] + len(p["forward"])] != p["forward"] or \
               rc(t[p["right_0based"] - len(p["reverse"]) + 1:p["right_0based"] + 1]) != p["reverse"]:
                coord_err += 1
            f = _primer_qc(p["forward"], p["reverse"], t)
            reasons.update(f)
            passed += not f
            t_pass += not f
        per_template.append((t_pass, len(rows)))
    return {"primary_metric": "primer_qc_pass_rate", "primary_value": passed / pairs if pairs else 0.0, "n": pairs,
            "bootstrap": {"unit": "templates", "stat": "rate", "samples": per_template},
            "secondary": {"templates": len(temps), "design_success_rate": rnd(with_pair / len(temps), 3),
                          "coordinate_errors": coord_err, "qc_failure_reasons": dict(reasons)},
            "seconds_per_call": statistics.median(times),
            "reference": "Primer3 thermodynamics (calc_tm/hairpin/dimers, Primer3 default 47 °C limits) and 3′-end uniqueness on both strands; templates GC 30–70 %."}


def t_primer(ctx):
    rng = random.Random(ctx["seed"] + 6)
    temps = _templates(rng, 35 if ctx["quick"] else 105)
    pairs = passed = with_pair = coord_err = 0
    reasons, times, per_template = Counter(), [], []
    for t in temps:
        ok, out, dt = call("primer", {"sequence": t, "num_return": 5}, ctx["variant"])
        times.append(dt)
        if not ok:
            if "no acceptable pair" in str(out):
                continue
            return {"status": "ERROR", "error": out}
        with_pair += 1
        t_pass = t_rows = 0
        for row in out["summary"]["tables"][0]["rows"]:
            f, r, fs, rs = row[1], row[2], int(row[3]), int(row[4])
            pairs += 1
            t_rows += 1
            if t[fs - 1:fs - 1 + len(f)] != f or rc(t[rs - len(r):rs]) != r:
                coord_err += 1
            fl = _primer_qc(f, r, t)
            reasons.update(fl)
            passed += not fl
            t_pass += not fl
        per_template.append((t_pass, t_rows))
    return {"primary_metric": "primer_qc_pass_rate", "primary_value": passed / pairs if pairs else 0.0, "n": pairs,
            "bootstrap": {"unit": "templates", "stat": "rate", "samples": per_template},
            "secondary": {"templates": len(temps), "design_success_rate": rnd(with_pair / len(temps), 3),
                          "coordinate_errors": coord_err, "qc_failure_reasons": dict(reasons)},
            "seconds_per_call": statistics.median(times),
            "reference": "Same QC as primer_design (note: Primer3 is also the design engine, so Tm/dimer checks are partly self-consistent; 3′ uniqueness is independent)."}


# --------------------------------------------------------------------------- DNA utilities
def t_dna_quality(ctx):
    rng = random.Random(ctx["seed"] + 7)
    checks = passed = 0
    fails, times = [], []
    for i in range(100 if not ctx["quick"] else 30):
        s = list(rand_dna(rng, rng.randint(50, 3000), rng.choice([0.3, 0.5, 0.7])))
        for _ in range(rng.randint(0, 3)):
            p = rng.randrange(len(s))
            s[p:p + rng.randint(1, 30)] = rng.choice("ACGTN") * rng.randint(3, 25)
        s = "".join(s)[:3000]
        ok, out, dt = call("dna_quality", {"primary": s}, ctx["variant"])
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        c = Counter(s)
        non_n = len(s) - c["N"]
        gc = round(100 * (c["G"] + c["C"]) / non_n, 2) if non_n else None
        longest = max(len(m.group()) for m in re.finditer(r"A+|C+|G+|T+|N+", s))
        tot = sum(c[b] for b in "ACGT")
        ent = round(-sum(c[b] / tot * math.log2(c[b] / tot) for b in "ACGT" if c[b]), 4) if tot else None
        tests = {"length": out["length_bp"] == len(s), "gc": out["gc_percent_excluding_N"] == gc,
                 "n_pct": out["n_percent"] == round(100 * c["N"] / len(s), 2), "homopolymer": out["longest_homopolymer_run"] == longest,
                 "entropy": out["shannon_entropy_bases_bits"] == ent}
        for k, v in tests.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"seq{i}: {k}")
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": checks // 5,
            "secondary": {"checks": checks}, "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Independent recomputation on random sequences with planted N blocks and homopolymers."}


def _ref_orfs(s, min_aa=10):
    out = set()
    L = len(s)
    for strand, seq in (("+", s), ("-", rc(s))):
        for frame in range(3):
            start = None
            for i in range(frame, L - 2, 3):
                cod = seq[i:i + 3]
                if cod == "ATG" and start is None:
                    start = i
                if cod in ("TAA", "TAG", "TGA"):
                    if start is not None and (i - start) // 3 >= min_aa:
                        out.add((strand, start + 1, i + 3) if strand == "+" else (strand, L - (i + 3) + 1, L - start))
                    start = None
    return out


def t_orf_finder(ctx):
    rng = random.Random(ctx["seed"] + 8)
    checks = passed = 0
    planted_found = planted_total = 0
    fails, times = [], []
    sense = [a + b + c for a in "ACGT" for b in "ACGT" for c in "ACGT" if a + b + c not in ("TAA", "TAG", "TGA")]
    for i in range(80 if not ctx["quick"] else 25):
        s = rand_dna(rng, rng.randint(300, 2500))
        planted = []
        for _ in range(rng.randint(1, 3)):
            gene = "ATG" + "".join(rng.choices(sense, k=rng.randint(60, 200))) + rng.choice(["TAA", "TAG", "TGA"])
            p = rng.randrange(len(s))
            while any(a - 1 < p < b for _, a, b, _ in planted):  # never insert inside an earlier planted gene
                p = rng.randrange(len(s))
            strand = rng.choice("+-")
            s = s[:p] + (gene if strand == "+" else rc(gene)) + s[p:]
            planted = [(st, a + (len(gene) if a > p else 0), b + (len(gene) if a > p else 0), g) for st, a, b, g in planted]
            planted.append((strand, p + 1, p + len(gene), gene))
        s = s[:3000]
        planted = [x for x in planted if x[2] <= len(s)]
        ok, out, dt = call("orf_finder", {"primary": s}, ctx["variant"], tier="PRO")
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        ref = _ref_orfs(s)
        got = {(r["strand"], r["start_1based"], r["end_1based"]) for r in out["rows"]}
        longest_ref = max((b - a for _, a, b in ref), default=None)
        tests = {"total_count": out["total_orfs"] == len(ref), "returned_subset_of_reference": got <= ref,
                 "longest_orf": (max((b - a for _, a, b in got), default=None) == longest_ref)}
        for k, v in tests.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"seq{i}: {k}")
        for st, a, b, g in planted:
            planted_total += 1
            # found if an ORF on the same strand ends at the planted stop (an upstream in-frame ATG may extend it)
            planted_found += any(x[0] == st and ((st == "+" and x[2] == b) or (st == "-" and x[1] == a)) for x in got)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": checks // 3,
            "secondary": {"checks": checks, "planted_gene_recall": rnd(planted_found / max(1, planted_total), 3), "planted_genes": planted_total},
            "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Independent six-frame ORF enumeration (first ATG after a stop → stop, ≥10 aa) + planted genes of 60–200 codons."}


def t_crispr_guide(ctx):
    rng = random.Random(ctx["seed"] + 9)
    checks = passed = 0
    fails, times = [], []
    for i in range(40 if not ctx["quick"] else 15):
        s = rand_dna(rng, rng.randint(100, 2500))
        ok, out, dt = call("crispr_guide", {"primary": s}, ctx["variant"], tier="PRO")
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        ref = 0
        for strand, o in (("+", s), ("-", rc(s))):
            for k in range(20, len(o) - 2):
                if o[k + 1:k + 3] == "GG":
                    g = o[k - 20:k]
                    if 0.3 <= (g.count("G") + g.count("C")) / 20 <= 0.8:
                        ref += 1
        coord_ok = all((s[r["target_start_1based"] - 1:r["target_start_1based"] + 22] if r["strand"] == "+"
                        else rc(s[r["target_start_1based"] - 1:r["target_start_1based"] + 22])) == r["guide_5to3"] + r["pam"]
                       for r in out["rows"])
        for k, v in {"candidate_count": out["all_local_ngg_candidates"] == ref, "coordinates": coord_ok}.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"seq{i}: {k}")
    sec = {"site_enumeration_validity": rnd(passed / checks, 4)}
    path = ctx["data_dir"] / "FC_plus_RES_withPredictions.csv"
    if not path.is_file():
        return {"primary_metric": "crispr_spearman", "primary_value": None, "status": "DATA_MISSING", "secondary": sec,
                "error": "FC_plus_RES_withPredictions.csv missing; run --fetch"}
    rows = list(csv.DictReader(open(path)))
    if ctx["quick"]:
        rows = rows[::5]
    y, yb, tool_s, rs2, filtered = [], [], [], [], 0
    for r in rows:
        m30 = r["30mer"].strip().upper()
        guide, pam = m30[4:24], m30[24:27]
        ok, out, dt = call("crispr_guide", {"primary": m30}, ctx["variant"], tier="PRO")
        cand = [c for c in out["rows"] if c["strand"] == "+" and c["guide_5to3"] == guide and c["pam"] == pam] if ok else []
        if cand:
            c = cand[0]
            score = -(100 * c["polyT_or_repeat_flag"] + abs(c["gc_percent"] - 50))
        else:
            filtered += 1
            score = -1000.0
        y.append(float(r["score_drug_gene_rank"]))
        yb.append(int(float(r["score_drug_gene_threshold"])))
        tool_s.append(score)
        rs2.append(float(r["predictions"]))
    rho = spearman(tool_s, y)
    boot = {"unit": "guides", "stat": "spearman", "samples": list(zip(tool_s, y))}
    sec.update({"n_guides": len(rows), "guides_filtered_by_tool(GC<30/>80%)": filtered,
                "AUC_top20pct_active": rnd(roc_auc(yb, tool_s), 3),
                "RuleSet2_spearman_same_data(in-sample upper reference)": rnd(spearman(rs2, y), 3),
                "RuleSet2_AUC_top20pct": rnd(roc_auc(yb, rs2), 3)})
    return {"primary_metric": "crispr_spearman", "primary_value": rho, "n": len(rows), "secondary": sec,
            "bootstrap": boot,
            "failures": fails[:10], "seconds_per_call": statistics.median(times),
            "reference": "Doench et al. 2016 (Nat Biotechnol) FC+RES sgRNA activity ranks (Azimuth repository); tool's implicit ranking key vs measured activity."}


BLOSUM_SRC = None


def t_variant_compare(ctx):
    from Bio.Align import substitution_matrices
    M = substitution_matrices.load("BLOSUM62")
    rng = random.Random(ctx["seed"] + 10)
    checks = passed = 0
    fails, times = [], []
    for i in range(80 if not ctx["quick"] else 25):
        a = rand_protein(rng, rng.randint(50, 1500))
        b = list(a)
        pos = sorted(rng.sample(range(len(a)), rng.randint(0, min(30, len(a) // 5))))
        for p in pos:
            b[p] = rng.choice([x for x in AA if x != a[p]])
        b = "".join(b)
        ok, out, dt = call("variant_compare", {"primary": a, "secondary": b}, ctx["variant"], tier="PRO")
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        ref = [(p + 1, a[p], b[p], int(M[a[p]][b[p]])) for p in pos]
        got = [(r["position_1based"], r["reference"], r["alternative"], r["blosum62_substitution_score"]) for r in out["rows"]]
        tests = {"substitutions": got == ref, "identity": abs(out["sequence_identity_percent"] - 100 * (len(a) - len(pos)) / len(a)) < 1e-3}
        for k, v in tests.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"pair{i}: {k}")
    bad = call("variant_compare", {"primary": "MKT", "secondary": "MKTA"}, ctx["variant"])[0]
    checks += 1
    passed += not bad
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": checks // 2,
            "secondary": {"checks": checks, "unequal_length_rejected": not bad}, "failures": fails[:20],
            "seconds_per_call": statistics.median(times),
            "reference": "Random proteins with known substitutions; BLOSUM62 (Henikoff 1992) table lookup."}


# REBASE recognition sites and top-strand cut offsets (cut after `k` bases of the site)
REBASE = {"EcoRI": ("GAATTC", 1), "BamHI": ("GGATCC", 1), "HindIII": ("AAGCTT", 1), "XhoI": ("CTCGAG", 1), "PstI": ("CTGCAG", 5),
          "NotI": ("GCGGCCGC", 2), "NheI": ("GCTAGC", 1), "NdeI": ("CATATG", 2), "BglII": ("AGATCT", 1), "NcoI": ("CCATGG", 1),
          "MluI": ("ACGCGT", 1), "SalI": ("GTCGAC", 1), "SpeI": ("ACTAGT", 1), "SacI": ("GAGCTC", 5), "KpnI": ("GGTACC", 5),
          "XbaI": ("TCTAGA", 1), "EcoRV": ("GATATC", 3), "SmaI": ("CCCGGG", 3), "HpaI": ("GTTAAC", 3)}


def _ref_cuts(s, enzyme):
    if enzyme == "BsaI":  # GGTCTC(1/5): non-palindromic, type IIS
        cuts = [m.start() + 6 + 1 + 1 for m in re.finditer("(?=GGTCTC)", s)]
        cuts += [m.start() - 5 + 1 for m in re.finditer("(?=GAGACC)", s)]
        return sorted(c for c in cuts if 1 < c <= len(s))
    site, k = REBASE[enzyme]
    return [m.start() + k + 1 for m in re.finditer(f"(?={site})", s)]


def t_restriction_map(ctx):
    rng = random.Random(ctx["seed"] + 11)
    checks = passed = 0
    fails, times = [], []
    enz_all = list(REBASE) + ["BsaI"]
    for i in range(60 if not ctx["quick"] else 20):
        s = rand_dna(rng, rng.randint(200, 3000))
        for _ in range(rng.randint(3, 12)):
            e = rng.choice(enz_all)
            site = "GGTCTC" if e == "BsaI" else REBASE[e][0]
            if e == "BsaI" and rng.random() < 0.5:
                site = rc(site)
            p = rng.randint(10, len(s) - 20)
            s = s[:p] + site + s[p + len(site):]
        s = s[:3000]
        ok, out, dt = call("restriction_map", {"primary": s}, ctx["variant"], tier="PRO")
        times.append(dt)
        if not ok:
            return {"status": "ERROR", "error": out}
        for r in out["rows"]:
            e = r["enzyme"]
            if e not in enz_all:
                continue
            ref = _ref_cuts(s, e)
            v = r["cut_positions_1based"] == ref[:60] and r["cut_count"] == len(ref)
            checks += 1
            passed += v
            if not v:
                fails.append(f"seq{i} {e}: tool={r['cut_positions_1based'][:5]} ref={ref[:5]}")
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": checks,
            "secondary": {"checks(enzyme×sequence)": checks}, "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Independent site search with REBASE cut offsets (20 enzymes incl. type IIS BsaI on both orientations); planted sites."}


TASKS = {
    "protein_properties": t_protein_properties, "motif_scanner": t_motif_scanner, "sequence_alignment": t_sequence_alignment,
    "peptide_profile": t_peptide_profile, "primer_design": t_primer_design, "dna_quality": t_dna_quality, "orf_finder": t_orf_finder,
    "crispr_guide": t_crispr_guide, "variant_compare": t_variant_compare, "restriction_map": t_restriction_map,
    "protparam": t_protparam, "align": t_align, "primer": t_primer,
}

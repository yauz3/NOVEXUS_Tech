"""Docking and structure-selection benchmarks (evidence tier B).

These need resources the cloud audit environment does not have, so they are written
to run on the deployment machine:

  pocket_p2rank   P2Rank installation + RCSB access
  redock          AutoDock Vina + Meeko + RCSB access
  structselect    RCSB / UniProt access
  pdbquantifier   runs offline from the shipped model and reference set

Ground truth:
  redock        crystallographic pose of the co-crystallised ligand; success = heavy-atom
                symmetry-corrected RMSD <= 2.0 A for the top-scored pose (Kramer 1999)
  pocket_p2rank DCC: distance from predicted pocket centre to ligand centroid, ligand
                removed before prediction (Chen 2011)
  structselect  determinism, and whether rank aggregation reorders a plain
                resolution/R-free ordering at all
  pdbquantifier reproduction of the shipped reference scores, and how much of the
                feature vector is actually present when it scores
"""
from __future__ import annotations

import csv
import json
import math
import shutil
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path

from ..metrics import prf, rnd

# Astex Diverse Set entries (Hartshorn et al. 2007, J Med Chem 50:726) with their
# co-crystallised ligand codes. A 24-entry subset spanning the enzyme classes.
ASTEX = [
    ("1G9V", "RQ3"), ("1GKC", "NFH"), ("1GM8", "SOX"), ("1GPK", "HUP"), ("1HNN", "SKF"),
    ("1HP0", "AD3"), ("1HQ2", "PH2"), ("1HVY", "D16"), ("1HWI", "115"), ("1HWW", "SWA"),
    ("1IA1", "TQ3"), ("1IG3", "VIB"), ("1J3J", "CDK"), ("1JD0", "AZM"), ("1JLA", "TNK"),
    ("1K3U", "navigate"), ("1KE5", "LS1"), ("1KZK", "JE2"), ("1L2S", "STC"), ("1L7F", "BCZ"),
    ("1LPZ", "CMB"), ("1LRH", "NAD"), ("1M2Z", "DEX"), ("1MEH", "MOA"),
]
ASTEX = [(p, l) for p, l in ASTEX if l != "navigate"]  # drop the malformed entry

MAX_RMSD_SUCCESS = 2.0


def _which(name, env_var=None):
    import os
    if env_var and os.environ.get(env_var):
        p = Path(os.environ[env_var])
        if p.is_file():
            return str(p)
    return shutil.which(name)


def _missing(ctx, needs):
    gaps = [n for n, p in needs.items() if not p]
    if gaps:
        return {"status": "DEPENDENCY_MISSING", "primary_value": None,
                "error": "not installed: " + ", ".join(gaps)}
    return None


def _fetch(variant, url, timeout=30):
    from ..engines import opentk_common
    return opentk_common(variant).http_get(url, timeout=timeout)


def _net_ok(variant):
    try:
        _fetch(variant, "https://files.rcsb.org/download/3PTB.pdb", 15)
        return True, None
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:160]


# --------------------------------------------------------------------------- redocking
def _split_complex(pdb_bytes, het, chain=None):
    """Return (receptor_pdb_text, ligand_pdb_text) for the named HET group."""
    rec, lig = [], []
    for line in pdb_bytes.decode("utf-8", "replace").splitlines():
        if line.startswith("ENDMDL"):
            break
        if not line.startswith(("ATOM  ", "HETATM")):
            continue
        if line[16:17] not in (" ", "A"):
            continue
        resn = line[17:20].strip()
        if line.startswith("HETATM") and resn == het and (chain is None or line[21:22] == chain):
            lig.append(line)
        elif line.startswith("ATOM  "):
            rec.append(line)
    return "\n".join(rec), "\n".join(lig)


def _ligand_mol(pdb_text):
    from rdkit import Chem
    m = Chem.MolFromPDBBlock(pdb_text + "\nEND\n", sanitize=False, removeHs=True, proximityBonding=True)
    return m


def _symmetry_rmsd(ref, probe):
    """Heavy-atom RMSD with automorphism correction, no superposition (poses share a frame)."""
    from rdkit import Chem
    import numpy as np
    if ref is None or probe is None:
        return None
    if ref.GetNumAtoms() != probe.GetNumAtoms():
        return None
    R = ref.GetConformer().GetPositions()
    P = probe.GetConformer().GetPositions()
    try:
        matches = probe.GetSubstructMatches(ref, uniquify=False, useChirality=False, maxMatches=2000)
    except Exception:  # noqa: BLE001
        matches = ()
    if not matches:
        matches = (tuple(range(ref.GetNumAtoms())),)
    best = None
    for m in matches:
        d = P[list(m)] - R
        v = float(np.sqrt((d ** 2).sum() / len(m)))
        best = v if best is None or v < best else best
    return best


def _centroid(pdb_text):
    xs = [(float(l[30:38]), float(l[38:46]), float(l[46:54])) for l in pdb_text.splitlines()
          if l.startswith(("ATOM", "HETATM")) and l[76:78].strip().upper() != "H"]
    if not xs:
        return None
    n = len(xs)
    return [sum(p[i] for p in xs) / n for i in range(3)]


def t_redock(ctx):
    """Redock each co-crystallised ligand into its own receptor; success = RMSD <= 2 A."""
    vina = _which("vina", "NVX_VINA")
    gap = _missing(ctx, {"vina (AutoDock Vina)": vina})
    if gap:
        gap["primary_metric"] = "redock_success_rmsd2"
        return gap
    try:
        from meeko import MoleculePreparation, PDBQTWriterLegacy  # noqa: F401
    except ImportError:
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "redock_success_rmsd2",
                "primary_value": None, "error": "meeko not installed (pip install meeko)"}
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": "redock_success_rmsd2",
                "primary_value": None, "error": err}

    from rdkit import Chem
    entries = ASTEX[:6] if ctx["quick"] else ASTEX
    rmsds, rows, times, ok_n, done = [], [], [], 0, 0
    exhaustiveness = int(ctx.get("exhaustiveness", 8))
    for pdb_id, het in entries:
        try:
            raw = _fetch(ctx["variant"], f"https://files.rcsb.org/download/{pdb_id}.pdb")
        except Exception as exc:  # noqa: BLE001
            rows.append([pdb_id, het, "fetch failed", str(exc)[:50], ""])
            continue
        rec_txt, lig_txt = _split_complex(raw, het)
        if not lig_txt or not rec_txt:
            rows.append([pdb_id, het, "ligand or receptor missing", "", ""])
            continue
        ref = _ligand_mol(lig_txt)
        centre = _centroid(lig_txt)
        if ref is None or centre is None:
            rows.append([pdb_id, het, "ligand unreadable", "", ""])
            continue
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            (td / "rec.pdb").write_text(rec_txt + "\nEND\n")
            (td / "lig.pdb").write_text(lig_txt + "\nEND\n")
            try:
                import time as _t
                t0 = _t.perf_counter()
                # receptor and ligand to PDBQT via Meeko / obabel fallback
                if not _prep_pdbqt(td / "rec.pdb", td / "rec.pdbqt", receptor=True):
                    rows.append([pdb_id, het, "receptor prep failed", "", ""])
                    continue
                if not _prep_pdbqt(td / "lig.pdb", td / "lig.pdbqt", receptor=False):
                    rows.append([pdb_id, het, "ligand prep failed", "", ""])
                    continue
                cmd = [vina, "--receptor", str(td / "rec.pdbqt"), "--ligand", str(td / "lig.pdbqt"),
                       "--center_x", f"{centre[0]:.3f}", "--center_y", f"{centre[1]:.3f}",
                       "--center_z", f"{centre[2]:.3f}",
                       "--size_x", "22", "--size_y", "22", "--size_z", "22",
                       "--exhaustiveness", str(exhaustiveness), "--num_modes", "9",
                       "--seed", str(ctx["seed"]), "--out", str(td / "out.pdbqt")]
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
                times.append(_t.perf_counter() - t0)
                if proc.returncode != 0 or not (td / "out.pdbqt").is_file():
                    rows.append([pdb_id, het, "vina failed", proc.stderr.strip()[:60], ""])
                    continue
                pose = _first_pose_mol(td / "out.pdbqt", td)
                rmsd = _symmetry_rmsd(ref, pose)
            except subprocess.TimeoutExpired:
                rows.append([pdb_id, het, "timeout", "", ""])
                continue
            except Exception as exc:  # noqa: BLE001
                rows.append([pdb_id, het, "error", str(exc)[:60], ""])
                continue
        if rmsd is None:
            rows.append([pdb_id, het, "rmsd not computable", "", ""])
            continue
        done += 1
        rmsds.append(rmsd)
        hit = rmsd <= MAX_RMSD_SUCCESS
        ok_n += hit
        rows.append([pdb_id, het, "ok", rnd(rmsd, 2), "yes" if hit else "no"])
    if not done:
        return {"status": "ERROR", "primary_metric": "redock_success_rmsd2", "primary_value": None,
                "error": "no complex could be redocked", "secondary": {"per_entry": rows}}
    return {"primary_metric": "redock_success_rmsd2", "primary_value": ok_n / done, "n": done,
            "secondary": {"success_RMSD<=2A": f"{ok_n}/{done}",
                          "success_RMSD<=1A": sum(1 for r in rmsds if r <= 1.0),
                          "median_RMSD_A": rnd(statistics.median(rmsds), 2),
                          "mean_RMSD_A": rnd(statistics.fmean(rmsds), 2),
                          "exhaustiveness": exhaustiveness,
                          "median_seconds_per_complex": rnd(statistics.median(times), 1) if times else None,
                          "per_entry": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "Astex Diverse Set co-crystallised poses; symmetry-corrected heavy-atom RMSD of the "
                         "top-scored pose, box centred on the crystallographic ligand (redocking protocol)."}


def _prep_pdbqt(src: Path, dst: Path, receptor: bool) -> bool:
    """Meeko for ligands, obabel for receptors; returns True on success."""
    try:
        if receptor:
            ob = shutil.which("obabel")
            if ob:
                r = subprocess.run([ob, str(src), "-O", str(dst), "-xr", "--partialcharge", "gasteiger"],
                                   capture_output=True, text=True, timeout=300)
                return r.returncode == 0 and dst.is_file()
            return False
        from meeko import MoleculePreparation, PDBQTWriterLegacy
        from rdkit import Chem
        m = Chem.MolFromPDBFile(str(src), removeHs=False, sanitize=False)
        if m is None:
            return False
        try:
            Chem.SanitizeMol(m)
        except Exception:  # noqa: BLE001
            pass
        m = Chem.AddHs(m, addCoords=True)
        prep = MoleculePreparation()
        setups = prep.prepare(m)
        text, ok, _ = PDBQTWriterLegacy.write_string(setups[0])
        if not ok:
            return False
        dst.write_text(text)
        return True
    except Exception:  # noqa: BLE001
        return False


def _first_pose_mol(pdbqt: Path, td: Path):
    """Convert the first MODEL of a Vina output PDBQT to an RDKit molecule."""
    from rdkit import Chem
    lines, started = [], False
    for line in pdbqt.read_text().splitlines():
        if line.startswith("MODEL"):
            if started:
                break
            started = True
            continue
        if line.startswith("ENDMDL"):
            break
        if line.startswith(("ATOM", "HETATM")):
            lines.append(line[:66])
    if not lines:
        return None
    p = td / "pose.pdb"
    p.write_text("\n".join(lines) + "\nEND\n")
    return Chem.MolFromPDBFile(str(p), sanitize=False, removeHs=True, proximityBonding=True)


# --------------------------------------------------------------------------- P2Rank pockets
def t_pocket_p2rank(ctx):
    prank = _which("prank", "NVX_P2RANK")
    gap = _missing(ctx, {"prank (P2Rank)": prank})
    if gap:
        gap["primary_metric"] = "pocket_top1_success_dcc4"
        return gap
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": "pocket_top1_success_dcc4",
                "primary_value": None, "error": err}
    entries = ASTEX[:6] if ctx["quick"] else ASTEX
    top1 = top3 = done = 0
    dccs, rows, times = [], [], []
    for pdb_id, het in entries:
        try:
            raw = _fetch(ctx["variant"], f"https://files.rcsb.org/download/{pdb_id}.pdb")
        except Exception as exc:  # noqa: BLE001
            rows.append([pdb_id, "fetch failed", str(exc)[:50], ""])
            continue
        rec_txt, lig_txt = _split_complex(raw, het)
        true_c = _centroid(lig_txt)
        if not true_c:
            rows.append([pdb_id, "ligand missing", het, ""])
            continue
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            (td / "rec.pdb").write_text(rec_txt + "\nEND\n")  # ligand removed before prediction
            import time as _t
            t0 = _t.perf_counter()
            proc = subprocess.run([prank, "predict", "-f", str(td / "rec.pdb"), "-o", str(td / "out")],
                                  capture_output=True, text=True, timeout=900)
            times.append(_t.perf_counter() - t0)
            pred = list((td / "out").glob("*predictions*.csv")) if (td / "out").is_dir() else []
            if proc.returncode != 0 or not pred:
                rows.append([pdb_id, "p2rank failed", proc.stderr.strip()[:60], ""])
                continue
            centres = []
            with open(pred[0]) as fh:
                for r in csv.DictReader(fh):
                    k = {c.strip().lower(): c for c in r}
                    try:
                        centres.append((float(r[k["center_x"]]), float(r[k["center_y"]]), float(r[k["center_z"]])))
                    except (KeyError, ValueError):
                        continue
        if not centres:
            rows.append([pdb_id, "no pocket", "", ""])
            continue
        done += 1
        d1 = math.dist(true_c, centres[0])
        dccs.append(d1)
        best3 = min(math.dist(true_c, c) for c in centres[:3])
        top1 += d1 <= 4.0
        top3 += best3 <= 4.0
        rows.append([pdb_id, "ok", rnd(d1, 2), "yes" if d1 <= 4.0 else "no"])
    if not done:
        return {"status": "ERROR", "primary_metric": "pocket_top1_success_dcc4", "primary_value": None,
                "error": "no structure evaluated", "secondary": {"per_entry": rows}}
    return {"primary_metric": "pocket_top1_success_dcc4", "primary_value": top1 / done, "n": done,
            "secondary": {"top1_DCC<=4A": f"{top1}/{done}", "top3_DCC<=4A": f"{top3}/{done}",
                          "median_DCC_top1_A": rnd(statistics.median(dccs), 2), "per_entry": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "DCC criterion (Chen 2011) on Astex receptors with the ligand removed before prediction."}


# --------------------------------------------------------------------------- PDB-Quantifier
def t_pdbquantifier(ctx):
    """Offline: does the shipped model reproduce its reference scores, and on how much data?"""
    import numpy as np
    import pandas as pd
    root = Path(ctx.get("pdbq_dir") or (ctx["root"].parent / "src" / "ub" / "Novexus_Ubuntu_Full_v0.22"
                                        / "pdbquantifier" / "PDBQuantifier_ML"))
    model_p, ref_p = root / "isolationforest_ads.joblib", root / "test_set_1_scored.csv"
    if not (model_p.is_file() and ref_p.is_file()):
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "validity_pass_rate", "primary_value": None,
                "error": f"model or reference set not found under {root}; pass --pdbq-dir"}
    import joblib
    import warnings
    import sklearn
    PINNED = "1.6.1"  # the version the artifact was serialised with (requirements.txt)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        saved = joblib.load(model_p)
    pipe, cols, q = saved["pipeline"], saved["feature_cols"], saved["train_quantiles"]
    ref = pd.read_csv(ref_p)
    X = ref.reindex(columns=cols)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            s = pipe.decision_function(X)
    except Exception as exc:  # noqa: BLE001 - version-locked artifact
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "validity_pass_rate", "primary_value": None,
                "error": (f"the packaged model is serialised with scikit-learn {PINNED} and does not load under "
                          f"{sklearn.__version__}: {type(exc).__name__}: {exc}. "
                          f"Run this benchmark in a virtualenv with scikit-learn=={PINNED}."),
                "secondary": {"pinned_sklearn": PINNED, "installed_sklearn": sklearn.__version__,
                              "artifact_is_version_locked": True,
                              "note": "A pickled estimator is not portable across scikit-learn versions; "
                                      "the failure is an AttributeError at predict time, not a clear "
                                      "version error."}}
    conf = np.clip((s - q["q05"]) / max(1e-8, q["q95"] - q["q05"]), 0, 1)
    tier = np.where(s < q["q20"], "low", np.where(s < q["q50"], "moderate",
                    np.where(s < q["q80"], "acceptable", "high")))
    low = {c.lower(): c for c in ref.columns}
    checks, passed, fails = 0, 0, []
    conf_diff = tier_agree = None
    if "conformity_score_0_1" in low:
        conf_diff = float(np.nanmax(np.abs(ref[low["conformity_score_0_1"]].values - conf)))
        checks += 1
        passed += conf_diff < 1e-6
        if conf_diff >= 1e-6:
            fails.append(f"conformity score differs by up to {conf_diff:.2e}")
    if "conformity_tier" in low:
        tier_agree = int((ref[low["conformity_tier"]].values == tier).sum())
        checks += 1
        passed += tier_agree == len(ref)
        if tier_agree != len(ref):
            fails.append(f"tier agreement {tier_agree}/{len(ref)}")
    miss = X.isna()
    empty = [c for c in cols if miss[c].all()]
    val_feats = ["r_free", "r_work", "clashscore", "ramachandran_outliers_pct",
                 "rotamer_outliers_pct", "rsrz_outliers_pct", "dcc_r", "dcc_rfree"]
    empty_val = [c for c in val_feats if c in empty]
    summary = {}
    sp = root / "isolationforest_validation_summary.json"
    if sp.is_file():
        js = json.loads(sp.read_text())
        for k in ("test_set_1", "test_set_2"):
            c = (js.get("comparisons_vs_train") or {}).get(k, {})
            if c:
                summary[f"{k}_KS_p_vs_train"] = f"{c.get('ks_pvalue_decision_score'):.2g}"
                summary[f"{k}_conformity_mean_shift"] = rnd(c.get("vs_train_conformity_score_mean_diff"), 3)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks if checks else None,
            "n": len(ref),
            "secondary": {"checks": checks,
                          "max_abs_conformity_difference": f"{conf_diff:.2e}" if conf_diff is not None else None,
                          "tier_agreement": f"{tier_agree}/{len(ref)}" if tier_agree is not None else None,
                          "features_in_model": len(cols),
                          "features_entirely_absent_in_reference_set": len(empty),
                          "crystallographic_validation_features_absent": f"{len(empty_val)}/{len(val_feats)}",
                          "absent_features": empty,
                          "missing_cells_pct": rnd(100 * float(miss.values.mean()), 1),
                          "scored_without_error_despite_missing": True,
                          **summary},
            "failures": fails,
            "reference": "The model's own shipped reference scores (test_set_1_scored.csv) recomputed from the "
                         "packaged pipeline; feature completeness measured on the same rows."}


# --------------------------------------------------------------------------- structure selection
def t_structselect(ctx):
    """Determinism, and whether rank aggregation reorders a plain quality ordering."""
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": "validity_pass_rate",
                "primary_value": None, "error": err}
    sel = ctx.get("structselect_cli")
    if not sel or not Path(sel).is_file():
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "validity_pass_rate", "primary_value": None,
                "error": "pass --structselect-cli /path/to/full_pdbminer_v09.py (needs its own venv)"}
    accs = ["P00533", "P24941"] if ctx["quick"] else ["P00533", "P24941", "P00918", "P68871"]
    same = total = 0
    rows, times = [], []
    for acc in accs:
        outs = []
        for _ in range(2):
            with tempfile.TemporaryDirectory() as td:
                import time as _t
                t0 = _t.perf_counter()
                proc = subprocess.run([sys.executable, str(sel), "--uniprot", acc, "--count", "5",
                                       "--out", str(Path(td) / "r")],
                                      capture_output=True, text=True, timeout=1800, cwd=Path(sel).parent)
                times.append(_t.perf_counter() - t0)
                if proc.returncode != 0:
                    outs.append(None)
                    continue
                csvs = sorted(Path(td).rglob("*.csv"))
                outs.append(csvs[0].read_text() if csvs else None)
        total += 1
        if outs[0] is not None and outs[0] == outs[1]:
            same += 1
            rows.append([acc, "deterministic"])
        else:
            rows.append([acc, "differs between runs" if outs[0] else "run failed"])
    return {"primary_metric": "validity_pass_rate", "primary_value": same / total if total else None, "n": total,
            "secondary": {"deterministic": f"{same}/{total}", "per_accession": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "Two identical runs per UniProt accession; identical ranked output required."}


TASKS = {"redock": t_redock, "pocket_p2rank": t_pocket_p2rank,
         "pdbquantifier": t_pdbquantifier, "structselect": t_structselect}


# --------------------------------------------------------------------------- DockQ
def _kabsch(P, Q):
    """Rotation+translation aligning P onto Q (both N x 3)."""
    import numpy as np
    pc, qc = P.mean(0), Q.mean(0)
    H = (P - pc).T @ (Q - qc)
    U, _, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    D = np.diag([1.0, 1.0, d])
    R = Vt.T @ D @ U.T
    return R, qc - R @ pc


def _ca_map(atoms):
    return {(a["chain"], a["resi"]): a["xyz"] for a in atoms if a["name"] == "CA"}


def _parse_atoms(text):
    out = []
    for l in text.splitlines():
        if l.startswith("ENDMDL"):
            break
        if l.startswith(("ATOM  ", "HETATM")) and l[16:17] in (" ", "A"):
            el = (l[76:78].strip() or l[12:16].strip()[:1]).upper()
            if el == "H":
                continue
            try:
                out.append({"name": l[12:16].strip(), "resn": l[17:20].strip(), "chain": l[21:22],
                            "resi": l[22:27].strip(),
                            "xyz": (float(l[30:38]), float(l[38:46]), float(l[46:54]))})
            except ValueError:
                continue
    return out


def _contacts(a_atoms, b_atoms, cutoff=5.0):
    import numpy as np
    if not a_atoms or not b_atoms:
        return set()
    A = np.array([a["xyz"] for a in a_atoms])
    B = np.array([b["xyz"] for b in b_atoms])
    d = np.linalg.norm(A[:, None, :] - B[None, :, :], axis=-1)
    idx = np.argwhere(d < cutoff)
    return {((a_atoms[i]["chain"], a_atoms[i]["resi"]), (b_atoms[j]["chain"], b_atoms[j]["resi"]))
            for i, j in idx}


def dockq(native_text, model_text, rec_chains, lig_chains):
    """DockQ (Basu & Wallner 2016, PLoS ONE 11:e0161879) with its CAPRI class.

    Returns dict with fnat, lrms, irms, dockq, capri -- or None when the two
    structures cannot be matched residue-for-residue.
    """
    import numpy as np
    nat, mod = _parse_atoms(native_text), _parse_atoms(model_text)
    sel = lambda ats, chs: [a for a in ats if a["chain"] in chs]  # noqa: E731
    nr, nl = sel(nat, rec_chains), sel(nat, lig_chains)
    mr, ml = sel(mod, rec_chains), sel(mod, lig_chains)
    if not (nr and nl and mr and ml):
        return None
    nat_c = _contacts(nr, nl)
    mod_c = _contacts(mr, ml)
    if not nat_c:
        return None
    fnat = len(nat_c & mod_c) / len(nat_c)

    # interface residues from the native, by CA, present in both structures
    iface = {p for pair in nat_c for p in pair}
    nca, mca = _ca_map(nat), _ca_map(mod)
    common_if = [k for k in iface if k in nca and k in mca]
    rec_common = [k for k in (set(nca) & set(mca)) if k[0] in rec_chains]
    lig_common = [k for k in (set(nca) & set(mca)) if k[0] in lig_chains]
    if len(common_if) < 3 or len(rec_common) < 3 or len(lig_common) < 3:
        return None

    # iRMS: superpose on interface CAs, report their RMSD
    P = np.array([mca[k] for k in common_if])
    Q = np.array([nca[k] for k in common_if])
    R, t = _kabsch(P, Q)
    irms = float(np.sqrt((((P @ R.T + t) - Q) ** 2).sum(1).mean()))

    # LRMS: superpose on receptor CAs, report ligand CA RMSD
    Pr = np.array([mca[k] for k in rec_common])
    Qr = np.array([nca[k] for k in rec_common])
    R2, t2 = _kabsch(Pr, Qr)
    Pl = np.array([mca[k] for k in lig_common])
    Ql = np.array([nca[k] for k in lig_common])
    lrms = float(np.sqrt((((Pl @ R2.T + t2) - Ql) ** 2).sum(1).mean()))

    score = (fnat + 1.0 / (1 + (lrms / 8.5) ** 2) + 1.0 / (1 + (irms / 1.5) ** 2)) / 3.0
    capri = ("incorrect" if score < 0.23 else "acceptable" if score < 0.49
             else "medium" if score < 0.80 else "high")
    return {"fnat": round(fnat, 4), "lrms": round(lrms, 2), "irms": round(irms, 2),
            "dockq": round(score, 4), "capri": capri}


# Bound protein--protein and peptide--protein reference complexes (PDB, receptor chains,
# partner chains, class). Short partner chains are the peptide cases.
PP_SET = [
    ("1CGI", "E", "I", "protein-protein"), ("1PPE", "E", "I", "protein-protein"),
    ("2PTC", "E", "I", "protein-protein"), ("1ACB", "E", "I", "protein-protein"),
    ("1AVX", "A", "B", "protein-protein"), ("1AY7", "A", "B", "protein-protein"),
    ("4ZQK", "A", "B", "protein-protein"),
]
PEPTIDE_SET = [
    ("1A1M", "A", "C", "peptide"), ("2V3S", "A", "C", "peptide"),
    ("1ELW", "A", "B", "peptide"), ("1SSH", "A", "B", "peptide"),
]


def _complex_task(ctx, entries, label, metric):
    """Shared driver: the search engine is deployer-supplied, so without it this reports
    DEPENDENCY_MISSING rather than a number."""
    import os
    engine = os.environ.get("NVX_PP_DOCK_BIN")
    if not engine or not Path(engine).is_file():
        return {"status": "DEPENDENCY_MISSING", "primary_metric": metric, "primary_value": None,
                "error": ("the rigid-body docking engine is supplied by the deployer under its own licence; "
                          "set NVX_PP_DOCK_BIN to its executable to run this benchmark"),
                "secondary": {"complexes_defined": len(entries),
                              "protocol": ("bound-form re-docking; top-ranked model scored with DockQ "
                                           "(Fnat, LRMS, iRMS) and assigned a CAPRI class"),
                              "reported": "DockQ, CAPRI class distribution, Top-1 and Top-10 acceptable rate"},
                "reference": "DockQ (Basu & Wallner 2016) against the bound reference complex; "
                             "CAPRI quality classes (Lensink et al.)."}
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": metric, "primary_value": None, "error": err}
    return {"status": "NOT_IMPLEMENTED", "primary_metric": metric, "primary_value": None,
            "error": ("engine found, but the adapter that drives it is deployment-specific and is not part of "
                      "this package; DockQ scoring is implemented and exposed as bench.tasks.dock_tasks.dockq"),
            "secondary": {"complexes_defined": len(entries)}}


def t_dock_pp(ctx):
    return _complex_task(ctx, PP_SET, "protein-protein", "dockq_acceptable_rate")


def t_dock_peptide(ctx):
    return _complex_task(ctx, PEPTIDE_SET, "peptide", "dockq_acceptable_rate")


TASKS["dock_protein_protein"] = t_dock_pp
TASKS["dock_peptide"] = t_dock_peptide

"""Structure- and database-dependent benchmarks (3 tools) plus the cross-cutting robustness suite.

These three tools need outbound HTTPS (RCSB / AlphaFold DB / UniProt / ChEMBL) and, for the
pocket tool, a local fpocket binary. They are therefore skipped with status NETWORK_REQUIRED
when the hosts are unreachable, and report DEPENDENCY_MISSING when fpocket is absent.

Ground truth:
  pocket   -> the crystallographic ligand centroid of a holo structure (DCC criterion, Chen 2011)
  interact -> PLIP 2.x on the same complex (Adasme 2021), an independent interaction engine
  target   -> the known primary target of an approved drug, from its own ChEMBL activity record
"""
from __future__ import annotations

import csv
import io
import json
import math
import shutil
import statistics
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path

from ..engines import call, opentk_common
from ..metrics import prf, rnd

CURATED = Path(__file__).resolve().parent.parent / "curated"

# PDB ID, ligand HET code, chain, protein name. Holo structures with a single clear drug-like ligand.
HOLO = [
    ("1HSG", "MK1", "A", "HIV-1 protease / indinavir"),
    ("3ERT", "OHT", "A", "ERalpha / 4-hydroxytamoxifen"),
    ("1STP", "BTN", "A", "streptavidin / biotin"),
    ("2ITO", "HYZ", "A", "EGFR kinase / erlotinib analogue"),
    ("1OYT", "FSN", "H", "thrombin / inhibitor"),
    ("4COX", "IMN", "A", "COX-2 / indomethacin"),
    ("1UYD", "PU8", "A", "HSP90 / purine inhibitor"),
    ("2WEB", "BGO", "A", "kinase / inhibitor"),
    ("1E66", "HUX", "A", "acetylcholinesterase / huprine"),
    ("3PTB", "BEN", "A", "trypsin / benzamidine"),
]

# Approved drug -> its ChEMBL primary target (for the target-hypothesis hit-rate)
DRUG_TARGETS = [
    ("aspirin", "CC(=O)Oc1ccccc1C(=O)O", ["Cyclooxygenase-1", "Cyclooxygenase-2", "Prostaglandin G/H synthase"]),
    ("imatinib", "Cc1ccc(NC(=O)c2ccc(CN3CCN(C)CC3)cc2)cc1Nc1nccc(-c2cccnc2)n1", ["Tyrosine-protein kinase ABL", "ABL", "Bcr/Abl", "Tyrosine-protein kinase Kit", "Platelet-derived growth factor receptor"]),
    ("atorvastatin", "CC(C)c1c(C(=O)Nc2ccccc2)c(-c2ccccc2)c(-c2ccc(F)cc2)n1CC[C@@H](O)C[C@@H](O)CC(=O)O", ["HMG-CoA reductase", "Hydroxymethylglutaryl-CoA reductase"]),
    ("losartan", "CCCCc1nc(Cl)c(CO)n1Cc1ccc(-c2ccccc2-c2nn[nH]n2)cc1", ["Type-1 angiotensin II receptor", "Angiotensin II type 1"]),
    ("propranolol", "CC(C)NCC(O)COc1cccc2ccccc12", ["Beta-1 adrenergic receptor", "Beta-2 adrenergic receptor", "Beta adrenergic receptor"]),
    ("ciprofloxacin", "OC(=O)c1cn(C2CC2)c2cc(N3CCNCC3)c(F)cc2c1=O", ["DNA gyrase", "DNA topoisomerase", "Topoisomerase IV"]),
    ("diazepam", "CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc21", ["GABA", "GABA-A receptor", "Gamma-aminobutyric acid receptor"]),
    ("sumatriptan", "CNS(=O)(=O)Cc1ccc2[nH]cc(CCN(C)C)c2c1", ["Serotonin 1b", "Serotonin 1d", "5-hydroxytryptamine receptor", "Serotonin"]),
    ("ibuprofen", "CC(C)Cc1ccc(C(C)C(=O)O)cc1", ["Cyclooxygenase-1", "Cyclooxygenase-2", "Prostaglandin G/H synthase"]),
    ("gefitinib", "COc1cc2ncnc(Nc3ccc(F)c(Cl)c3)c2cc1OCCCN1CCOCC1", ["Epidermal growth factor receptor", "EGFR"]),
    ("omeprazole", "CC1=CN=C(CS(=O)c2nc3cc(OC)ccc3[nH]2)C(C)=C1OC", ["Potassium-transporting ATPase", "H+/K+-ATPase", "ATPase"]),
    ("warfarin", "CC(=O)CC(c1ccccc1)c1c(O)c2ccccc2oc1=O", ["Vitamin K epoxide reductase", "VKORC1"]),
]


def _net_ok(variant):
    """One cheap allowlisted request decides whether the network tasks can run."""
    common = opentk_common(variant)
    try:
        common.http_get("https://files.rcsb.org/download/3PTB.pdb", timeout=15)
        return True, None
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:200]


def _fetch_pdb(variant, pdb_id):
    common = opentk_common(variant)
    return common.http_get(f"https://files.rcsb.org/download/{pdb_id}.pdb", timeout=30)


def _ligand_centroid(pdb_bytes, het, chain):
    xs, ys, zs = [], [], []
    for line in pdb_bytes.decode("utf-8", "replace").splitlines():
        if line.startswith("ENDMDL"):
            break
        if line.startswith("HETATM") and line[17:20].strip() == het and line[21:22] == chain \
                and line[16:17] in (" ", "A") and line[76:78].strip().upper() != "H":
            xs.append(float(line[30:38]))
            ys.append(float(line[38:46]))
            zs.append(float(line[46:54]))
    if not xs:
        return None
    return (sum(xs) / len(xs), sum(ys) / len(ys), sum(zs) / len(zs))


def _dist(a, b):
    return math.dist(a, b)


# --------------------------------------------------------------------------- T05 pocket
def t_pocket(ctx):
    if not (shutil.which("fpocket") or (ctx["root"] / "engines" / ctx["variant"] / "opentk" / "bin" / "fpocket").is_file()):
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "pocket_top1_success_dcc4", "primary_value": None,
                "error": "fpocket not installed. Ubuntu: sudo apt install fpocket (or build from github.com/Discngine/fpocket)."}
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": "pocket_top1_success_dcc4", "primary_value": None, "error": err}
    top1 = topn = usable = 0
    dcc1, rows, times = [], [], []
    for pdb_id, het, chain, label in HOLO:
        try:
            raw = _fetch_pdb(ctx["variant"], pdb_id)
        except Exception as exc:  # noqa: BLE001
            rows.append([pdb_id, label, "fetch failed", str(exc)[:60], "", ""])
            continue
        true_c = _ligand_centroid(raw, het, chain)
        if true_c is None:
            rows.append([pdb_id, label, "ligand not found", het, "", ""])
            continue
        # The ligand must not be visible to the pocket finder: strip the HET group before docking-site detection.
        stripped = "\n".join(l for l in raw.decode("utf-8", "replace").splitlines()
                             if not (l.startswith("HETATM") and l[17:20].strip() == het))
        with tempfile.TemporaryDirectory() as td:
            up = Path(td) / "upload.pdb"
            up.write_text(stripped + "\nEND\n")
            ok2, out, dt = call("pocket", {"structure": pdb_id, "chain": chain, "_upload_path": str(up)}, ctx["variant"])
        times.append(dt)
        if not ok2:
            rows.append([pdb_id, label, "tool error", str(out)[:60], "", ""])
            continue
        details = json.loads(out["files"]["pockets.json"])
        centres = [(d["pocket"], d["box_center"]) for d in details if d.get("box_center")]
        if not centres:
            rows.append([pdb_id, label, "no pocket", "", "", ""])
            continue
        usable += 1
        d1 = _dist(true_c, centres[0][1])
        dcc1.append(d1)
        hit1 = d1 <= 4.0
        best = min((_dist(true_c, c) for _, c in centres[:5]), default=1e9)
        top1 += hit1
        topn += best <= 4.0
        rows.append([pdb_id, label, "ok", rnd(d1, 2), "yes" if hit1 else "no", rnd(best, 2)])
    if not usable:
        return {"status": "ERROR", "error": "no structure could be evaluated", "details": rows}
    return {"primary_metric": "pocket_top1_success_dcc4", "primary_value": top1 / usable, "n": usable,
            "secondary": {"top1_success_DCC<=4A": f"{top1}/{usable}", "top5_success_DCC<=4A": f"{topn}/{usable}",
                          "median_DCC_top1_A": rnd(statistics.median(dcc1), 2), "per_structure": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "DCC criterion (Chen et al. 2011): distance from the predicted pocket centre to the crystallographic ligand centroid, ligand removed before prediction."}


# --------------------------------------------------------------------------- T06 interact
PLIP_MAP = {
    "hydrophobic_interaction": "Hydrophobic contact", "hydrogen_bond": "Hydrogen bond", "water_bridge": None,
    "salt_bridge": "Salt bridge", "pi_stack": "pi-stacking", "pi_cation_interaction": "Cation-pi",
    "halogen_bond": "Halogen bond", "metal_complex": "Metal coordination",
}


def _tool_kind(name):
    n = name.lower()
    if n.startswith("hydrogen bond"):
        return "hydrogen_bond"
    if n.startswith("hydrophobic"):
        return "hydrophobic_interaction"
    if n.startswith("salt bridge"):
        return "salt_bridge"
    if "stacking" in n:
        return "pi_stack"
    if "cation" in n:
        return "pi_cation_interaction"
    if n.startswith("halogen"):
        return "halogen_bond"
    if n.startswith("metal"):
        return "metal_complex"
    return None


def _plip_residues(pdb_bytes, het, chain):
    """Run PLIP and return {(kind, 'RESNUM')} for the chosen ligand."""
    from plip.structure.preparation import PDBComplex
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "c.pdb"
        p.write_bytes(pdb_bytes)
        mol = PDBComplex()
        mol.load_pdb(str(p))
        mol.analyze()
    out = set()
    for key, site in mol.interaction_sets.items():
        if not key.startswith(het + ":"):
            continue
        from plip.basic import config  # noqa: F401 - ensures PLIP constants are initialised
        for kind_attr, kind in (("hydrophobic_contacts", "hydrophobic_interaction"), ("hbonds_pdon", "hydrogen_bond"),
                                ("hbonds_ldon", "hydrogen_bond"), ("saltbridge_lneg", "salt_bridge"),
                                ("saltbridge_pneg", "salt_bridge"), ("pistacking", "pi_stack"),
                                ("pication_laro", "pi_cation_interaction"), ("pication_paro", "pi_cation_interaction"),
                                ("halogen_bonds", "halogen_bond"), ("metal_complexes", "metal_complex")):
            for it in getattr(site, kind_attr, []) or []:
                resnr = getattr(it, "resnr", None)
                restype = getattr(it, "restype", "")
                if resnr is not None:
                    out.add((kind, f"{restype}{resnr}"))
    return out


def t_interact(ctx):
    ok, err = _net_ok(ctx["variant"])
    if not ok:
        return {"status": "NETWORK_REQUIRED", "primary_metric": "interaction_f1_vs_plip", "primary_value": None, "error": err}
    try:
        import plip  # noqa: F401
    except ImportError:
        return {"status": "DEPENDENCY_MISSING", "primary_metric": "interaction_f1_vs_plip", "primary_value": None,
                "error": "PLIP not installed. pip install plip openbabel-wheel"}
    tp = fp = fn = 0
    per_kind = defaultdict(lambda: [0, 0, 0])
    rows, times, sites = [], [], []
    for pdb_id, het, chain, label in HOLO:
        try:
            raw = _fetch_pdb(ctx["variant"], pdb_id)
        except Exception as exc:  # noqa: BLE001
            rows.append([pdb_id, label, "fetch failed", str(exc)[:60]])
            continue
        ok2, out, dt = call("interact", {"structure": pdb_id, "ligand": het, "chain": chain}, ctx["variant"])
        times.append(dt)
        if not ok2:
            rows.append([pdb_id, label, "tool error", str(out)[:80]])
            continue
        try:
            ref = _plip_residues(raw, het, chain)
        except Exception as exc:  # noqa: BLE001
            rows.append([pdb_id, label, "PLIP failed", str(exc)[:80]])
            continue
        pred = set()
        for r in csv.DictReader(io.StringIO(out["files"]["interactions.csv"].decode())):
            k = _tool_kind(r["type"])
            if k:
                pred.add((k, r["residue"].split(":")[0]))
        a, b = len(pred & ref), len(pred - ref)
        c = len(ref - pred)
        tp += a
        fp += b
        fn += c
        for k in {x[0] for x in pred | ref}:
            pk = {x for x in pred if x[0] == k}
            rk = {x for x in ref if x[0] == k}
            per_kind[k][0] += len(pk & rk)
            per_kind[k][1] += len(pk - rk)
            per_kind[k][2] += len(rk - pk)
        # binding-site residue agreement (type-agnostic)
        ps, rs = {x[1] for x in pred}, {x[1] for x in ref}
        sites.append(len(ps & rs) / len(ps | rs) if ps | rs else 0.0)
        rows.append([pdb_id, label, f"TP={a} FP={b} FN={c}", f"F1={rnd(prf(a, b, c)[2], 3)}"])
    if tp + fn == 0:
        return {"status": "ERROR", "error": "no complex could be evaluated", "details": rows}
    p, r, f = prf(tp, fp, fn)
    return {"primary_metric": "interaction_f1_vs_plip", "primary_value": f, "n": len(sites),
            "secondary": {"precision": rnd(p, 3), "recall": rnd(r, 3),
                          "binding_site_residue_jaccard": rnd(statistics.fmean(sites), 3) if sites else None,
                          "per_interaction_type_f1": {k: rnd(prf(*v)[2], 3) for k, v in sorted(per_kind.items())},
                          "per_structure": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "PLIP 2.x (Adasme et al. 2021 NAR) on the same complexes, matched at (interaction type, residue) level."}


# --------------------------------------------------------------------------- T09 target
def t_target(ctx):
    common = opentk_common(ctx["variant"])
    try:
        common.http_json("https://www.ebi.ac.uk/chembl/api/data/status.json", timeout=20)
    except Exception as exc:  # noqa: BLE001
        return {"status": "NETWORK_REQUIRED", "primary_metric": "target_top10_hit_rate", "primary_value": None, "error": str(exc)[:200]}
    hit1 = hit10 = done = 0
    ranks, rows, times = [], [], []
    for name, smi, aliases in DRUG_TARGETS:
        ok, out, dt = call("target", {"query": smi, "threshold": 70, "organism": "Homo sapiens"}, ctx["variant"])
        times.append(dt)
        if not ok:
            rows.append([name, "tool error", str(out)[:70], ""])
            continue
        tbl = out["summary"]["tables"][0]["rows"]
        done += 1
        pos = None
        for i, row in enumerate(tbl, start=1):
            tname = str(row[1])
            if any(a.lower() in tname.lower() for a in aliases):
                pos = i
                break
        if pos:
            ranks.append(pos)
            hit1 += pos == 1
            hit10 += pos <= 10
        rows.append([name, f"rank {pos}" if pos else "not found", str(tbl[0][1])[:40] if tbl else "-", len(tbl)])
    if not done:
        return {"status": "ERROR", "error": "no query could be evaluated", "details": rows}
    return {"primary_metric": "target_top10_hit_rate", "primary_value": hit10 / done, "n": done,
            "secondary": {"top1_hit_rate": rnd(hit1 / done, 3), "top10_hits": f"{hit10}/{done}",
                          "median_rank_when_found": statistics.median(ranks) if ranks else None, "per_drug": rows},
            "seconds_per_call": statistics.median(times) if times else None,
            "reference": "Known primary target of 12 approved drugs (ChEMBL target names); the drug itself is present in ChEMBL, so this measures evidence retrieval, not de-novo prediction."}


# --------------------------------------------------------------------------- cross-cutting robustness
MALICIOUS = [
    ("empty", ""),
    ("whitespace", "   \n\t  \n"),
    ("very_long_line", "C" * 5000),
    ("null_bytes", "CCO\x00CCO"),
    ("control_chars", "CCO\x07\x1b[31m"),
    ("unicode", "CCO‮CC\u0000O\U0001f600"),
    ("shell_metachars", "CCO; rm -rf /; $(whoami) `id` | cat"),
    ("path_traversal", "../../../etc/passwd"),
    ("sql_like", "' OR 1=1; DROP TABLE mol;--"),
    ("html_script", "<script>alert(1)</script>"),
    ("python_format", "{__class__.__init__.__globals__}"),
    ("xml_entity", "<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]>&e;"),
    ("many_lines", "\n".join(["CCO"] * 5000)),
    ("deep_nesting", "C" + "(" * 300 + "C" + ")" * 300),
    ("huge_ring_number", "C1" + "2" * 200 + "CC1"),
    ("invalid_smiles", "C(((("),
    ("invalid_aa", "MKTXXXZZZ123"),
    ("invalid_dna", "ACGTRYKMBVDHN"),
    ("fasta_no_seq", ">header only"),
    ("float_overflow", "1e400"),
    ("negative_numbers", "-999999"),
    ("tab_overflow", "a\tb\tc\td\te"),
]

# minimal valid input per tool, used as the baseline and for the formatting-variation checks
VALID = {
    "druglikeness": {"primary": "CCO"}, "structural_alerts": {"primary": "CCO"},
    "chemical_similarity": {"primary": "CCO", "secondary": "CCC"}, "scaffold_analysis": {"primary": "c1ccccc1"},
    "chemical_diversity": {"primary": "CCO\nc1ccccc1"}, "protein_properties": {"primary": "MKTAYIAKQRQ"},
    "motif_scanner": {"primary": "MNGSTRANKTY"}, "sequence_alignment": {"primary": "MKTAYIAKQRQ", "secondary": "MKTAYIAKQRA"},
    "peptide_profile": {"primary": "MKTAYIAKQRQ"}, "primer_design": {"primary": "ATGC" * 50},
    "formula_mass": {"primary": "CCO"}, "functional_groups": {"primary": "CCO"}, "esol_estimator": {"primary": "CCO"},
    "ligand_efficiency": {"primary": "CCO\t7.5"}, "compound_cleanup": {"primary": "CCO"},
    "dna_quality": {"primary": "ACGT" * 20}, "orf_finder": {"primary": "ATG" + "AAA" * 20 + "TAA"},
    "crispr_guide": {"primary": "ACGT" * 20}, "variant_compare": {"primary": "MKTAYIAKQRQ", "secondary": "MKTAYIAKQRA"},
    "restriction_map": {"primary": "GAATTC" + "ACGT" * 20},
    "admet": {"molecules": "CCO"}, "similarity": {"library": "CCO\nCCC\nCCCC"},
    "chemspace": {"molecules": "CCO\nCCC\nc1ccccc1"}, "ligprep": {"molecules": "CCO", "conformers": 1},
    "protparam": {"sequences": ">a\nMKTAYIAKQRQ\n"}, "align": {"sequences": ">a\nMKTAYIAKQRQ\n>b\nMKTAYIAKQRA\n"},
    "primer": {"sequence": "ATGCTTAGGCATCCGATTACGGCATTAGCCATGGATCCAAGCTTGAATTCACGTGCATGCATTAGCCGGATCATTAGGCCATAGCATCGATCGGATCCATTAGCCATGGCATCGATTACGGCATTAGCCATGGATCCAAGCTTGAATTCACGTGCATGCATTAGCCGGATCATTAGGCCATAGCATCGATCGGATCCATTAGCCATGGCATCGATTACGGCATTAGCCATGGATCCAAGCTTGAATTCACGTGCATGCATTAGCCGGATCATTAGGCCATAGCATCGATCGGATCCATTAGCCATGGCATCGA"}, "pocket": {"structure": "3PTB"}, "interact": {"structure": "3PTB"},
    "target": {"query": "CCO"},
}
FIELDS = {"admet": "molecules", "similarity": "library", "chemspace": "molecules", "ligprep": "molecules",
          "protparam": "sequences", "align": "sequences", "primer": "sequence", "pocket": "structure",
          "interact": "structure", "target": "query"}
OFFLINE = [t for t in VALID if t not in ("pocket", "interact", "target")]


def t_robustness(ctx):
    """Hostile and malformed input must produce a controlled rejection, never a crash."""
    from ..engines import is_user_error
    total = clean = 0
    crashes, times = [], []
    per_tool = {}
    for tool in OFFLINE:
        field = FIELDS.get(tool, "primary")
        t_clean = t_total = 0
        for label, payload in MALICIOUS:
            inputs = dict(VALID[tool])
            inputs[field] = payload
            ok, out, dt = call(tool, inputs, ctx["variant"])
            times.append(dt)
            total += 1
            t_total += 1
            # acceptable: a successful run, or a controlled InputError / ToolError
            good = ok or is_user_error(out)
            clean += good
            t_clean += good
            if not good:
                crashes.append(f"{tool} / {label}: {out}")
        per_tool[tool] = f"{t_clean}/{t_total}"
    return {"primary_metric": "robustness_rate", "primary_value": clean / total, "n": total,
            "secondary": {"inputs_per_tool": len(MALICIOUS), "tools": len(OFFLINE), "uncontrolled_failures": len(crashes),
                          "per_tool": per_tool},
            "failures": crashes[:25], "seconds_per_call": statistics.median(times),
            "reference": f"{len(MALICIOUS)} hostile/malformed inputs per tool (injection strings, control characters, overflow, oversized and malformed payloads)."}


def t_determinism(ctx):
    """Same input twice must give the same answer; input formatting must not change it."""
    import copy
    same = total = 0
    fails, times = [], []
    for tool in OFFLINE:
        inputs = VALID[tool]
        a_ok, a, dt = call(tool, copy.deepcopy(inputs), ctx["variant"])
        b_ok, b, _ = call(tool, copy.deepcopy(inputs), ctx["variant"])
        times.append(dt)
        total += 1
        # identical outcome counts, including two identical controlled rejections
        if a_ok == b_ok and json.dumps(a, sort_keys=True, default=str) == json.dumps(b, sort_keys=True, default=str):
            same += 1
        else:
            fails.append(f"{tool}: repeated call differs")
        # whitespace / line-ending variation must not change the result
        field = FIELDS.get(tool, "primary")
        if isinstance(inputs.get(field), str):
            v = dict(inputs)
            v[field] = "  " + inputs[field].replace("\n", "\r\n") + "  \n"
            c_ok, c, _ = call(tool, v, ctx["variant"])
            total += 1
            if c_ok == a_ok and json.dumps(a, sort_keys=True, default=str) == json.dumps(c, sort_keys=True, default=str):
                same += 1
            else:
                fails.append(f"{tool}: whitespace/CRLF variation changes the result")
    return {"primary_metric": "robustness_rate", "primary_value": same / total, "n": total,
            "secondary": {"checks": total}, "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Repeated identical calls and whitespace/CRLF-padded equivalents of the same input."}


TASKS = {"pocket": t_pocket, "interact": t_interact, "target": t_target,
         "robustness": t_robustness, "determinism": t_determinism}


# --------------------------------------------------------------------------- free-tier parity
# Inputs sized to fit the smallest (FREE) cap of each tiered tool, so the only
# difference between the two runs is the tier itself.
_AA = "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKVKALPDAQFEVVHSLAKWKR"
_DNA = ("ATGGCAGAATTCGATCCGTTAGCCATGGATCCAAGCTTGAATTCACGTGCATGCATTAGCCGGATCATTAGGCCATAG"
        "CATCGATCGGATCCATTAGCCATGGCATCGATTACGGCATTAGCCATGGATCCAAGCTTGCATGCATTAGCCGGATCA"
        "TTAGGCCATAGCATCGATCGGATCCATTAGCCATGGCATCGATTACGGCATTAGCCATGGATCCAAGCTTGAATTCAC"
        "GTGCATGCATTAGCCGGATCATTAGGCCATAGCATCGATCGGATCCATTAGCCATGGCATCGATAG")
_SMI3 = "aspirin\tCC(=O)Oc1ccccc1C(=O)O\nibuprofen\tCC(C)Cc1ccc(C(C)C(=O)O)cc1\ncaffeine\tCn1c(=O)c2c(ncn2C)n(C)c1=O"
_SMI5 = _SMI3 + "\nphenol\tOc1ccccc1\nethanol\tCCO"

TIER_INPUTS = {
    "druglikeness": {"primary": _SMI3},
    "structural_alerts": {"primary": _SMI3},
    "chemical_similarity": {"primary": "CC(=O)Oc1ccccc1C(=O)O", "secondary": _SMI3},
    "scaffold_analysis": {"primary": _SMI3},
    "chemical_diversity": {"primary": _SMI3},
    "protein_properties": {"primary": _AA},
    "motif_scanner": {"primary": _AA[:60]},
    "sequence_alignment": {"primary": _AA[:70], "secondary": _AA[:70].replace("K", "R", 2)},
    "peptide_profile": {"primary": _AA[:55]},
    "primer_design": {"primary": _DNA[:900]},
    "formula_mass": {"primary": _SMI5},
    "functional_groups": {"primary": _SMI5},
    "esol_estimator": {"primary": _SMI5},
    "ligand_efficiency": {"primary": "\n".join(f"{n}\t{s}\t7.5" for n, s in
                                              [("a", "CC(=O)Oc1ccccc1C(=O)O"), ("b", "CCO"), ("c", "Oc1ccccc1")])},
    "compound_cleanup": {"primary": _SMI5},
    "dna_quality": {"primary": _DNA},
    "orf_finder": {"primary": _DNA},
    "crispr_guide": {"primary": _DNA},
    "variant_compare": {"primary": _AA, "secondary": _AA.replace("K", "R", 3)},
    "restriction_map": {"primary": _DNA},
}


def _rowcount(payload):
    if isinstance(payload, dict):
        for k in ("rows", "representative_set"):
            if isinstance(payload.get(k), list):
                return len(payload[k])
    return None


def _prefix_equal(free, pro):
    """True when the FREE result is the PRO result truncated to fewer returned rows."""
    if not (isinstance(free, dict) and isinstance(pro, dict)):
        return False
    nf = _rowcount(free)
    if nf is None:
        return False
    trimmed = dict(pro)
    for k in ("rows", "representative_set"):
        if isinstance(pro.get(k), list):
            trimmed[k] = pro[k][:nf]
    ignore = {"catalogs", "enzyme_count", "notes", "hit_count", "total_orfs",
              "all_local_ngg_candidates", "unique_scaffolds", "molecule_count"}
    a = {k: v for k, v in free.items() if k not in ignore}
    b = {k: v for k, v in trimmed.items() if k not in ignore}
    return json.dumps(a, sort_keys=True, default=str) == json.dumps(b, sort_keys=True, default=str)


def t_tier_parity(ctx):
    """Does the free tier run the same computation as the paid tier?

    Three outcomes per tool: IDENTICAL (byte-identical result), PREFIX (same
    computation, fewer rows returned), NARROWER (free tier evaluates a smaller
    catalogue, so the science itself differs).
    """
    outcome, notes, times = {}, [], []
    for tool, inputs in TIER_INPUTS.items():
        okf, free, dt = call(tool, dict(inputs), ctx["variant"], tier="FREE")
        okp, pro, _ = call(tool, dict(inputs), ctx["variant"], tier="PRO")
        times.append(dt)
        if not (okf and okp):
            outcome[tool] = "ERROR"
            notes.append(f"{tool}: FREE ok={okf} PRO ok={okp} ({free if not okf else pro})")
            continue
        if json.dumps(free, sort_keys=True, default=str) == json.dumps(pro, sort_keys=True, default=str):
            outcome[tool] = "IDENTICAL"
        elif _prefix_equal(free, pro):
            outcome[tool] = "PREFIX"
            notes.append(f"{tool}: free tier returns {_rowcount(free)} of {_rowcount(pro)} rows, values identical")
        else:
            outcome[tool] = "NARROWER"
            if tool == "structural_alerts":
                notes.append(f"free tier screens {len(free.get('catalogs', []))} catalogues, "
                             f"paid tier {len(pro.get('catalogs', []))} (Brenk added)")
            elif tool == "restriction_map":
                notes.append(f"free tier maps {free.get('enzyme_count')} enzymes, paid tier {pro.get('enzyme_count')}")
            else:
                notes.append(f"{tool}: results differ beyond row count")
    same = sum(1 for v in outcome.values() if v in ("IDENTICAL", "PREFIX"))
    counts = {}
    for v in outcome.values():
        counts[v] = counts.get(v, 0) + 1
    return {"primary_metric": "robustness_rate", "primary_value": same / len(outcome), "n": len(outcome),
            "secondary": {**counts, "per_tool": outcome, "input_sizes": "all inputs sized within the free-tier cap"},
            "failures": notes, "seconds_per_call": statistics.median(times),
            "reference": "Same input run at both tiers; the free tier is scientifically equivalent unless it evaluates a narrower catalogue."}


TASKS["tier_parity"] = t_tier_parity

"""Cheminformatics benchmarks (14 tools).

Reference sources are independent of the tool under test wherever possible:
hand-curated literature formulas, textbook functional-group labels, measured solubility
(Delaney 2004), pharmacological class membership, literature pKa values, and
independent re-implementations (element-sum masses, graph-pruning Murcko, sklearn PCA,
RDKit MaxMinPicker).
"""
from __future__ import annotations

import csv
import io
import json
import math
import random
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

from ..engines import call
from ..metrics import bedroc, enrichment_factor, prf, r2, rmse, mae, roc_auc, rnd, spearman

CURATED = Path(__file__).resolve().parent.parent / "curated"

# IUPAC 2013 conventional standard atomic weights and NIST monoisotopic masses (independent of RDKit)
AVG = {"H": 1.008, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998403, "P": 30.973762, "S": 32.06,
       "Cl": 35.45, "Br": 79.904, "I": 126.90447, "Na": 22.98977, "K": 39.0983}
MONO = {"H": 1.00782503207, "C": 12.0, "N": 14.0030740048, "O": 15.99491461956, "F": 18.99840322,
        "P": 30.97376163, "S": 31.97207100, "Cl": 34.96885268, "Br": 78.9183371, "I": 126.904473}


def quiet_rdkit():
    from rdkit import RDLogger
    RDLogger.DisableLog("rdApp.*")


def load_drugs():
    with open(CURATED / "drugs.tsv") as fh:
        return list(csv.DictReader(fh, delimiter="\t"))


def parse_formula(f: str) -> Counter:
    c = Counter()
    for el, n in re.findall(r"([A-Z][a-z]?)(\d*)", f):
        c[el] += int(n) if n else 1
    return c


def batched(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def tsv_lines(rows):
    return "\n".join(f"{r['name']}\t{r['smiles']}" for r in rows)


def _fail(tool, msg):
    return {"status": "ERROR", "error": str(msg)[:300]}


# --------------------------------------------------------------------------- micro24
def _ro5_consistent(r):
    lo = sum([r["mw"] > 500.005, r["logp"] > 5.005, r["hbd"] > 5, r["hba"] > 10])
    hi = sum([r["mw"] >= 499.995, r["logp"] >= 4.995, r["hbd"] > 5, r["hba"] > 10])
    return lo <= r["lipinski_violations"] <= hi


def t_druglikeness(ctx):
    drugs = load_drugs()
    checks = passed = 0
    fails, times = [], []
    rows_all = []
    for chunk in batched(drugs, 80):
        ok, out, dt = call("druglikeness", {"primary": tsv_lines(chunk)}, ctx["variant"])
        times.append(dt)
        if not ok:
            return _fail("druglikeness", out)
        rows_all += out["rows"]
    by_name = {r["name"]: r for r in rows_all}
    for d in drugs:
        r = by_name[d["name"]]
        f = parse_formula(d["formula"])
        ref_mw = sum(AVG[e] * n for e, n in f.items())
        ref_heavy = sum(n for e, n in f.items() if e != "H")
        tests = {
            "mw_vs_formula(<=0.1 Da)": abs(r["mw"] - ref_mw) <= 0.1,
            "heavy_atoms_vs_formula": r["heavy_atoms"] == ref_heavy,
            # values are rounded in the output: a value within rounding distance of a cut-off is accepted either way
            "ro5_violation_logic": _ro5_consistent(r),
            "ro5_pass_logic": r["lipinski_pass"] == (r["lipinski_violations"] <= 1),
            "veber_logic": r["veber_pass"] == (r["rotatable"] <= 10 and r["tpsa"] <= 140),
        }
        for k, v in tests.items():
            checks += 1
            passed += bool(v)
            if not v:
                fails.append(f"{d['name']}: {k}")
    ro5 = statistics.fmean(r["lipinski_pass"] for r in rows_all)
    veber = statistics.fmean(r["veber_pass"] for r in rows_all)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(drugs),
            "secondary": {"checks": checks, "ro5_pass_rate_curated_drugs": rnd(ro5), "veber_pass_rate_curated_drugs": rnd(veber),
                          "mw_mae_vs_formula_da": rnd(mae([by_name[d["name"]]["mw"] for d in drugs],
                                                          [sum(AVG[e] * n for e, n in parse_formula(d["formula"]).items()) for d in drugs]), 4)},
            "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "IUPAC average atomic weights summed over literature molecular formulas; rule logic re-derived."}


def t_structural_alerts(ctx):
    with open(CURATED / "pains_exemplars.tsv") as fh:
        pains = list(csv.DictReader(fh, delimiter="\t"))
    drugs = load_drugs()
    ok, out, dt = call("structural_alerts", {"primary": tsv_lines(pains)}, ctx["variant"], tier="PRO")
    if not ok:
        return _fail("structural_alerts", out)
    # FREE tier = PAINS A/B/C only (the PAINS benchmark); PRO adds Brenk (reported separately)
    tp = fn = 0
    missed = []
    for chunk in batched(pains, 3):
        ok, o, _ = call("structural_alerts", {"primary": tsv_lines(chunk)}, ctx["variant"], tier="FREE")
        for r in o["rows"]:
            if r["hit_count"] > 0:
                tp += 1
            else:
                fn += 1
                missed.append(r["name"])
    fp = tn = 0
    flagged, times = [], []
    for chunk in batched(drugs, 3):
        ok, o, dt = call("structural_alerts", {"primary": tsv_lines(chunk)}, ctx["variant"], tier="FREE")
        times.append(dt)
        for r in o["rows"]:
            if r["hit_count"] > 0:
                fp += 1
                flagged.append(f"{r['name']}: {', '.join(r['alerts'][:2])}")
            else:
                tn += 1
    brenk_flag = 0
    for chunk in batched(drugs, 50):
        ok, o, _ = call("structural_alerts", {"primary": tsv_lines(chunk)}, ctx["variant"], tier="PRO")
        brenk_flag += sum(1 for r in o["rows"] if r["hit_count"] > 0)
    sens = tp / (tp + fn)
    spec = tn / (tn + fp)
    # balanced accuracy averages two per-class rates, so the interval must resample the
    # two classes separately rather than treat all molecules as one binomial sample
    strat = [("pains", 1)] * tp + [("pains", 0)] * fn + [("drug", 1)] * tn + [("drug", 0)] * fp
    return {"primary_metric": "balanced_accuracy", "primary_value": (sens + spec) / 2, "n": len(pains) + len(drugs),
            "bootstrap": {"unit": "molecules within class", "stat": "balanced",
                          "stratified": True, "samples": strat},
            "secondary": {"pains_exemplar_recall": rnd(sens), "approved_drug_specificity": rnd(spec),
                          "approved_drugs_flagged_PAINS": fp, "approved_drugs_flagged_PAINS+Brenk(PRO)": brenk_flag},
            "failures": [f"missed PAINS exemplar: {m}" for m in missed] + [f"drug flagged: {f}" for f in flagged][:20],
            "seconds_per_call": statistics.median(times),
            "reference": "13 textbook PAINS chemotypes (Baell & Holloway 2010 families) vs 57 approved drugs."}


def _class_retrieval(rank_fn, drugs, want_samples=False):
    """Leave-one-out: each drug queries the other 56; actives = same pharmacological class."""
    aucs, efs, beds, p5 = [], [], [], []
    for q in drugs:
        lib = [d for d in drugs if d is not q]
        scores = rank_fn(q, lib)
        if scores is None:
            return None
        labels = [int(d["class"] == q["class"]) for d in lib]
        sc = [scores[d["name"]] for d in lib]
        aucs.append(roc_auc(labels, sc))
        efs.append(enrichment_factor(labels, sc, 0.05))
        beds.append(bedroc(labels, sc, 20.0))
        top = sorted(range(len(sc)), key=lambda i: -sc[i])[:5]
        p5.append(sum(labels[i] for i in top) / 5)
    out = (statistics.fmean(aucs), statistics.fmean(efs), statistics.fmean(beds), statistics.fmean(p5))
    return out + (aucs,) if want_samples else out


def t_chemical_similarity(ctx):
    drugs = load_drugs()
    times = []

    def rank(q, lib):
        ok, out, dt = call("chemical_similarity", {"primary": f"{q['name']}\t{q['smiles']}", "secondary": tsv_lines(lib)}, ctx["variant"])
        times.append(dt)
        if not ok:
            return None
        return {r["name"]: r["morgan_tanimoto"] for r in out["rows"]}

    res = _class_retrieval(rank, drugs, want_samples=True)
    if res is None:
        return _fail("chemical_similarity", "tool call failed")
    auc, ef5, bed, p5, per_query = res
    return {"primary_metric": "class_retrieval_auc", "primary_value": auc, "n": len(drugs),
            "bootstrap": {"unit": "query molecules", "stat": "mean", "samples": per_query},
            "secondary": {"EF5%": rnd(ef5), "BEDROC20": rnd(bed), "precision_at_5": rnd(p5)},
            "seconds_per_call": statistics.median(times),
            "reference": "Leave-one-out retrieval of same-class drugs (11 classes, 57 approved drugs)."}


def _ref_murcko(mol):
    """Independent graph-pruning Bemis-Murcko (RDKit convention: keep exocyclic double-bonded atoms)."""
    from rdkit import Chem
    ri = mol.GetRingInfo()
    if ri.NumRings() == 0:
        return ""
    keep = set(range(mol.GetNumAtoms()))
    changed = True
    while changed:
        changed = False
        for idx in list(keep):
            a = mol.GetAtomWithIdx(idx)
            if ri.NumAtomRings(idx):
                continue
            nb = [n.GetIdx() for n in a.GetNeighbors() if n.GetIdx() in keep]
            if len(nb) <= 1:
                keep.discard(idx)
                changed = True
    core = set(keep)
    for idx in list(core):
        for b in mol.GetAtomWithIdx(idx).GetBonds():
            o = b.GetOtherAtomIdx(idx)
            if o not in core and b.GetBondType() == Chem.BondType.DOUBLE and mol.GetAtomWithIdx(o).GetDegree() == 1:
                keep.add(o)
    removed = set(range(mol.GetNumAtoms())) - keep
    em = Chem.RWMol(mol)
    # atoms that lose a substituent: aromatic N/heteroatoms keep valence via an explicit H
    for idx in keep:
        a = em.GetAtomWithIdx(idx)
        lost = sum(1 for n in mol.GetAtomWithIdx(idx).GetNeighbors() if n.GetIdx() in removed)
        if lost and a.GetIsAromatic() and a.GetSymbol() != "C":
            a.SetNumExplicitHs(a.GetNumExplicitHs() + lost)
        a.SetNoImplicit(False)
    for idx in sorted(removed, reverse=True):
        em.RemoveAtom(idx)
    m2 = em.GetMol()
    try:
        Chem.SanitizeMol(m2)
    except Exception:  # noqa: BLE001 - unresolvable valence: exclude from comparison
        return None
    return Chem.MolToSmiles(m2)


def t_scaffold_analysis(ctx):
    quiet_rdkit()
    from rdkit import Chem
    drugs = load_drugs()
    fg = json.loads((CURATED / "functional_groups.json").read_text())["molecules"]
    mols = [{"name": d["name"], "smiles": d["smiles"]} for d in drugs] + [{"name": m["name"], "smiles": m["smiles"]} for m in fg]
    ok, out, dt = call("scaffold_analysis", {"primary": tsv_lines(mols)}, ctx["variant"])
    if not ok:
        return _fail("scaffold_analysis", out)
    agree = comparable = 0
    fails = []
    for row, m in zip(out["rows"], mols):
        ref = _ref_murcko(Chem.MolFromSmiles(m["smiles"]))
        if ref is None:
            continue
        comparable += 1
        tool = "" if row["murcko_scaffold"].startswith("(acyclic") else row["murcko_scaffold"]
        if tool == ref:
            agree += 1
        else:
            fails.append(f"{m['name']}: tool={tool} ref={ref}")
    ref_unique = len({_ref_murcko(Chem.MolFromSmiles(m["smiles"])) for m in mols})
    return {"primary_metric": "validity_pass_rate", "primary_value": agree / comparable, "n": comparable,
            "secondary": {"unique_scaffolds_tool": out["unique_scaffolds"], "unique_scaffolds_reference": ref_unique},
            "failures": fails[:20], "seconds_per_call": dt,
            "reference": "Independent graph-pruning Bemis-Murcko implementation (ring + linker atoms + exocyclic =X)."}


def t_chemical_diversity(ctx):
    quiet_rdkit()
    from rdkit import Chem, DataStructs
    from rdkit.Chem import rdFingerprintGenerator
    from rdkit.SimDivFilters.rdSimDivPickers import MaxMinPicker
    drugs = load_drugs()
    ok, out, dt = call("chemical_diversity", {"primary": tsv_lines(drugs)}, ctx["variant"])
    if not ok:
        return _fail("chemical_diversity", out)
    gen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=1024)
    fps = [gen.GetFingerprint(Chem.MolFromSmiles(d["smiles"])) for d in drugs]
    idx = {d["name"]: i for i, d in enumerate(drugs)}

    def min_dist(sel):
        return min(1 - DataStructs.TanimotoSimilarity(fps[a], fps[b]) for i, a in enumerate(sel) for b in sel[:i])

    picks = [idx[p["name"]] for p in out["representative_set"]]
    k = len(picks)
    rd = list(MaxMinPicker().LazyBitVectorPick(fps, len(fps), k, firstPicks=[0], seed=42))
    rng = random.Random(ctx["seed"])
    rand = [min_dist(rng.sample(range(len(fps)), k)) for _ in range(500)]
    tool_md, ref_md = min_dist(picks), min_dist(rd)
    # validity of reported pairwise statistics
    allp = [DataStructs.TanimotoSimilarity(fps[i], fps[j]) for i in range(len(fps)) for j in range(i)]
    stats_ok = (abs(out["mean_pairwise_tanimoto"] - statistics.fmean(allp)) < 1e-3 and
                abs(out["min_pairwise_tanimoto"] - min(allp)) < 1e-3 and abs(out["max_pairwise_tanimoto"] - max(allp)) < 1e-3)
    classes = len({drugs[i]["class"] for i in picks})
    return {"primary_metric": "maxmin_ratio", "primary_value": tool_md / ref_md if ref_md else float("nan"), "n": len(drugs),
            "secondary": {"picked": k, "tool_min_pairwise_distance": rnd(tool_md), "rdkit_maxmin_min_distance": rnd(ref_md),
                          "random_subset_min_distance_mean": rnd(statistics.fmean(rand)),
                          "beats_random_percentile": rnd(sum(tool_md > r for r in rand) / len(rand)),
                          "pharmacological_classes_covered": f"{classes}/11", "pairwise_stats_correct": stats_ok},
            "seconds_per_call": dt,
            "reference": "RDKit MaxMinPicker on identical Morgan2/1024 fingerprints; 500 random subsets as baseline."}


# --------------------------------------------------------------------------- micro25
def t_formula_mass(ctx):
    drugs = load_drugs()
    checks = passed = 0
    fails, ppms, times = [], [], []
    for chunk in batched(drugs, 100):
        ok, out, dt = call("formula_mass", {"primary": tsv_lines(chunk)}, ctx["variant"])
        times.append(dt)
        if not ok:
            return _fail("formula_mass", out)
        for d, r in zip(chunk, out["rows"]):
            f = parse_formula(d["formula"])
            mono = sum(MONO[e] * n for e, n in f.items())
            avg = sum(AVG[e] * n for e, n in f.items())
            ppm = abs(r["exact_mass_da"] - mono) / mono * 1e6
            ppms.append(ppm)
            elem_ok = dict(r["element_counts"]) == dict(f)
            tests = {"formula_exact": r["formula"] == d["formula"], "monoisotopic_<1ppm": ppm < 1.0,
                     "average_mass_<0.1Da": abs(r["average_mass_da"] - avg) < 0.1, "element_counts": elem_ok}
            for k, v in tests.items():
                checks += 1
                passed += bool(v)
                if not v:
                    fails.append(f"{d['name']}: {k}")
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(drugs),
            "secondary": {"checks": checks, "max_ppm_error": rnd(max(ppms), 3), "mean_ppm_error": rnd(statistics.fmean(ppms), 4)},
            "failures": fails[:20], "seconds_per_call": statistics.median(times),
            "reference": "Literature molecular formulas; NIST monoisotopic and IUPAC average masses summed independently."}


def t_functional_groups(ctx):
    spec = json.loads((CURATED / "functional_groups.json").read_text())
    mols, kmap, groups = spec["molecules"], spec["tool_key_map"], spec["groups"]
    per = {g: [0, 0, 0] for g in groups}  # tp fp fn
    per_mol = []                           # (tp, fp, fn) per molecule, the bootstrap unit
    fails, times = [], []
    for chunk in batched(mols, 100):
        ok, out, dt = call("functional_groups", {"primary": tsv_lines(chunk)}, ctx["variant"])
        times.append(dt)
        if not ok:
            return _fail("functional_groups", out)
        for m, r in zip(chunk, out["rows"]):
            found = {g for g in groups if any(r["functional_groups"].get(k, 0) > 0 for k in kmap[g])}
            truth = set(m["present"])
            mol_counts = [0, 0, 0]
            for g in groups:
                if g in m["ignore"]:
                    continue
                if g in found and g in truth:
                    per[g][0] += 1
                    mol_counts[0] += 1
                elif g in found:
                    per[g][1] += 1
                    mol_counts[1] += 1
                    fails.append(f"{m['name']}: false {g}")
                elif g in truth:
                    per[g][2] += 1
                    mol_counts[2] += 1
                    fails.append(f"{m['name']}: missed {g}")
            per_mol.append(tuple(mol_counts))
    tp, fp, fn = (sum(v[i] for v in per.values()) for i in range(3))
    p, r, f = prf(tp, fp, fn)
    per_f1 = {g: rnd(prf(*v)[2], 3) for g, v in per.items() if sum(v)}
    return {"primary_metric": "group_micro_f1", "primary_value": f, "n": len(mols),
            "bootstrap": {"unit": "molecules", "stat": "micro_f1", "samples": per_mol},
            "secondary": {"micro_precision": rnd(p), "micro_recall": rnd(r), "per_group_f1": per_f1},
            "failures": fails[:25], "seconds_per_call": statistics.median(times),
            "reference": "35 molecules with hand-curated textbook functional-group labels (20 group types)."}


def t_esol_estimator(ctx):
    path = ctx["data_dir"] / "delaney-processed.csv"
    if not path.is_file():
        return {"status": "DATA_MISSING", "error": f"{path.name} not found; run: python run_benchmark.py --fetch"}
    rows = list(csv.DictReader(open(path)))
    if ctx["quick"]:
        rows = rows[::4]
    y, p, pub, times = [], [], [], []
    for chunk in batched(rows, 80):
        text = "\n".join(f"c{i}\t{r['smiles'].strip()}" for i, r in enumerate(chunk))
        ok, out, dt = call("esol_estimator", {"primary": text}, ctx["variant"])
        times.append(dt)
        if not ok:
            # retry one by one so a single unparsable SMILES does not drop the chunk
            for r in chunk:
                ok1, o1, _ = call("esol_estimator", {"primary": f"x\t{r['smiles'].strip()}"}, ctx["variant"])
                if ok1:
                    y.append(float(r["measured log solubility in mols per litre"]))
                    p.append(o1["rows"][0]["estimated_logS_mol_L"])
                    pub.append(float(r["ESOL predicted log solubility in mols per litre"]))
            continue
        for r, o in zip(chunk, out["rows"]):
            y.append(float(r["measured log solubility in mols per litre"]))
            p.append(o["estimated_logS_mol_L"])
            pub.append(float(r["ESOL predicted log solubility in mols per litre"]))
    return {"primary_metric": "esol_rmse_logS", "primary_value": rmse(y, p), "n": len(y),
            "bootstrap": {"unit": "molecules", "stat": "rmse", "samples": list(zip(y, p))},
            "secondary": {"R2": rnd(r2(y, p)), "MAE": rnd(mae(y, p)), "spearman": rnd(spearman(y, p)),
                          "published_ESOL_RMSE_same_set": rnd(rmse(y, pub)),
                          "agreement_with_published_ESOL_RMSE": rnd(rmse(pub, p)),
                          "within_1_logS": rnd(sum(abs(a - b) <= 1 for a, b in zip(y, p)) / len(y))},
            "seconds_per_call": statistics.median(times),
            "reference": "Delaney 2004 ESOL dataset (MoleculeNet 'delaney-processed', measured logS)."}


def t_ligand_efficiency(ctx):
    quiet_rdkit()
    from rdkit import Chem
    from rdkit.Chem import Crippen
    drugs = load_drugs()
    rng = random.Random(ctx["seed"])
    lines, pk = [], {}
    for d in drugs:
        v = round(rng.uniform(4, 11), 2)
        pk[d["name"]] = v
        lines.append(f"{d['name']}\t{d['smiles']}\t{v}")
    ok, out, dt = call("ligand_efficiency", {"primary": "\n".join(lines[:80])}, ctx["variant"])
    if not ok:
        return _fail("ligand_efficiency", out)
    R, T = 1.98720425864083e-3, 298.15
    checks = passed = 0
    fails = []
    for d, r in zip(drugs, out["rows"]):
        ha = sum(n for e, n in parse_formula(d["formula"]).items() if e != "H")
        le = 2.302585093 * R * T * pk[d["name"]] / ha
        lipe = pk[d["name"]] - Crippen.MolLogP(Chem.MolFromSmiles(d["smiles"]))
        for k, v in {"LE": abs(r["ligand_efficiency_kcal_mol_per_heavy_atom"] - le) < 1e-3,
                     "LipE": abs(r["LipE_pKi_minus_logP"] - lipe) < 2e-3, "heavy_atoms": r["heavy_atoms"] == ha}.items():
            checks += 1
            passed += v
            if not v:
                fails.append(f"{d['name']}: {k}")
    # input validation: pKi outside 0-15 and pIC50-like text must be rejected
    bad = [f"x\tCCO\t16", "x\tCCO\tabc", "x\tCCO\t-1", "CCO"]
    rejected = sum(not call("ligand_efficiency", {"primary": b}, ctx["variant"])[0] for b in bad)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(drugs),
            "secondary": {"checks": checks, "invalid_pKi_rejected": f"{rejected}/{len(bad)}",
                          "constant_used": "2.303·R·T = 1.3643 kcal/mol at 298.15 K"},
            "failures": fails[:20], "seconds_per_call": dt,
            "reference": "LE = 2.303RT·pKi/HA (Hopkins 2004), LipE = pKi − cLogP (Leeson & Springthorpe 2007); HA from literature formula."}


def _variants(smiles, rng):
    """Same-parent variants (should be duplicates) and a stereo-inverted negative control."""
    from rdkit import Chem
    m = Chem.MolFromSmiles(smiles)
    out = [("random_smiles", Chem.MolToSmiles(m, doRandom=True, canonical=False))]
    acid = Chem.MolFromSmarts("[CX3](=O)[OX2H1]")
    amine = Chem.MolFromSmarts("[NX3;H2,H1,H0;!$(N-C=[O,S,N]);!$(N-S(=O)=O);!$(N-a);!$(N=*);!$(N#*);!$([N]-[N,O])]")
    hits = m.GetSubstructMatches(acid)
    if hits:
        rw = Chem.RWMol(m)
        o = rw.GetAtomWithIdx(hits[0][2])
        o.SetFormalCharge(-1)
        o.SetNumExplicitHs(0)
        o.SetNoImplicit(True)
        carbox = Chem.MolToSmiles(rw.GetMol())
        out += [("sodium_salt", carbox + ".[Na+]"), ("potassium_salt", carbox + ".[K+]"), ("carboxylate_anion", carbox)]
    hits = [h for h in m.GetSubstructMatches(amine) if not m.GetAtomWithIdx(h[0]).GetIsAromatic()]
    if hits:
        rw = Chem.RWMol(m)
        n = rw.GetAtomWithIdx(hits[0][0])
        n.SetFormalCharge(1)
        n.SetNumExplicitHs(n.GetTotalNumHs() + 1)
        n.SetNoImplicit(True)
        ammonium = Chem.MolToSmiles(rw.GetMol())
        out += [("hydrochloride", smiles + ".Cl"), ("ammonium_chloride", ammonium + ".[Cl-]"),
                ("mesylate", smiles + ".CS(=O)(=O)O"), ("hydrobromide", smiles + ".Br")]
    neg = None
    centers = [a for a in m.GetAtoms() if a.GetChiralTag() != Chem.ChiralType.CHI_UNSPECIFIED]
    if centers:
        rw = Chem.RWMol(m)
        a = rw.GetAtomWithIdx(centers[0].GetIdx())
        a.InvertChirality()
        neg = Chem.MolToSmiles(rw.GetMol())
        if neg == Chem.MolToSmiles(m):
            neg = None
    return out, neg


def t_compound_cleanup(ctx):
    quiet_rdkit()
    drugs = load_drugs()
    rng = random.Random(ctx["seed"])
    entries = []  # (label_identity, name, smiles)
    for d in drugs:
        entries.append((d["name"], f"{d['name']}__parent", d["smiles"]))
        vs, neg = _variants(d["smiles"], rng)
        for tag, s in vs:
            entries.append((d["name"], f"{d['name']}__{tag}", s))
        if neg:
            entries.append((d["name"] + "__stereoisomer", f"{d['name']}__stereoisomer", neg))
    tp = fp = fn = 0
    fails, times, n_entries = [], [], 0
    by_kind = defaultdict(lambda: [0, 0])
    # keep each drug's family in one call (pairs are evaluated within a call)
    groups = defaultdict(list)
    for e in entries:
        groups[e[0].split("__")[0]].append(e)
    calls, cur = [], []
    for g in groups.values():
        if len(cur) + len(g) > 120:
            calls.append(cur)
            cur = []
        cur += g
    calls.append(cur)
    for chunk in calls:
        text = "\n".join(f"{n}\t{s}" for _, n, s in chunk)
        ok, out, dt = call("compound_cleanup", {"primary": text}, ctx["variant"])
        times.append(dt)
        if not ok:
            return _fail("compound_cleanup", out)
        parent = {r["name"]: r["parent_smiles"] for r in out["rows"]}
        n_entries += len(chunk)
        for i, (ti, ni, _) in enumerate(chunk):
            for tj, nj, _ in chunk[:i]:
                same_truth = ti == tj
                same_pred = parent[ni[:40]] == parent[nj[:40]]
                if same_truth and same_pred:
                    tp += 1
                elif same_pred:
                    fp += 1
                    fails.append(f"false duplicate: {ni} ~ {nj}")
                elif same_truth:
                    fn += 1
                    fails.append(f"missed duplicate: {ni} ~ {nj}")
                if same_truth:
                    kind = (ni if not ni.endswith("__parent") else nj).split("__")[-1]
                    by_kind[kind][0] += same_pred
                    by_kind[kind][1] += 1
    p, r, f = prf(tp, fp, fn)
    return {"primary_metric": "duplicate_pair_f1", "primary_value": f, "n": n_entries,
            "secondary": {"precision": rnd(p), "recall": rnd(r), "true_duplicate_pairs": tp + fn,
                          "recall_by_variant_type": {k: f"{a}/{b}" for k, (a, b) in sorted(by_kind.items())}},
            "failures": fails[:25], "seconds_per_call": statistics.median(times),
            "reference": "57 drugs × generated salt / charge / random-SMILES variants (duplicates) + stereo-inverted controls (non-duplicates)."}


# --------------------------------------------------------------------------- Open Toolkit
def _otk_lines(rows):
    return "\n".join(f"{r['smiles']} {r['name']}" for r in rows)


def t_admet(ctx):
    drugs = load_drugs()
    prof, times = [], []
    for chunk in batched(drugs, 50):  # free-tier limit is 50 molecules per job
        ok, out, dt = call("admet", {"molecules": _otk_lines(chunk)}, ctx["variant"])
        times.append(dt)
        if not ok:
            return _fail("admet", out)
        prof += json.loads(out["files"]["admet_profile.json"])
    dt = statistics.median(times)
    by = {p["name"]: p for p in prof}
    checks = passed = 0
    fails = []
    for d in drugs:
        p = by.get(d["name"])
        if p is None:
            checks += 1
            fails.append(f"{d['name']}: missing")
            continue
        f = parse_formula(d["formula"])
        mw = sum(AVG[e] * n for e, n in f.items())
        atoms_total = sum(f.values())
        r = p["rules"]
        tests = {
            "formula": p["formula"] == d["formula"],
            "mw": abs(p["mw"] - mw) <= 0.1,
            "Ro5": r["Lipinski (Ro5)"] == (sum([p["mw"] > 500, p["logp"] > 5, p["hbd"] > 5, p["hba"] > 10]) <= 1),
            "Veber": r["Veber"] == (p["rotb"] <= 10 and p["tpsa"] <= 140),
            "Egan": r["Egan"] == (p["logp"] <= 5.88 and p["tpsa"] <= 131.6),
            "Ghose": r["Ghose"] == (160 <= p["mw"] <= 480 and -0.4 <= p["logp"] <= 5.6 and 40 <= p["mr"] <= 130 and 20 <= atoms_total <= 70),
            "QED_range": 0 <= p["qed"] <= 1,
            "SA_range": 1 <= p["sa_score"] <= 10,
            "NDI_range": 0 <= p["ndi"] <= 100,
        }
        for k, v in tests.items():
            checks += 1
            passed += bool(v)
            if not v:
                fails.append(f"{d['name']}: {k}")
    sec = {"checks": checks, "mean_QED_drugs": rnd(statistics.fmean(p["qed"] for p in prof), 3),
           "mean_NDI_drugs": rnd(statistics.fmean(p["ndi"] for p in prof), 1),
           "NDI_favourable(>=70)_fraction": rnd(sum(p["ndi"] >= 70 for p in prof) / len(prof), 3)}
    # Proxy discrimination: approved drugs vs Delaney environmental / industrial chemicals
    path = ctx["data_dir"] / "delaney-processed.csv"
    if path.is_file():
        rng = random.Random(ctx["seed"])
        neg = [r["smiles"].strip() for r in csv.DictReader(open(path))]
        neg = rng.sample(neg, 50)
        okn, outn, _ = call("admet", {"molecules": "\n".join(f"{s} chem{i}" for i, s in enumerate(neg))}, ctx["variant"])
        if okn:
            pn = json.loads(outn["files"]["admet_profile.json"])
            lab = [1] * len(prof) + [0] * len(pn)
            sec["AUC_QED_drug_vs_industrial_chem(proxy)"] = rnd(roc_auc(lab, [p["qed"] for p in prof + pn]), 3)
            sec["AUC_NDI_drug_vs_industrial_chem(proxy)"] = rnd(roc_auc(lab, [p["ndi"] for p in prof + pn]), 3)
    return {"primary_metric": "validity_pass_rate", "primary_value": passed / checks, "n": len(drugs),
            "secondary": sec, "failures": fails[:20], "seconds_per_call": dt,
            "reference": "Literature formulas, independent rule re-derivation (Lipinski 1997, Veber 2002, Egan 2000, Ghose 1999)."}


def t_similarity(ctx):
    drugs = load_drugs()
    times = []
    res_by_fp = {}
    for fp in ("morgan2", "featmorgan2", "maccs", "rdkit"):
        def rank(q, lib, fp=fp):
            ok, out, dt = call("similarity", {"query": q["smiles"], "library": _otk_lines(lib), "fingerprint": fp}, ctx["variant"])
            times.append(dt)
            if not ok:
                return None
            rows = list(csv.DictReader(io.StringIO(out["files"]["query_ranking.csv"].decode())))
            return {r["name"]: float(r["tanimoto"]) for r in rows}
        sub = drugs if not ctx["quick"] or fp == "morgan2" else drugs
        res = _class_retrieval(rank, sub, want_samples=True)
        if res is None:
            return _fail("similarity", "tool call failed")
        res_by_fp[fp] = res
    # Butina clustering agreement with pharmacological classes
    from sklearn.metrics import adjusted_rand_score
    ok, out, _ = call("similarity", {"library": _otk_lines(drugs), "fingerprint": "morgan2", "cluster_cutoff": 0.4}, ctx["variant"])
    ari = None
    if ok:
        rows = list(csv.DictReader(io.StringIO(out["files"]["clusters.csv"].decode())))
        cl = {r["name"]: r["cluster"] for r in rows}
        ari = adjusted_rand_score([d["class"] for d in drugs], [cl[d["name"]] for d in drugs])
    auc = res_by_fp["morgan2"][0]
    return {"primary_metric": "class_retrieval_auc", "primary_value": auc, "n": len(drugs),
            "bootstrap": {"unit": "query molecules", "stat": "mean", "samples": res_by_fp["morgan2"][4]},
            "secondary": {**{f"AUC_{k}": rnd(v[0]) for k, v in res_by_fp.items()},
                          **{f"BEDROC20_{k}": rnd(v[2]) for k, v in res_by_fp.items()},
                          "precision_at_5_morgan2": rnd(res_by_fp["morgan2"][3]),
                          "butina(0.4)_ARI_vs_classes": rnd(ari, 3)},
            "seconds_per_call": statistics.median(times),
            "reference": "Leave-one-out same-class retrieval (11 classes, 57 approved drugs); ARI of Butina clusters vs classes."}


def t_chemspace(ctx):
    quiet_rdkit()
    import numpy as np
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    drugs = load_drugs()
    ok, out, dt = call("chemspace", {"molecules": _otk_lines(drugs)}, ctx["variant"])
    if not ok:
        return _fail("chemspace", out)
    rows = list(csv.DictReader(io.StringIO(out["files"]["chemical_space.csv"].decode())))
    desc = ["MW", "WLOGP", "TPSA", "HBD", "HBA", "RotB", "Rings", "AromRings", "Fsp3", "HeavyAtoms"]
    X = np.array([[float(r[k]) for k in desc] for r in rows])
    pca = PCA(n_components=2).fit(StandardScaler().fit_transform(X))
    ref_var = 100 * pca.explained_variance_ratio_.sum()
    tool_var = float(next(h["value"] for h in out["summary"]["headline"] if h["label"].startswith("PC1")).rstrip(" %"))
    ref_scaf = len({Chem.MolToSmiles(MurckoScaffold.GetScaffoldForMol(Chem.MolFromSmiles(d["smiles"]))) for d in drugs})
    tool_scaf = next(h["value"] for h in out["summary"]["headline"] if h["label"] == "Unique scaffolds")
    # PC scores should equal sklearn's up to sign
    t = np.array([[float(r["pc1"]), float(r["pc2"])] for r in rows])
    s = pca.transform(StandardScaler().fit_transform(X))
    corr = [abs(np.corrcoef(t[:, i], s[:, i])[0, 1]) for i in range(2)]
    heavy_ok = all(int(float(r["HeavyAtoms"])) == sum(n for e, n in parse_formula(d["formula"]).items() if e != "H")
                   for r, d in zip(rows, drugs))
    tests = {"pca_variance_within_0.5pct": abs(tool_var - ref_var) < 0.5, "pc1_scores_match": corr[0] > 0.999,
             "pc2_scores_match": corr[1] > 0.999, "scaffold_count": tool_scaf == ref_scaf, "heavy_atoms_vs_formula": heavy_ok}
    return {"primary_metric": "validity_pass_rate", "primary_value": sum(tests.values()) / len(tests), "n": len(drugs),
            "secondary": {**tests, "tool_PC1+2_variance_pct": tool_var, "sklearn_PC1+2_variance_pct": rnd(ref_var, 2)},
            "failures": [k for k, v in tests.items() if not v], "seconds_per_call": dt,
            "reference": "scikit-learn StandardScaler+PCA on the exported descriptor matrix; formula heavy-atom counts."}


def t_ligprep(ctx):
    quiet_rdkit()
    from rdkit import Chem
    with open(CURATED / "protonation_ph74.tsv") as fh:
        ref = list(csv.DictReader(fh, delimiter="\t"))
    correct = done = embedded = stereo_ok = stereo_n = pdbqt = 0
    fails, times = [], []
    for chunk in batched(ref, 10):
        ok, out, dt = call("ligprep", {"molecules": _otk_lines(chunk), "ph": 7.4, "tautomers": 1, "conformers": 3}, ctx["variant"])
        times.append(dt)
        if not ok:
            fails.append(f"chunk failed: {out}")
            continue
        table = out["summary"]["tables"][0]
        rows = {r[0]: r for r in table["rows"]}
        sdf = out["files"].get("all_conformers.sdf", b"").decode()
        mols3d = {}
        for block in sdf.split("$$$$\n"):
            if block.strip():
                m = Chem.MolFromMolBlock(block, removeHs=False)
                if m is not None:
                    nm = m.GetProp("_Name").rsplit("_conf", 1)[0]
                    mols3d.setdefault(nm, m)
        for r in chunk:
            done += 1
            row = rows.get(r["name"])
            if row is None:
                fails.append(f"{r['name']}: not prepared")
                continue
            embedded += 1
            pdbqt += row[7] == "yes"
            if int(row[2]) == int(r["expected_net_charge"]):
                correct += 1
            else:
                fails.append(f"{r['name']}: charge {row[2]} expected {r['expected_net_charge']} ({r['basis']})")
            m_in = Chem.MolFromSmiles(r["smiles"])
            centers_in = Chem.FindMolChiralCenters(m_in, includeUnassigned=False, useLegacyImplementation=False)
            if centers_in and r["name"] in mols3d:
                m3 = mols3d[r["name"]]
                Chem.AssignStereochemistryFrom3D(m3)
                stereo_n += 1
                # compare after neutral standardisation of both (protonation changes the SMILES)
                from rdkit.Chem.MolStandardize import rdMolStandardize
                un = rdMolStandardize.Uncharger()
                a = Chem.MolToSmiles(un.uncharge(Chem.RemoveHs(m3)))
                b = Chem.MolToSmiles(un.uncharge(m_in))
                stereo_ok += a == b
    return {"primary_metric": "charge_state_accuracy", "primary_value": correct / done, "n": done,
            "secondary": {"embedding_success": rnd(embedded / done), "stereo_and_tautomer_retained": f"{stereo_ok}/{stereo_n}",
                          "pdbqt_written": rnd(pdbqt / max(1, embedded))},
            "failures": fails[:25], "seconds_per_call": statistics.median(times),
            "reference": "34 drugs/probes with dominant net charge at pH 7.4 from literature pKa values."}


TASKS = {
    "druglikeness": t_druglikeness, "structural_alerts": t_structural_alerts, "chemical_similarity": t_chemical_similarity,
    "scaffold_analysis": t_scaffold_analysis, "chemical_diversity": t_chemical_diversity, "formula_mass": t_formula_mass,
    "functional_groups": t_functional_groups, "esol_estimator": t_esol_estimator, "ligand_efficiency": t_ligand_efficiency,
    "compound_cleanup": t_compound_cleanup, "admet": t_admet, "similarity": t_similarity, "chemspace": t_chemspace,
    "ligprep": t_ligprep,
}

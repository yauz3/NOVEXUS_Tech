"""Uniform access to the three Novexus engines in two variants (original / fixed).

Every tool is called through ``call(tool_id, inputs, variant)``. The function returns
``(ok, result_or_error, seconds)``. Inputs use the public form fields of each tool, so the
benchmark exercises exactly the code path a website visitor reaches.
"""
from __future__ import annotations

import importlib.util
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENGINES = ROOT / "engines"
VARIANTS = ("original", "fixed")

# tool_id -> (family, engine-internal id)
TOOLS = {
    # micro24 (Source A, v0.24 microtools)
    "druglikeness": ("micro24", "druglikeness"),
    "structural_alerts": ("micro24", "structural_alerts"),
    "chemical_similarity": ("micro24", "chemical_similarity"),
    "scaffold_analysis": ("micro24", "scaffold_analysis"),
    "chemical_diversity": ("micro24", "chemical_diversity"),
    "protein_properties": ("micro24", "protein_properties"),
    "motif_scanner": ("micro24", "motif_scanner"),
    "sequence_alignment": ("micro24", "sequence_alignment"),
    "peptide_profile": ("micro24", "peptide_profile"),
    "primer_design": ("micro24", "primer_design"),
    # micro25 (Source B)
    "formula_mass": ("micro25", "formula_mass"),
    "functional_groups": ("micro25", "functional_groups"),
    "esol_estimator": ("micro25", "esol_estimator"),
    "ligand_efficiency": ("micro25", "ligand_efficiency"),
    "compound_cleanup": ("micro25", "compound_cleanup"),
    "dna_quality": ("micro25", "dna_quality"),
    "orf_finder": ("micro25", "orf_finder"),
    "crispr_guide": ("micro25", "crispr_guide"),
    "variant_compare": ("micro25", "variant_compare"),
    "restriction_map": ("micro25", "restriction_map"),
    # Open Toolkit (Source C)
    "admet": ("opentk", "admet"),
    "similarity": ("opentk", "similarity"),
    "chemspace": ("opentk", "chemspace"),
    "ligprep": ("opentk", "ligprep"),
    "pocket": ("opentk", "pocket"),
    "interact": ("opentk", "interact"),
    "protparam": ("opentk", "protparam"),
    "align": ("opentk", "align"),
    "target": ("opentk", "target"),
    "primer": ("opentk", "primer"),
}

_cache: dict = {}


def _load_micro(variant: str, family: str):
    key = (variant, family)
    if key not in _cache:
        path = ENGINES / variant / family / "engine.py"
        name = f"nvx_{variant}_{family}_engine"
        spec = importlib.util.spec_from_file_location(name, path)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
        _cache[key] = mod
    return _cache[key]


def _load_opentk(variant: str, tool: str):
    """nvx_tools is a package with relative imports; load each variant under its own name."""
    pkg_name = f"nvx_tools_{variant}"
    if pkg_name not in sys.modules:
        pkg_dir = ENGINES / variant / "opentk" / "nvx_tools"
        spec = importlib.util.spec_from_file_location(pkg_name, pkg_dir / "__init__.py",
                                                      submodule_search_locations=[str(pkg_dir)])
        pkg = importlib.util.module_from_spec(spec)
        sys.modules[pkg_name] = pkg
        spec.loader.exec_module(pkg)
    key = (variant, "opentk", tool)
    if key not in _cache:
        _cache[key] = importlib.import_module(f"{pkg_name}.{tool}")
    return _cache[key]


def opentk_module(variant: str, tool: str):
    return _load_opentk(variant, tool)


def opentk_common(variant: str):
    _load_opentk(variant, "admet")
    return importlib.import_module(f"nvx_tools_{variant}.common")


def call(tool_id: str, inputs: dict, variant: str = "original", tier: str = "PRO", **kw):
    """Run one tool. micro tools: inputs = {'primary':..., 'secondary':..., 'mode':...}.
    Open Toolkit tools: inputs = the tool's params dict. Returns (ok, payload, seconds)."""
    family, internal = TOOLS[tool_id]
    t0 = time.perf_counter()
    try:
        if family in ("micro24", "micro25"):
            mod = _load_micro(variant, family)
            out = mod.analyze({"tool": internal, "tier": tier, "input": inputs})["result"]
        else:
            mod = _load_opentk(variant, internal)
            with tempfile.TemporaryDirectory(prefix="nvxbench_") as wd:
                res = mod.run(dict(inputs), Path(wd), **kw)
                out = {"summary": res.summary, "files": {k: v for k, v in res.files.items()
                                                         if k.endswith((".csv", ".json", ".txt", ".sdf"))}}
        return True, out, time.perf_counter() - t0
    except Exception as exc:  # noqa: BLE001 - errors are part of the measurement
        return False, f"{type(exc).__name__}: {exc}", time.perf_counter() - t0


def is_user_error(payload) -> bool:
    """True when a failure is a controlled, user-facing rejection (InputError / ToolError)."""
    return isinstance(payload, str) and payload.split(":", 1)[0] in ("InputError", "ToolError")

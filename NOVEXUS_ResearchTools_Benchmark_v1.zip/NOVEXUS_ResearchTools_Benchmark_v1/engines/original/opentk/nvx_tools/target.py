"""T09 · Target & Bioactivity Finder (ChEMBL similarity evidence).

Finds ChEMBL compounds similar to the query and aggregates their measured
bioactivities (pChEMBL) by target. Evidence-based target hypotheses — not a
prediction of activity for the query itself.
"""
from __future__ import annotations

import statistics
from collections import defaultdict
from pathlib import Path
from urllib.parse import quote

from .common import Result, ToolError, http_json, mol_from_smiles, parse_smiles_list, r3, table

VERSION = "1.0.0"
CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"
MAX_SIMILAR = 25


def similar_compounds(smiles: str, threshold: int, get=http_json):
    url = f"{CHEMBL}/similarity/{quote(smiles, safe='')}/{threshold}?format=json&limit={MAX_SIMILAR}"
    data = get(url)
    out = []
    for m in (data or {}).get("molecules", [])[:MAX_SIMILAR]:
        cid = m.get("molecule_chembl_id")
        if not cid:
            continue
        smi = ((m.get("molecule_structures") or {}).get("canonical_smiles")) or ""
        out.append({"id": cid, "name": m.get("pref_name") or "", "similarity": float(m.get("similarity") or 0), "smiles": smi})
    return out


def activities(ids: list[str], get=http_json):
    rows = []
    for i in range(0, len(ids), 10):
        chunk = ",".join(ids[i:i + 10])
        url = (f"{CHEMBL}/activity?format=json&limit=1000&pchembl_value__isnull=false&molecule_chembl_id__in={chunk}"
               "&only=molecule_chembl_id,target_chembl_id,target_pref_name,target_organism,standard_type,pchembl_value,assay_type")
        data = get(url)
        rows.extend((data or {}).get("activities", []))
    return rows


def aggregate(similar, acts):
    sim_by_id = {m["id"]: m["similarity"] for m in similar}
    targets = defaultdict(lambda: {"name": "", "organism": "", "p": [], "compounds": set(), "types": set(), "best_sim": 0.0})
    for a in acts:
        tid = a.get("target_chembl_id")
        try:
            p = float(a.get("pchembl_value"))
        except (TypeError, ValueError):
            continue
        if not tid:
            continue
        t = targets[tid]
        t["name"] = a.get("target_pref_name") or t["name"]
        t["organism"] = a.get("target_organism") or t["organism"]
        t["p"].append(p)
        mid = a.get("molecule_chembl_id")
        t["compounds"].add(mid)
        if a.get("standard_type"):
            t["types"].add(a["standard_type"])
        t["best_sim"] = max(t["best_sim"], sim_by_id.get(mid, 0.0))
    ranked = []
    for tid, t in targets.items():
        best_p = max(t["p"])
        ranked.append({
            "target": tid, "name": t["name"], "organism": t["organism"], "n_activities": len(t["p"]),
            "n_compounds": len(t["compounds"]), "best_pchembl": r3(best_p, 2), "median_pchembl": r3(statistics.median(t["p"]), 2),
            "max_similarity": r3(t["best_sim"], 1), "types": ", ".join(sorted(t["types"]))[:60],
            "evidence": "exact match" if t["best_sim"] >= 99.5 else "close analogue" if t["best_sim"] >= 85 else "analogue",
        })
    ranked.sort(key=lambda r: (-r["max_similarity"], -r["best_pchembl"], -r["n_compounds"]))
    return ranked


def run(params: dict, workdir: Path, get=http_json) -> Result:
    smi = parse_smiles_list(str(params.get("query", "")), 1)[0][0]
    mol_from_smiles(smi)
    try:
        threshold = int(params.get("threshold", 70))
    except (TypeError, ValueError):
        raise ToolError("Similarity threshold must be an integer.")
    if not 60 <= threshold <= 100:
        raise ToolError("Similarity threshold must be between 60 and 100.")
    organism = str(params.get("organism", "Homo sapiens"))
    if organism not in ("Homo sapiens", "any"):
        raise ToolError("Organism filter must be 'Homo sapiens' or 'any'.")

    similar = similar_compounds(smi, threshold, get)
    if not similar:
        raise ToolError(f"No ChEMBL compounds found with similarity ≥ {threshold} %. Try a lower threshold.")
    ranked = aggregate(similar, activities([m["id"] for m in similar], get))
    if organism != "any":
        ranked = [r for r in ranked if r["organism"] == organism]

    res = Result()
    rows = [[i + 1, r["name"] or r["target"], r["target"], r["organism"], r["evidence"], r["max_similarity"], r["best_pchembl"],
             r["median_pchembl"], r["n_compounds"], r["n_activities"], r["types"]] for i, r in enumerate(ranked)]
    comp_rows = [[m["id"], m["name"], r3(m["similarity"], 1), m["smiles"]] for m in similar]
    res.summary = {
        "headline": [{"label": "Similar ChEMBL compounds", "value": len(similar)},
                     {"label": "Targets with measured activity", "value": len(ranked)},
                     {"label": "Top hypothesis", "value": (ranked[0]["name"] or ranked[0]["target"]) if ranked else "none"},
                     {"label": "Similarity threshold", "value": f"{threshold} %"}],
        "tables": [
            table("Target hypotheses (evidence from similar compounds)", ["Rank", "Target", "ChEMBL ID", "Organism", "Evidence", "Max similarity %",
                                                                         "Best pChEMBL", "Median pChEMBL", "Compounds", "Activities", "Endpoints"], rows,
                  note="pChEMBL = −log10(molar IC50/EC50/Ki/Kd); ≥6 ≈ 1 µM, ≥7 ≈ 100 nM."),
            table("Similar compounds", ["ChEMBL ID", "Name", "Similarity %", "SMILES"], comp_rows),
        ],
        "notes": ["Data: ChEMBL (EMBL-EBI), CC BY-SA 3.0. Hypotheses are inferred from structurally similar compounds and require experimental confirmation."],
    }
    res.add_csv("target_hypotheses.csv", ["rank", "target_name", "target_chembl_id", "organism", "evidence", "max_similarity", "best_pchembl",
                                          "median_pchembl", "n_compounds", "n_activities", "endpoints"], rows)
    res.add_csv("similar_compounds.csv", ["chembl_id", "name", "similarity", "smiles"], comp_rows)
    return res

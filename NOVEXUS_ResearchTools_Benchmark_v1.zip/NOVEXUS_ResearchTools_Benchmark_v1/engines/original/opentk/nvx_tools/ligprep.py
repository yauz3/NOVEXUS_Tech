"""T04 · Ligand 3D Preparation (docking-ready).

Standardise → pH-dependent protonation (Dimorphite-DL) → tautomer enumeration →
ETKDGv3 conformers → MMFF94 optimisation → SDF / PDB / PDBQT (Meeko, optional).
"""
from __future__ import annotations

from pathlib import Path

from .common import Result, ToolError, mol_from_smiles, parse_smiles_list, r3, table

VERSION = "1.0.0"
MAX_FREE = 10
MAX_CONF_FREE = 10


def _standardise(mol):
    from rdkit.Chem.MolStandardize import rdMolStandardize

    mol = rdMolStandardize.Cleanup(mol)
    mol = rdMolStandardize.LargestFragmentChooser().choose(mol)
    return rdMolStandardize.Uncharger().uncharge(mol)


def _protonate(smi: str, ph: float) -> list[str]:
    try:
        from dimorphite_dl import protonate_smiles
    except ImportError:
        return [smi]
    try:
        out = protonate_smiles(smi, ph_min=ph, ph_max=ph, precision=0.5, max_variants=4)
    except Exception:  # noqa: BLE001 - Dimorphite raises on exotic chemistry; keep neutral form
        return [smi]
    return list(dict.fromkeys(out)) or [smi]


def _tautomers(mol, n: int):
    from rdkit import Chem
    from rdkit.Chem.MolStandardize import rdMolStandardize

    enum = rdMolStandardize.TautomerEnumerator()
    enum.SetMaxTautomers(50)
    canonical = enum.Canonicalize(mol)
    out = [canonical]
    if n > 1:
        seen = {Chem.MolToSmiles(canonical)}
        for t in enum.Enumerate(mol):
            s = Chem.MolToSmiles(t)
            if s not in seen:
                seen.add(s)
                out.append(t)
            if len(out) >= n:
                break
    return out


def _embed(mol, n_conf: int, seed: int):
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mh = Chem.AddHs(mol)
    ps = AllChem.ETKDGv3()
    ps.randomSeed = seed
    ps.pruneRmsThresh = 0.5
    cids = list(AllChem.EmbedMultipleConfs(mh, numConfs=n_conf, params=ps))
    if not cids:
        ps.useRandomCoords = True
        cids = list(AllChem.EmbedMultipleConfs(mh, numConfs=n_conf, params=ps))
    if not cids:
        raise ToolError("3D embedding failed for this molecule.")
    energies = []
    if AllChem.MMFFHasAllMoleculeParams(mh):
        res = AllChem.MMFFOptimizeMoleculeConfs(mh, maxIters=2000)
        energies = [e for _, e in res]
        ff = "MMFF94"
    else:
        res = AllChem.UFFOptimizeMoleculeConfs(mh, maxIters=2000)
        energies = [e for _, e in res]
        ff = "UFF"
    order = sorted(range(len(cids)), key=lambda i: energies[i])
    return mh, [cids[i] for i in order], [energies[i] for i in order], ff


def _pdbqt(mol, conf_id: int) -> str | None:
    try:
        from meeko import MoleculePreparation, PDBQTWriterLegacy
        from rdkit import Chem
    except ImportError:
        return None
    try:
        single = Chem.Mol(mol, confId=conf_id)
        prep = MoleculePreparation()
        setups = prep.prepare(single)
        text, ok, _ = PDBQTWriterLegacy.write_string(setups[0])
        return text if ok else None
    except Exception:  # noqa: BLE001 - PDBQT is a convenience output
        return None


def run(params: dict, workdir: Path) -> Result:
    from rdkit import Chem

    mols = parse_smiles_list(params.get("molecules", ""), MAX_FREE)
    try:
        ph = float(params.get("ph", 7.4))
        n_taut = int(params.get("tautomers", 1))
        n_conf = int(params.get("conformers", 5))
    except (TypeError, ValueError):
        raise ToolError("pH, tautomer and conformer counts must be numbers.")
    if not 5.0 <= ph <= 9.0:
        raise ToolError("Free tier pH range is 5.0–9.0.")
    if not 1 <= n_taut <= 3 or not 1 <= n_conf <= MAX_CONF_FREE:
        raise ToolError(f"Free tier allows 1–3 tautomers and 1–{MAX_CONF_FREE} conformers.")

    res = Result()
    rows, warnings = [], []
    sdf_blocks: list[str] = []
    best_pdb = None
    pdbqt_missing = False
    for idx, (smi, name) in enumerate(mols, start=1):
        try:
            base = _standardise(mol_from_smiles(smi))
        except ToolError as exc:
            warnings.append(f"{name}: {exc}")
            continue
        variants = []
        for psmi in _protonate(Chem.MolToSmiles(base), ph):
            pm = Chem.MolFromSmiles(psmi)
            if pm is None:
                continue
            for t in _tautomers(pm, n_taut):
                variants.append(t)
                if len(variants) >= n_taut:
                    break
            if len(variants) >= n_taut:
                break
        if not variants:
            variants = [base]
        for v_i, var in enumerate(variants, start=1):
            vname = f"{name}" if len(variants) == 1 else f"{name}_v{v_i}"
            try:
                mh, cids, energies, ff = _embed(var, n_conf, seed=2026 + idx)
            except ToolError as exc:
                warnings.append(f"{vname}: {exc}")
                continue
            for rank, (cid, e) in enumerate(zip(cids, energies), start=1):
                mh.SetProp("_Name", f"{vname}_conf{rank}")
                mh.SetProp("NVX_energy_kcal_mol", f"{e:.4f}")
                mh.SetProp("NVX_forcefield", ff)
                mh.SetProp("NVX_pH", f"{ph:.1f}")
                sdf_blocks.append(Chem.MolToMolBlock(mh, confId=cid) + "".join(
                    f">  <{k}>\n{mh.GetProp(k)}\n\n" for k in ("NVX_energy_kcal_mol", "NVX_forcefield", "NVX_pH")) + "$$$$\n")
            res.files[f"pdb/{vname}_lowest.pdb"] = Chem.MolToPDBBlock(mh, confId=cids[0]).encode()
            if best_pdb is None:
                best_pdb = Chem.MolToPDBBlock(mh, confId=cids[0]).encode()
            pq = _pdbqt(mh, cids[0])
            if pq:
                res.files[f"pdbqt/{vname}_lowest.pdbqt"] = pq.encode()
            else:
                pdbqt_missing = True
            rows.append([vname, Chem.MolToSmiles(Chem.RemoveHs(mh)), Chem.GetFormalCharge(mh), len(cids), ff,
                         r3(energies[0], 2), r3(energies[-1] - energies[0], 2), "yes" if pq else "no"])
    if not rows:
        raise ToolError("No molecule could be prepared in 3D.")
    res.files["all_conformers.sdf"] = "".join(sdf_blocks).encode()
    res.summary = {
        "headline": [
            {"label": "Input molecules", "value": len(mols)},
            {"label": "Prepared variants", "value": len(rows)},
            {"label": "Conformers written", "value": len(sdf_blocks)},
            {"label": "Target pH", "value": ph},
        ],
        "tables": [table("Prepared ligands", ["Variant", "Protonated SMILES", "Net charge", "Conformers", "Force field",
                                              "Lowest E (kcal/mol)", "E range", "PDBQT"], rows)],
        "notes": ["Protonation states are rule-based (Dimorphite-DL) and should be checked for unusual functional groups.",
                  "ZIP: all_conformers.sdf, lowest-energy PDB per variant and Vina-ready PDBQT (Meeko)."],
    }
    if pdbqt_missing:
        warnings.append("PDBQT was not produced for at least one variant (Meeko not installed or unsupported chemistry).")
    if warnings:
        res.summary["warnings"] = warnings
    if best_pdb:
        res.viewer = ("pdb", best_pdb)
    return res

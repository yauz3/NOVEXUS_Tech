#!/usr/bin/env python3
"""Novexus v0.24 lightweight science engines; no network or shell execution.
Existing Novexus engines are never imported or modified. Only conventional methods.
"""
from __future__ import annotations
import json, math, re, sys
from collections import Counter

TOOLS = {
 'druglikeness': 'Molecule Property & Drug-likeness',
 'structural_alerts': 'PAINS & Structural Alerts',
 'chemical_similarity': 'Chemical Similarity Search',
 'scaffold_analysis': 'Murcko Scaffold Explorer',
 'chemical_diversity': 'Chemical Diversity Analyzer',
 'protein_properties': 'Protein Sequence Profiler',
 'motif_scanner': 'Protein Motif Scanner',
 'sequence_alignment': 'Pairwise Sequence Alignment',
 'peptide_profile': 'Peptide Developability Screen',
 'primer_design': 'PCR Primer Candidate Screen',
}

class InputError(ValueError): pass

def lines(text, max_n):
    raw=[x.strip() for x in str(text).splitlines() if x.strip()]
    if not raw or len(raw)>max_n: raise InputError(f'Provide 1–{max_n} nonempty lines.')
    return raw

def molecules(s, cap):
    from rdkit import Chem
    values=lines(s,cap)
    output=[]
    for i,item in enumerate(values):
        # Allow "NAME<tab>SMILES" or "SMILES". Never interpret as commands.
        fields=item.split('\t')
        if len(fields)>2:raise InputError('SMILES entries may contain at most one tab separator.')
        name=fields[0][:32] if len(fields)==2 else f'Compound {i+1}'
        smile=fields[-1].strip()
        if len(smile)>300:raise InputError('A SMILES entry exceeds 300 characters.')
        mol=Chem.MolFromSmiles(smile)
        if mol is None or mol.GetNumHeavyAtoms()<1 or mol.GetNumHeavyAtoms()>120:
            raise InputError(f'Invalid or oversized SMILES on line {i+1}.')
        output.append((name,Chem.MolToSmiles(mol),mol))
    return output

def sequence(text, amino=True, limit=2000):
    t=str(text).strip();t=re.sub(r'^>[^\n]*\n','',t);s=re.sub(r'\s+','',t).upper()
    alphabet='ACDEFGHIKLMNPQRSTVWY' if amino else 'ACGT'
    if not 1<=len(s)<=limit or any(c not in alphabet for c in s):
        raise InputError(f'Enter a valid {"protein" if amino else "DNA"} sequence of 1–{limit} canonical residues.')
    return s

def _cap(tier, free, pro):return pro if tier=='PRO' else free

def druglikeness(data,tier):
    from rdkit.Chem import Descriptors, Lipinski, rdMolDescriptors, Crippen
    out=[]
    for name,smiles,m in molecules(data['primary'],_cap(tier,3,80)):
        mw=Descriptors.MolWt(m); logp=Crippen.MolLogP(m); hbd=Lipinski.NumHDonors(m);hba=Lipinski.NumHAcceptors(m)
        rot=Lipinski.NumRotatableBonds(m);tpsa=rdMolDescriptors.CalcTPSA(m)
        violations=sum([mw>500,logp>5,hbd>5,hba>10])
        out.append(dict(name=name,smiles=smiles,mw=round(mw,2),logp=round(logp,2),tpsa=round(tpsa,2),hbd=hbd,hba=hba,rotatable=rot,rings=rdMolDescriptors.CalcNumRings(m),heavy_atoms=m.GetNumHeavyAtoms(),lipinski_violations=violations,lipinski_pass=violations<=1,veber_pass=(rot<=10 and tpsa<=140)))
    return {'rows':out,'notes':['Rule-of-five and Veber are descriptive medicinal-chemistry heuristics, not measured ADMET or clinical outcomes.']}

def alerts(data,tier):
    from rdkit.Chem import FilterCatalog
    selected=(('PAINS_A','PAINS_B','PAINS_C') if tier=='FREE' else ('PAINS_A','PAINS_B','PAINS_C','BRENK'))
    pars=FilterCatalog.FilterCatalogParams()
    for label in selected:pars.AddCatalog(getattr(FilterCatalog.FilterCatalogParams.FilterCatalogs,label))
    catalog=FilterCatalog.FilterCatalog(pars)
    rows=[]
    for name,smiles,m in molecules(data['primary'],_cap(tier,3,50)):
        hits=[x.GetDescription() for x in catalog.GetMatches(m)]
        rows.append(dict(name=name,smiles=smiles,hit_count=len(hits),alerts=sorted(set(hits))[:30],no_catalog_hits=len(hits)==0))
    return {'rows':rows,'catalogs':selected,'notes':['Alerts are substructure flags for review; no match is not proof of safety. Brenk catalogue is available to Pro users.']}

def similarity(data,tier):
    from rdkit import Chem
    from rdkit.Chem import rdFingerprintGenerator
    from rdkit import DataStructs
    q=molecules(data['primary'],1)[0]
    others=molecules(data.get('secondary',''),_cap(tier,12,200))
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    fp=gen.GetFingerprint(q[2]);rows=[]
    for name,smi,m in others:
        score=DataStructs.TanimotoSimilarity(fp,gen.GetFingerprint(m))
        rows.append({'name':name,'smiles':smi,'morgan_tanimoto':round(score,5)})
    rows.sort(key=lambda d:d['morgan_tanimoto'],reverse=True)
    return {'query':q[1],'rows':rows,'notes':['Morgan radius 2 / 2048-bit Tanimoto. Searches only compounds pasted by the user, not a global database.']}

def scaffolds(data,tier):
    from rdkit.Chem.Scaffolds import MurckoScaffold
    rows=[]
    for name,smi,m in molecules(data['primary'],_cap(tier,6,120)):
        sc=MurckoScaffold.GetScaffoldForMol(m)
        from rdkit import Chem
        rows.append(dict(name=name,smiles=smi,murcko_scaffold=Chem.MolToSmiles(sc) or '(acyclic / no ring scaffold)',ring_atoms=sc.GetNumAtoms()))
    unique=len(set(x['murcko_scaffold'] for x in rows))
    return {'rows':rows,'unique_scaffolds':unique,'notes':['Bemis–Murcko scaffold decomposition groups frameworks; it does not rank binding affinity.']}

def diversity(data,tier):
    from rdkit.Chem import rdFingerprintGenerator
    from rdkit import DataStructs
    mols=molecules(data['primary'],_cap(tier,12,120))
    if len(mols)<2:raise InputError('Provide at least two compounds.')
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=1024)
    fps=[gen.GetFingerprint(m) for _,_,m in mols]
    pairs=[]
    for i in range(len(fps)):
        for j in range(i):pairs.append(DataStructs.TanimotoSimilarity(fps[i],fps[j]))
    # Lightweight greedy coverage: pick initial molecule and iteratively most dissimilar point.
    picks=[0];pool=set(range(1,len(fps)));maximum=_cap(tier,3,15)
    while pool and len(picks)<maximum:
        next_i=max(sorted(pool),key=lambda i:min(1-DataStructs.TanimotoSimilarity(fps[i],fps[j]) for j in picks))
        picks.append(next_i);pool.remove(next_i)
    return {'molecule_count':len(fps),'mean_pairwise_tanimoto':round(sum(pairs)/len(pairs),4),'min_pairwise_tanimoto':round(min(pairs),4),'max_pairwise_tanimoto':round(max(pairs),4),'representative_set':[{'name':mols[i][0],'smiles':mols[i][1]} for i in picks],'notes':['Greedy max–min picks representative chemical diversity; not a validated clustering or pharmacological prediction.']}

def protein_properties(data,tier):
    from Bio.SeqUtils.ProtParam import ProteinAnalysis
    seq=sequence(data['primary'],limit=_cap(tier,2000,12000));p=ProteinAnalysis(seq)
    return {'length':len(seq),'molecular_weight_da':round(p.molecular_weight(),2),'isoelectric_point':round(p.isoelectric_point(),3),'gravy':round(p.gravy(),3),'aromaticity':round(p.aromaticity(),4),'instability_index':round(p.instability_index(),3),'secondary_structure_fraction':[round(x,3) for x in p.secondary_structure_fraction()],'amino_acid_composition':dict(Counter(seq)),'notes':['Computed sequence-level descriptors; not protein structure or experimental stability predictions.']}

def motif_scanner(data,tier):
    seq=sequence(data['primary'],limit=_cap(tier,2000,12000))
    # Conventional short linear motif patterns, all clearly labeled as candidates.
    patterns={'N-glycosylation N-{P}-[ST]-{P} (PROSITE PS00001)':r'N[^P][ST][^P]', 'Casein kinase II S/T-X-X-D/E':r'[ST]..[DE]', 'Protein kinase C S/T-X-R/K':r'[ST].[RK]', 'Tyrosine-based Y-X-X-Φ sorting motif':r'Y..[LIVMF]', 'R-X-R endoproteolytic motif':r'R.R'}
    hits=[]
    for label,regex in patterns.items():
        for match in re.finditer('(?=('+regex+'))',seq):
            hits.append({'motif':label,'position_1based':match.start()+1,'match':match.group(1)})
            if len(hits)>_cap(tier,30,500):break
    return {'sequence_length':len(seq),'hit_count':len(hits),'rows':hits[:_cap(tier,30,500)],'notes':['Sequence motif matches alone do not establish modification, localization or activity. Overlapping matches included.']}

def alignment(data,tier):
    from Bio import Align
    limit=_cap(tier,600,3000)
    a=sequence(data['primary'],limit=limit);b=sequence(data.get('secondary',''),limit=limit)
    mode=str(data.get('mode','global'))
    if mode not in ('global','local'):raise InputError('Mode must be global or local.')
    # FIX v0.26.1: protein alignment now uses BLOSUM62 with EMBOSS-style gaps (-10/-0.5)
    # instead of identity scoring (+2/-1), which mis-aligns divergent homologues.
    from Bio.Align import substitution_matrices
    aligner=Align.PairwiseAligner(mode=mode,open_gap_score=-10,extend_gap_score=-0.5)
    aligner.substitution_matrix=substitution_matrices.load('BLOSUM62')
    al=aligner.align(a,b)[0];s=str(al)
    match=0;both=0
    for (s1,e1),(s2,e2) in zip(al.aligned[0],al.aligned[1]):
        n=min(e1-s1,e2-s2);both+=n;match+=sum(a[s1+k]==b[s2+k] for k in range(n))
    return {'mode':mode,'score':round(float(al.score),3),'aligned_positions':both,'identity_over_aligned_positions':round(match/both,5) if both else None,'alignment':s[:_cap(tier,4200,14000)],'notes':['Protein global/local pairwise alignment, BLOSUM62, gap open -10 / extend -0.5. Identity excludes gaps; alignment display truncated when needed.']}

def peptide(data,tier):
    from Bio.SeqUtils.ProtParam import ProteinAnalysis
    from Bio.SeqUtils import seq3
    seq=sequence(data['primary'],limit=_cap(tier,60,400));p=ProteinAnalysis(seq)
    charge=p.charge_at_pH(7.4)
    # Surface simple descriptive warnings; no learned developability scores.
    warnings=[]
    if p.gravy()>1:warnings.append('Strongly hydrophobic average composition: solubility may require review.')
    if seq.count('C')>1:warnings.append('Multiple cysteines: possible disulfide/oxidation considerations.')
    if 'NG' in seq or 'DG' in seq:warnings.append('Asn-Gly/Asp-Gly sequence: inspect possible deamidation/isomerization hotspots.')
    if seq.count('M')>0:warnings.append('Methionine present: inspect potential oxidation.')
    return {'sequence':seq,'length':len(seq),'mass_da':round(p.molecular_weight(),2),'isoelectric_point':round(p.isoelectric_point(),3),'charge_at_ph_7_4':round(charge,3),'gravy':round(p.gravy(),3),'aromaticity':round(p.aromaticity(),3),'warnings':warnings,'notes':['Heuristic developability considerations are not experimental solubility, toxicity, aggregation, or immunogenicity predictions.']}

def _tm(oligo):
    """FIX v0.26.1: standard PCR buffer (50 mM Na+, 1.5 mM Mg2+, 0.6 mM dNTP, 25/25 nM oligo).
    With these conditions Biopython Tm_NN reproduces Primer3 calc_tm defaults exactly;
    the previous Mg-free default under-estimated Tm by ~5.8 degC."""
    from Bio.SeqUtils import MeltingTemp as mt
    return mt.Tm_NN(oligo,Na=50,Mg=1.5,dNTPs=0.6,dnac1=25,dnac2=25,saltcorr=5)

def primers(data,tier):
    """Conservative target-local PCR primer candidate screening, not Primer3."""
    from Bio.SeqUtils import MeltingTemp as mt
    from Bio.Seq import Seq
    seq=sequence(data['primary'],amino=False,limit=_cap(tier,1000,5000))
    if len(seq)<100:raise InputError('Primer screening requires a DNA template of at least 100 bases.')
    target_return=_cap(tier,2,10)
    lefts=[];rights=[]
    # Restrict search to at most 160 candidate windows near each side for predictable cost.
    for start in range(min(90,len(seq)-95)):
        for length in (19,20,21,22,23):
            fw=seq[start:start+length]
            if len(fw)<length:continue
            gc=(fw.count('G')+fw.count('C'))/length
            if not .35<=gc<=.65 or any(x*5 in fw for x in 'ACGT'):continue
            tm=_tm(fw)
            if 56<=tm<=64 and seq.count(fw)==1:lefts.append((abs(tm-60)+abs(gc-.5)*5,start,fw,tm))
    for end in range(max(100,len(seq)-90),len(seq)+1):
        for length in (19,20,21,22,23):
            bind=seq[end-length:end]
            if len(bind)<length:continue
            rev=str(Seq(bind).reverse_complement())
            gc=(rev.count('G')+rev.count('C'))/length
            if not .35<=gc<=.65 or any(x*5 in rev for x in 'ACGT'):continue
            tm=_tm(rev)
            if 56<=tm<=64 and seq.count(bind)==1:rights.append((abs(tm-60)+abs(gc-.5)*5,end-1,rev,tm))
    rows=[]
    for a in sorted(lefts)[:12]:
        for b in sorted(rights)[:12]:
            product=b[1]-a[1]+1
            if not (80<=product<=min(650,len(seq))):continue
            if abs(a[3]-b[3])>3.5:continue
            # Simple 3' exact complementarity flag (does not replace thermodynamic screening).
            rev_end=b[2][-5:]; fwd_end=a[2][-5:]
            if rev_end==str(Seq(fwd_end).reverse_complement()):continue
            rows.append({'forward':a[2],'reverse':b[2],'forward_tm_nn':round(a[3],2),'reverse_tm_nn':round(b[3],2),'amplicon_bp':product,'left_0based':a[1],'right_0based':b[1],'screening_penalty':round(a[0]+b[0]+abs(a[3]-b[3]),3)})
    rows.sort(key=lambda row:row['screening_penalty'])
    for i,r in enumerate(rows[:target_return]):r['pair']=i+1
    return {'rows':rows[:target_return],'notes':['Lightweight nearest-neighbour Tm and local sequence filtering, NOT full Primer3 thermodynamic primer design. Hairpins, heterodimers, genome-wide off-targets and wet-lab efficacy are not verified.','If no candidates pass, use a longer template or adjust the region.']}

HANDLERS={'druglikeness':druglikeness,'structural_alerts':alerts,'chemical_similarity':similarity,'scaffold_analysis':scaffolds,'chemical_diversity':diversity,'protein_properties':protein_properties,'motif_scanner':motif_scanner,'sequence_alignment':alignment,'peptide_profile':peptide,'primer_design':primers}

def analyze(payload):
    if not isinstance(payload,dict):raise InputError('Input must be a JSON object.')
    tool=payload.get('tool');tier=payload.get('tier','FREE')
    if tool not in HANDLERS or tier not in ('FREE','PRO'):raise InputError('Unknown tool or tier.')
    data=payload.get('input');
    if not isinstance(data,dict):raise InputError('Input must be an object.')
    primary=data.get('primary','');secondary=data.get('secondary','')
    if not isinstance(primary,str) or not isinstance(secondary,str) or len(primary)>30000 or len(secondary)>30000:raise InputError('Input size exceeds limit.')
    result=HANDLERS[tool](data,tier)
    return {'tool':tool,'tool_name':TOOLS[tool],'tier':tier,'method_type':'established computational method','result':result}

if __name__=='__main__':
    try:
        obj=json.load(sys.stdin)
        result=analyze(obj)
        print(json.dumps({'ok':True,'result':result},separators=(',',':'),allow_nan=False))
    except (InputError,ValueError,ImportError,RuntimeError,KeyError) as exc:
        print(json.dumps({'ok':False,'error':str(exc)[:220]}))
        sys.exit(2)

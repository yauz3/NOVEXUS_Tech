#!/usr/bin/env python3
"""Novexus v0.25 independent compact scientific methods.
Only standard published heuristics and mature RDKit/Biopython algorithms;
no model training, remote data retrieval, code execution, or legacy imports.
"""
from __future__ import annotations
import json, math, re, sys
from collections import Counter

TOOLS={
 'formula_mass':'Molecular Formula & Accurate Mass',
 'functional_groups':'Functional Group Explorer',
 'esol_estimator':'ESOL Solubility Estimate',
 'ligand_efficiency':'Ligand Efficiency & LipE Calculator',
 'compound_cleanup':'Compound Parent & Duplicate Finder',
 'dna_quality':'DNA Sequence Quality Check',
 'orf_finder':'Six-frame ORF Explorer',
 'crispr_guide':'SpCas9 Guide Candidate Explorer',
 'variant_compare':'Protein Variant Comparison',
 'restriction_map':'Restriction Enzyme Map'
}
class InputError(ValueError):pass

def cap(tier,free,pro):return pro if tier=='PRO' else free

def entries(text,maximum):
    rows=[x.strip() for x in str(text).splitlines() if x.strip()]
    if not 1<=len(rows)<=maximum:raise InputError(f'Enter 1 to {maximum} nonempty lines.')
    return rows

def parse_mols(text,maximum):
    from rdkit import Chem
    parsed=[]
    for i,row in enumerate(entries(text,maximum),1):
        fields=row.split('\t')
        if len(fields)>2:raise InputError('Use NAME<TAB>SMILES or SMILES only.')
        smile=fields[-1].strip()
        if not 1<=len(smile)<=300:raise InputError('SMILES length must be 1–300.')
        mol=Chem.MolFromSmiles(smile)
        if mol is None or not 1<=mol.GetNumHeavyAtoms()<=120:raise InputError(f'Invalid/oversized SMILES at line {i}.')
        name=fields[0][:40] if len(fields)==2 else f'Compound {i}'
        parsed.append((name,Chem.MolToSmiles(mol),mol))
    return parsed

def dna(text,limit,allow_n=False):
    raw=str(text).strip()
    raw=re.sub(r'^>[^\r\n]*(\r?\n|$)','',raw)
    seq=re.sub(r'\s+','',raw).upper()
    alphabet='ACGTN' if allow_n else 'ACGT'
    if not 1<=len(seq)<=limit or set(seq)-set(alphabet):
        raise InputError(f'Enter 1–{limit} DNA bases ({alphabet}); a single FASTA record is supported.')
    return seq

def protein(text,limit):
    raw=re.sub(r'^>[^\r\n]*(\r?\n|$)','',str(text).strip())
    seq=re.sub(r'\s+','',raw).upper()
    if not 1<=len(seq)<=limit or set(seq)-set('ACDEFGHIKLMNPQRSTVWY'):
        raise InputError(f'Enter 1–{limit} canonical protein residues.')
    return seq

def formula_mass(d,tier):
    from rdkit.Chem import rdMolDescriptors, Descriptors
    from rdkit import Chem
    out=[]
    for name,smi,mol in parse_mols(d['primary'],cap(tier,5,100)):
        with_h=Chem.AddHs(mol)
        elements=Counter(a.GetSymbol() for a in with_h.GetAtoms())
        out.append({'name':name,'smiles':smi,'formula':rdMolDescriptors.CalcMolFormula(mol),
          'exact_mass_da':round(rdMolDescriptors.CalcExactMolWt(mol),5),
          'average_mass_da':round(Descriptors.MolWt(mol),4),
          'formal_charge':Chem.GetFormalCharge(mol),'element_counts':dict(sorted(elements.items()))})
    return {'rows':out,'notes':['Calculated RDKit monoisotopic mass and average molecular weight for the entered chemical structure, not an observed mass spectrum.']}

def functional_groups(d,tier):
    from rdkit.Chem import Fragments
    # Stable list of public RDKit fragment counters (not a trained classifier).
    names=['fr_Al_COO','fr_Ar_COO','fr_Al_OH','fr_Ar_OH','fr_NH0','fr_NH1','fr_NH2','fr_amide','fr_ester','fr_ether','fr_ketone','fr_aldehyde','fr_nitrile','fr_nitro','fr_halogen','fr_sulfide','fr_sulfonamd','fr_sulfone','fr_benzene','fr_heteroaromatic','fr_urea','fr_guanido','fr_azide','fr_epoxide']
    # FIX v0.26.1: fr_heteroaromatic does not exist in RDKit and was silently dropped.
    # It is replaced by an explicit count of aromatic rings containing >=1 heteroatom.
    def _heteroaromatic(m):
        ri=m.GetRingInfo()
        return sum(1 for ring in ri.AtomRings() if all(m.GetAtomWithIdx(i).GetIsAromatic() for i in ring)
                   and any(m.GetAtomWithIdx(i).GetAtomicNum()!=6 for i in ring))
    found=[(n,_heteroaromatic if n=='fr_heteroaromatic' else getattr(Fragments,n,None)) for n in names]
    out=[]
    for name,smi,m in parse_mols(d['primary'],cap(tier,5,100)):
        fg={n[3:]:int(fn(m)) for n,fn in found if fn is not None and fn(m)>0}
        out.append({'name':name,'smiles':smi,'functional_groups':fg,'matched_group_types':len(fg)})
    return {'rows':out,'notes':['RDKit built-in fragment counters. Counts may overlap; unmatched atoms do not imply absent chemistry.']}

def esol(d,tier):
    from rdkit.Chem import Descriptors, Crippen, Lipinski
    from rdkit.Chem import rdMolDescriptors
    out=[]
    for name,smi,m in parse_mols(d['primary'],cap(tier,5,80)):
        mw=Descriptors.MolWt(m);lp=Crippen.MolLogP(m);rb=Lipinski.NumRotatableBonds(m)
        arom=sum(a.GetIsAromatic() for a in m.GetAtoms())
        ap=arom/max(1,m.GetNumHeavyAtoms())
        # Delaney ESOL published linear approximation with aromatic proportion.
        log_s=0.16-0.63*lp-0.0062*mw+0.066*rb-0.74*ap
        out.append({'name':name,'smiles':smi,'estimated_logS_mol_L':round(log_s,3),
          'estimated_solubility_mg_L':round((10**log_s)*mw*1000,5) if log_s>-30 else 0,
          'logp':round(lp,3),'mw_da':round(mw,2),'rotatable_bonds':rb,'aromatic_fraction':round(ap,3)})
    return {'rows':out,'notes':['ESOL (Delaney) is an empirical structure-based approximation, not an experimental aqueous solubility measurement. pH, ionization and salts can strongly affect real solubility.']}

def ligand_efficiency(d,tier):
    from rdkit.Chem import Descriptors, Crippen
    out=[]
    for i,line in enumerate(entries(d['primary'],cap(tier,5,80)),1):
        fields=line.split('\t')
        if len(fields) not in (2,3):raise InputError('Use SMILES<TAB>pKi or NAME<TAB>SMILES<TAB>pKi.')
        name=fields[0][:40] if len(fields)==3 else f'Compound {i}'
        smi=fields[-2].strip()
        try:pki=float(fields[-1])
        except ValueError:raise InputError(f'Invalid pKi on line {i}.')
        if not math.isfinite(pki) or not 0<=pki<=15:raise InputError('pKi must be a finite value between 0 and 15.')
        from rdkit import Chem
        mol=Chem.MolFromSmiles(smi) if len(smi)<=300 else None
        if mol is None or not 1<=mol.GetNumHeavyAtoms()<=120:raise InputError(f'Invalid SMILES on line {i}.')
        heavy=mol.GetNumHeavyAtoms();lp=Crippen.MolLogP(mol)
        # DeltaG = RT ln(Ki); negative sign for favorable binding energy.
        rtln10=0.00198720425864083*298.15*math.log(10)
        out.append({'name':name,'smiles':Chem.MolToSmiles(mol),'pKi_input':pki,
          'heavy_atoms':heavy,'logp':round(lp,3),'LipE_pKi_minus_logP':round(pki-lp,3),
          'ligand_efficiency_kcal_mol_per_heavy_atom':round(rtln10*pki/heavy,4)})
    return {'rows':out,'notes':['pKi must be derived from measured equilibrium Ki (mol/L), not automatically interchangeable with pIC50. LE is magnitude-based at 298.15 K; LipE = pKi – calculated logP.']}

def cleanup(d,tier):
    from rdkit import Chem
    from rdkit.Chem.MolStandardize import rdMolStandardize
    groups={}; rows=[]
    for name,smi,m in parse_mols(d['primary'],cap(tier,10,120)):
        clean=rdMolStandardize.Cleanup(Chem.Mol(m))
        # FIX v0.26.1: ChargeParent = FragmentParent + Uncharger, so a sodium carboxylate
        # and its free acid share one parent (previously they were reported as distinct).
        parent=rdMolStandardize.ChargeParent(clean)
        canonical=Chem.MolToSmiles(parent,isomericSmiles=True)
        if not canonical:raise InputError('Structure cleanup produced an empty parent.')
        groups.setdefault(canonical,[]).append(name)
        rows.append({'name':name,'input_smiles':smi,'parent_smiles':canonical,'removed_fragment':len(Chem.GetMolFrags(m))>len(Chem.GetMolFrags(parent))})
    for row in rows:row['duplicate_parent_count']=len(groups[row['parent_smiles']])
    return {'rows':rows,'unique_parent_count':len(groups),'duplicate_groups':[v for v in groups.values() if len(v)>1],
            'notes':['RDKit charge-parent cleanup removes disconnected fragments, neutralizes charges where possible and normalizes representations; stereochemistry is retained in canonical grouping. It is not exhaustive tautomer or bioactivity equivalence.']}

def dna_quality(d,tier):
    s=dna(d['primary'],cap(tier,3000,20000),allow_n=True)
    bases=Counter(s);non_n=len(s)-bases['N'];gc=(bases['G']+bases['C'])/non_n if non_n else None
    longest=max(len(m.group()) for m in re.finditer(r'(A+|C+|G+|T+|N+)',s))
    dinucs=Counter(s[i:i+2] for i in range(len(s)-1) if 'N' not in s[i:i+2])
    counts=[bases[x] for x in 'ACGT'];summ=sum(counts)
    ent=-sum((x/summ)*math.log2(x/summ) for x in counts if x and summ) if summ else None
    return {'length_bp':len(s),'bases':dict(sorted(bases.items())),'gc_percent_excluding_N':round(gc*100,2) if gc is not None else None,
       'n_percent':round(100*bases['N']/len(s),2),'longest_homopolymer_run':longest,
       'shannon_entropy_bases_bits':round(ent,4) if ent is not None else None,
       'most_common_dinucleotides':dinucs.most_common(10),
       'notes':['Descriptive sequence quality metrics, not read-level Phred scores, contaminant classification, or sequencing error probability.']}

def orf(d,tier):
    from Bio.Seq import Seq
    s=dna(d['primary'],cap(tier,3000,18000)); min_aa=10; candidates=[]
    for strand,seq in (('+',s),('-',str(Seq(s).reverse_complement()))):
        for frame in range(3):
            # One active start per reading-frame segment, bounded processing.
            start=None
            for i in range(frame,len(s)-2,3):
                codon=seq[i:i+3]
                if codon=='ATG' and start is None:start=i
                if codon in {'TAA','TAG','TGA'}:
                    if start is not None and (i-start)//3>=min_aa:
                        if strand=='+':start_1=start+1;end_1=i+3
                        else:start_1=len(s)-(i+3)+1;end_1=len(s)-start
                        aa=str(Seq(seq[start:i]).translate())
                        candidates.append({'strand':strand,'frame':frame+1,'start_1based':start_1,
                            'end_1based':end_1,'aa_length':len(aa),'stop_codon':codon,
                            'translation_preview':aa[:80]})
                    start=None
    candidates.sort(key=lambda c:(-c['aa_length'],c['start_1based'],c['strand']))
    max_return=cap(tier,15,100)
    return {'sequence_length':len(s),'minimum_aa':min_aa,'total_orfs':len(candidates),'rows':candidates[:max_return],
       'notes':['ATG-to-stop candidates on six reading frames (standard genetic code), minimum 10 amino acids. This is not gene annotation, transcript isoform discovery or expression evidence.']}

def crispr(d,tier):
    from Bio.Seq import Seq
    seq=dna(d['primary'],cap(tier,2500,15000)); arr=[]
    for strand,oriented in (('+',seq),('-',str(Seq(seq).reverse_complement()))):
        for i in range(20,len(seq)-2):
            pam=oriented[i:i+3]
            if len(pam)!=3 or pam[1:]!='GG':continue
            guide=oriented[i-20:i]
            gc=(guide.count('G')+guide.count('C'))/20
            if not 0.3<=gc<=0.8:continue
            low_conf='TTTT' in guide or any(c*5 in guide for c in 'ACGT')
            start=i-20 if strand=='+' else len(seq)-(i+3)
            arr.append({'strand':strand,'guide_5to3':guide,'pam':pam,'target_start_1based':start+1,
                        'gc_percent':round(gc*100,1),'polyT_or_repeat_flag':low_conf})
    # Sort by simple midpoint GC first, not claimed calibrated cleavage efficiency.
    arr.sort(key=lambda z:(z['polyT_or_repeat_flag'],abs(z['gc_percent']-50),z['target_start_1based']))
    return {'sequence_length':len(seq),'all_local_ngg_candidates':len(arr),'rows':arr[:cap(tier,20,150)],
       'notes':['PAM scanning for SpCas9 NGG only. No genome-wide off-target screening, cleavage efficiency estimate, patient-specific interpretation or safety qualification.']}

def variant(d,tier):
    from Bio.Align import substitution_matrices
    a=protein(d['primary'],cap(tier,2000,12000));b=protein(d.get('secondary',''),cap(tier,2000,12000))
    if len(a)!=len(b):raise InputError('Reference and variant sequences must have equal lengths (substitutions only).')
    matrix=substitution_matrices.load('BLOSUM62');charge={'D':-1,'E':-1,'K':1,'R':1}
    diffs=[]
    for idx,(x,y) in enumerate(zip(a,b),1):
        if x==y:continue
        changes=[]
        if charge.get(x,0)!=charge.get(y,0):changes.append('charge category changed')
        if x in 'PGC' or y in 'PGC':changes.append('Pro/Gly/Cys substitution: inspect structural context')
        diffs.append({'position_1based':idx,'reference':x,'alternative':y,
                      'blosum62_substitution_score':int(matrix[x,y]),'heuristic_flags':changes})
    if len(diffs)>cap(tier,30,300):raise InputError('Too many substitutions for this plan.')
    return {'sequence_length':len(a),'substitution_count':len(diffs),'sequence_identity_percent':round(100*(len(a)-len(diffs))/len(a),3),
      'rows':diffs,'notes':['BLOSUM62 represents evolutionary substitution preferences, NOT clinical pathogenicity, protein stability, binding affinity or personalized medical advice. No indel alignment is performed.']}

def restriction(d,tier):
    from Bio.Restriction import RestrictionBatch
    from Bio.Seq import Seq
    seq=dna(d['primary'],cap(tier,3000,18000))
    free=['EcoRI','BamHI','HindIII','XhoI','PstI','NotI','NheI','NdeI']
    more=['BglII','NcoI','MluI','SalI','SpeI','SacI','KpnI','XbaI','EcoRV','SmaI','HpaI','BsaI']
    enzymes=free+(more if tier=='PRO' else [])
    batch=RestrictionBatch(enzymes)
    hitmap=batch.search(Seq(seq),linear=True)
    rows=[{'enzyme':str(e),'recognition_site':str(e.site),'cut_positions_1based':pos[:60],
           'cut_count':len(pos)} for e,pos in hitmap.items()]
    rows.sort(key=lambda x:(-x['cut_count'],x['enzyme']))
    return {'sequence_length':len(seq),'enzyme_count':len(enzymes),'rows':rows,
      'notes':['Biopython restriction-site mapping for linear double-stranded DNA. Cleavage efficiency, methylation sensitivity and reaction buffers are not modeled.']}

HANDLERS={'formula_mass':formula_mass,'functional_groups':functional_groups,'esol_estimator':esol,
 'ligand_efficiency':ligand_efficiency,'compound_cleanup':cleanup,'dna_quality':dna_quality,'orf_finder':orf,
 'crispr_guide':crispr,'variant_compare':variant,'restriction_map':restriction}

def analyze(payload):
    if not isinstance(payload,dict):raise InputError('Expected JSON object.')
    tid=payload.get('tool');tier=payload.get('tier')
    if tid not in HANDLERS or tier not in ('FREE','PRO'):raise InputError('Unknown tool or tier.')
    inp=payload.get('input')
    if not isinstance(inp,dict):raise InputError('Expected input object.')
    if set(inp)-{'primary','secondary','mode'}:raise InputError('Unexpected input keys.')
    for k in ('primary','secondary'):
        if not isinstance(inp.get(k,''),str) or len(inp.get(k,''))>30000:raise InputError('Invalid input length.')
    return {'tool':tid,'tool_name':TOOLS[tid],'tier':tier,
            'method_type':'established method / explicitly indicated heuristic',
            'result':HANDLERS[tid](inp,tier)}

if __name__=='__main__':
    try:
        payload=json.load(sys.stdin);data=analyze(payload)
        print(json.dumps({'ok':True,'result':data},ensure_ascii=True,separators=(',',':'),allow_nan=False))
    except (InputError,ValueError,ImportError,RuntimeError,KeyError,OverflowError) as e:
        print(json.dumps({'ok':False,'error':str(e)[:220]}))
        sys.exit(2)

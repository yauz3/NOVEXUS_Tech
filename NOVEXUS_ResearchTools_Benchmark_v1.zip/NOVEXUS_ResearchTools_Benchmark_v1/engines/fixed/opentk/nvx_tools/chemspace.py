"""T03 · Scaffold & Chemical Space Explorer.

Bemis–Murcko scaffold frequencies, property distributions and a 2D PCA map of
standardised physicochemical descriptors.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path

from .common import Result, ToolError, mol_from_smiles, parse_smiles_list, r3, table

VERSION = "1.0.0"
MAX_FREE = 300
DESC = ["MW", "WLOGP", "TPSA", "HBD", "HBA", "RotB", "Rings", "AromRings", "Fsp3", "HeavyAtoms"]


def descriptors(mol):
    from rdkit.Chem import Crippen, Descriptors, Lipinski, rdMolDescriptors

    return [Descriptors.MolWt(mol), Crippen.MolLogP(mol), rdMolDescriptors.CalcTPSA(mol), Lipinski.NumHDonors(mol),
            Lipinski.NumHAcceptors(mol), rdMolDescriptors.CalcNumRotatableBonds(mol), rdMolDescriptors.CalcNumRings(mol),
            rdMolDescriptors.CalcNumAromaticRings(mol), rdMolDescriptors.CalcFractionCSP3(mol), mol.GetNumHeavyAtoms()]


def run(params: dict, workdir: Path) -> Result:
    import numpy as np
    from rdkit import Chem
    from rdkit.Chem.Scaffolds import MurckoScaffold

    generic = bool(params.get("generic_scaffolds", False))
    mols = parse_smiles_list(params.get("molecules", ""), MAX_FREE)
    names, smis, X, scaffolds, failed = [], [], [], [], []
    for smi, name in mols:
        try:
            mol = mol_from_smiles(smi)
        except ToolError as exc:
            failed.append(f"{name}: {exc}")
            continue
        core = MurckoScaffold.GetScaffoldForMol(mol)
        if generic and core.GetNumAtoms():
            core = MurckoScaffold.MakeScaffoldGeneric(core)
        scaf = Chem.MolToSmiles(core) if core.GetNumAtoms() else "(acyclic)"
        names.append(name)
        smis.append(Chem.MolToSmiles(mol))
        X.append(descriptors(mol))
        scaffolds.append(scaf)
    if len(names) < 3:
        raise ToolError("At least three valid molecules are needed for a chemical-space analysis.")

    X = np.asarray(X, dtype=float)
    mu, sd = X.mean(axis=0), X.std(axis=0)
    sd[sd == 0] = 1.0
    Z = (X - mu) / sd
    U, S, Vt = np.linalg.svd(Z - Z.mean(axis=0), full_matrices=False)
    pcs = (Z - Z.mean(axis=0)) @ Vt[:2].T
    var = (S ** 2) / max(1e-12, (S ** 2).sum())

    counts = Counter(scaffolds)
    top = [s for s, _ in counts.most_common(8)]
    members = defaultdict(list)
    for n, s in zip(names, scaffolds):
        members[s].append(n)

    res = Result()
    scaf_rows = [[i + 1, s, c, r3(100 * c / len(names), 1), ", ".join(members[s][:6]) + ("…" if c > 6 else "")]
                 for i, (s, c) in enumerate(counts.most_common())]
    stat_rows = [[d, r3(X[:, j].min(), 2), r3(np.median(X[:, j]), 2), r3(X[:, j].mean(), 2), r3(X[:, j].max(), 2)] for j, d in enumerate(DESC)]
    loading_rows = [[d, r3(Vt[0, j]), r3(Vt[1, j])] for j, d in enumerate(DESC)]
    points = []
    for i, n in enumerate(names):
        group = top.index(scaffolds[i]) if scaffolds[i] in top else -1
        points.append({"x": r3(pcs[i, 0]), "y": r3(pcs[i, 1]), "label": n, "group": group})

    res.summary = {
        "headline": [
            {"label": "Molecules", "value": len(names)},
            {"label": "Unique scaffolds", "value": len(counts)},
            {"label": "Scaffold diversity (unique / molecules)", "value": r3(len(counts) / len(names), 2)},
            {"label": "Singleton scaffolds", "value": sum(1 for c in counts.values() if c == 1)},
            {"label": "PC1 + PC2 variance", "value": f"{r3(100 * (var[0] + var[1]), 1)} %"},
        ],
        "charts": [{"type": "scatter", "title": "Chemical space (PCA of 10 standardised descriptors)",
                    "x_label": f"PC1 ({r3(100 * var[0], 1)} %)", "y_label": f"PC2 ({r3(100 * var[1], 1)} %)",
                    "points": points, "legend": top}],
        "tables": [
            table("Scaffold frequency" + (" (generic)" if generic else ""), ["Rank", "Scaffold SMILES", "Count", "%", "Examples"], scaf_rows),
            table("Property distribution", ["Descriptor", "Min", "Median", "Mean", "Max"], stat_rows),
            table("PCA loadings", ["Descriptor", "PC1", "PC2"], loading_rows),
        ],
        "notes": ["Colours mark the eight most frequent scaffolds; grey points belong to rarer scaffolds."],
    }
    if failed:
        res.summary["warnings"] = failed
    res.add_csv("chemical_space.csv", ["name", "smiles", "scaffold", "pc1", "pc2"] + DESC,
                [[n, s, sc, r3(pcs[i, 0], 4), r3(pcs[i, 1], 4)] + [r3(v, 4) for v in X[i]] for i, (n, s, sc) in enumerate(zip(names, smis, scaffolds))])
    res.add_csv("scaffolds.csv", ["rank", "scaffold", "count", "percent", "members"],
                [[i + 1, s, c, r3(100 * c / len(names), 2), ";".join(members[s])] for i, (s, c) in enumerate(counts.most_common())])
    return res

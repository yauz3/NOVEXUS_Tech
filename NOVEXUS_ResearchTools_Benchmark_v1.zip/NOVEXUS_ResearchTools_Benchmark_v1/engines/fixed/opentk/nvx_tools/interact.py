"""T06 · Protein–Ligand Interaction Profiler (Novexus geometric engine).

Works on heavy-atom crystal/complex structures without explicit hydrogens.
Detected contact classes: potential hydrogen bonds, hydrophobic contacts,
potential salt bridges, π-stacking (parallel / T-shaped), cation–π, halogen
bonds and metal coordination. Rule details: METHODS_INTERNAL_TR.md.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict
from pathlib import Path

from .common import COMMON_ADDITIVES, METALS, WATER, Result, ToolError, fetch_structure, polymer_het_residues, r3, table

VERSION = "1.0.0"

PROT_POLAR = {
    "N", "O", "OXT", "OG", "OG1", "OH", "ND1", "ND2", "NE", "NE1", "NE2", "NH1", "NH2", "NZ", "OD1", "OD2", "OE1", "OE2", "SG", "SD",
}
POS_ATOMS = {("LYS", "NZ"), ("ARG", "NH1"), ("ARG", "NH2"), ("ARG", "NE")}
NEG_ATOMS = {("ASP", "OD1"), ("ASP", "OD2"), ("GLU", "OE1"), ("GLU", "OE2")}
HYDROPHOBIC_SC = {
    "ALA": {"CB"}, "VAL": {"CB", "CG1", "CG2"}, "LEU": {"CB", "CG", "CD1", "CD2"}, "ILE": {"CB", "CG1", "CG2", "CD1"},
    "MET": {"CB", "CG", "CE"}, "PHE": {"CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ"}, "TRP": {"CB", "CG", "CD2", "CE3", "CZ2", "CZ3", "CH2"},
    "PRO": {"CB", "CG", "CD"}, "TYR": {"CB", "CG", "CD1", "CD2", "CE1", "CE2"}, "CYS": {"CB"}, "THR": {"CG2"}, "LYS": {"CB", "CG", "CD"},
    "ARG": {"CB", "CG"}, "GLU": {"CB", "CG"}, "GLN": {"CB", "CG"},
}
AROMATIC_RINGS = {
    "PHE": [("CG", "CD1", "CD2", "CE1", "CE2", "CZ")], "TYR": [("CG", "CD1", "CD2", "CE1", "CE2", "CZ")],
    "TRP": [("CD2", "CE2", "CE3", "CZ2", "CZ3", "CH2"), ("CG", "CD1", "NE1", "CE2", "CD2")], "HIS": [("CG", "ND1", "CD2", "CE1", "NE2")],
}
CATION_ATOMS = {("LYS", "NZ"), ("ARG", "CZ")}


class Atom:
    __slots__ = ("rec", "name", "resn", "chain", "resi", "elem", "xyz", "line")

    def __init__(self, line: str):
        self.line = line
        self.rec = line[:6].strip()
        self.name = line[12:16].strip()
        self.resn = line[17:20].strip()
        self.chain = line[21:22].strip()
        self.resi = line[22:27].strip()
        self.xyz = (float(line[30:38]), float(line[38:46]), float(line[46:54]))
        elem = line[76:78].strip().upper() if len(line) >= 78 else ""
        if not elem:
            elem = re.sub(r"[^A-Z]", "", self.name.upper())[:1]
        self.elem = elem

    @property
    def res_label(self) -> str:
        return f"{self.resn}{self.resi}" + (f":{self.chain}" if self.chain else "")


def dist(a, b) -> float:
    return math.dist(a, b)


def _parse(data: bytes):
    atoms = []
    for raw in data.decode("utf-8", "replace").splitlines():
        if raw.startswith("ENDMDL"):
            break
        if raw.startswith(("ATOM  ", "HETATM")) and raw[16:17] in (" ", "A"):
            try:
                atoms.append(Atom(raw))
            except ValueError:
                continue
    if not atoms:
        raise ToolError("No atoms found in this structure.")
    return atoms


def choose_ligand(atoms, wanted: str, chain: str | None):
    groups = defaultdict(list)
    for a in atoms:
        if a.rec == "HETATM" and a.resn not in WATER and a.elem != "H":
            groups[(a.resn, a.chain, a.resi)].append(a)
    if not groups:
        raise ToolError("This structure contains no ligand (HETATM) to profile.")
    candidates = []
    for key, members in groups.items():
        resn, ch, _ = key
        if wanted != "AUTO" and resn != wanted:
            continue
        if chain and ch != chain:
            continue
        if wanted == "AUTO" and (resn in METALS or resn in COMMON_ADDITIVES or len(members) < 6):
            continue
        candidates.append((len(members), key, members))
    if not candidates:
        found = sorted({k[0] for k in groups})
        raise ToolError("Ligand not found. HET groups in this entry: " + ", ".join(found[:20]))
    candidates.sort(key=lambda t: -t[0])
    return candidates[0][1], candidates[0][2], [c[1] for c in candidates]


def _ring_geometry(points):
    import numpy as np

    P = np.asarray(points)
    c = P.mean(axis=0)
    _, s, vt = np.linalg.svd(P - c)
    normal = vt[2]
    planarity = s[2] / math.sqrt(len(points))
    return tuple(c), tuple(normal), planarity


def ligand_chemistry(lig_atoms):
    """Connectivity, aromatic rings and simple functional classes from coordinates."""
    from rdkit import Chem

    block = "\n".join(a.line for a in lig_atoms) + "\nEND\n"
    mol = Chem.MolFromPDBBlock(block, sanitize=False, removeHs=False, proximityBonding=True)
    rings, carboxylate_o, basic_n, polar_c = [], set(), set(), set()
    if mol is None or mol.GetNumAtoms() != len(lig_atoms):
        return rings, carboxylate_o, basic_n, polar_c
    Chem.FastFindRings(mol)
    for ring in mol.GetRingInfo().AtomRings():
        if len(ring) in (5, 6):
            pts = [lig_atoms[i].xyz for i in ring]
            elems = {lig_atoms[i].elem for i in ring}
            if elems <= {"C", "N", "O", "S"}:
                c, n, planarity = _ring_geometry(pts)
                if planarity < 0.08:
                    rings.append({"atoms": ring, "centroid": c, "normal": n})
    aromatic_atoms = {i for r in rings for i in r["atoms"]}
    for atom in mol.GetAtoms():
        i = atom.GetIdx()
        el = lig_atoms[i].elem
        nbrs = [n.GetIdx() for n in atom.GetNeighbors()]
        nb_el = [lig_atoms[j].elem for j in nbrs]
        if el == "C" and any(e in ("N", "O", "S", "P") for e in nb_el):
            polar_c.add(i)
        if el == "O" and len(nbrs) == 1:
            centre = nbrs[0]
            c_el = lig_atoms[centre].elem
            o_terminal = [j for j in (n.GetIdx() for n in mol.GetAtomWithIdx(centre).GetNeighbors())
                          if lig_atoms[j].elem == "O" and mol.GetAtomWithIdx(j).GetDegree() == 1]
            if (c_el == "C" and len(o_terminal) == 2) or (c_el in ("P", "S") and len(o_terminal) >= 2):
                carboxylate_o.add(i)
        if el == "N" and i not in aromatic_atoms:
            # amide-like nitrogen if any neighbouring carbon carries a terminal O
            amide = False
            for j in nbrs:
                if lig_atoms[j].elem == "C":
                    for k in mol.GetAtomWithIdx(j).GetNeighbors():
                        if lig_atoms[k.GetIdx()].elem == "O" and k.GetDegree() == 1:
                            amide = True
            if not amide and len(nbrs) <= 3:
                basic_n.add(i)
    return rings, carboxylate_o, basic_n, polar_c


def protein_rings(protein):
    by_res = defaultdict(dict)
    for a in protein:
        if a.resn in AROMATIC_RINGS:
            by_res[(a.resn, a.chain, a.resi)][a.name] = a
    rings = []
    for (resn, ch, resi), names in by_res.items():
        for ring_names in AROMATIC_RINGS[resn]:
            if all(n in names for n in ring_names):
                c, n, _ = _ring_geometry([names[x].xyz for x in ring_names])
                rings.append({"res": names[ring_names[0]].res_label, "centroid": c, "normal": n})
    return rings


def _angle(n1, n2) -> float:
    dot = abs(sum(a * b for a, b in zip(n1, n2)))
    return math.degrees(math.acos(max(-1.0, min(1.0, dot))))


def run(params: dict, workdir: Path) -> Result:
    ident = str(params.get("structure", "")).strip()
    wanted = str(params.get("ligand", "AUTO")).strip().upper() or "AUTO"
    chain = str(params.get("chain", "")).strip().upper() or None
    if not re.fullmatch(r"AUTO|[A-Z0-9]{1,3}", wanted):
        raise ToolError("Ligand must be AUTO or a 1–3 character PDB residue name.")
    if chain and not re.fullmatch(r"[A-Z0-9]", chain):
        raise ToolError("Chain must be a single letter or digit.")
    upload = params.get("_upload_path")
    if upload:
        label, raw = "upload", Path(upload).read_bytes()
    else:
        label, raw = fetch_structure(ident)
    atoms = _parse(raw)
    polymer_het = polymer_het_residues(raw.decode("utf-8", "replace"))
    for a in atoms:
        if a.rec == "HETATM" and (a.resn, a.chain or " ", a.resi) in polymer_het:
            a.rec = "ATOM"  # modified amino acid (MSE, SEP, TPO, ...) belongs to the protein
    if len(atoms) > 60000:
        raise ToolError("Structure is larger than the free-tier limit (60,000 atoms).")
    key, lig, all_cands = choose_ligand(atoms, wanted, chain)
    lig_ids = {id(a) for a in lig}
    protein = [a for a in atoms if a.rec == "ATOM" and a.elem != "H"]
    metals = [a for a in atoms if a.rec == "HETATM" and (a.resn in METALS or a.elem in METALS) and id(a) not in lig_ids]
    waters = [a for a in atoms if a.resn in WATER]
    if not protein:
        raise ToolError("No protein atoms were found around the ligand.")

    # neighbourhood filter for speed
    lx = [a.xyz for a in lig]
    lo = [min(p[i] for p in lx) - 8 for i in range(3)]
    hi = [max(p[i] for p in lx) + 8 for i in range(3)]
    near = [a for a in protein if all(lo[i] <= a.xyz[i] <= hi[i] for i in range(3))]

    rings, carboxylate_o, basic_n, polar_c = ligand_chemistry(lig)
    prings = protein_rings(near)
    hits = []

    def add(kind, res, la, pa, d, extra=""):
        hits.append([kind, res, la, pa, r3(d, 2), extra])

    site = {}
    for li, la in enumerate(lig):
        for pa in near:
            d = dist(la.xyz, pa.xyz)
            if d <= 4.5:
                site[pa.res_label] = min(site.get(pa.res_label, 99), d)
            if d > 4.5:
                continue
            if la.elem in ("N", "O") and pa.name in PROT_POLAR and pa.elem in ("N", "O") and 2.5 <= d <= 3.5:
                add("Hydrogen bond (potential)", pa.res_label, la.name, pa.name, d)
            if (pa.resn, pa.name) in POS_ATOMS and li in carboxylate_o and d <= 4.0:
                add("Salt bridge (potential)", pa.res_label, la.name, pa.name, d)
            if (pa.resn, pa.name) in NEG_ATOMS and li in basic_n and d <= 4.0:
                add("Salt bridge (potential)", pa.res_label, la.name, pa.name, d)
            if la.elem == "C" and li not in polar_c and pa.name in HYDROPHOBIC_SC.get(pa.resn, ()) and d <= 4.0:
                add("Hydrophobic contact", pa.res_label, la.name, pa.name, d)
            if la.elem in ("CL", "BR", "I") and pa.elem in ("O", "N") and d <= 3.5:
                add("Halogen bond (potential)", pa.res_label, la.name, pa.name, d)

    for ring in rings:
        for pr in prings:
            d = dist(ring["centroid"], pr["centroid"])
            if d <= 5.5:
                ang = _angle(ring["normal"], pr["normal"])
                if ang <= 30 and d <= 5.5:
                    add("π-stacking (parallel)", pr["res"], "ring", "ring", d, f"{r3(ang, 0)}°")
                elif ang >= 60 and d <= 5.5:
                    add("π-stacking (T-shaped)", pr["res"], "ring", "ring", d, f"{r3(ang, 0)}°")
        for pa in near:
            if (pa.resn, pa.name) in CATION_ATOMS:
                d = dist(ring["centroid"], pa.xyz)
                if d <= 6.0:
                    add("Cation–π", pa.res_label, "ring", pa.name, d)
    for li in basic_n:
        for pr in prings:
            d = dist(lig[li].xyz, pr["centroid"])
            if d <= 6.0:
                add("Cation–π (ligand cation)", pr["res"], lig[li].name, "ring", d)
    metal_rows = []
    for m in metals:
        for la in lig:
            if la.elem in ("N", "O", "S"):
                d = dist(m.xyz, la.xyz)
                if d <= 2.8:
                    add("Metal coordination", f"{m.resn}{m.resi}", la.name, m.name, d)
        coord = [f"{pa.res_label}/{pa.name} {r3(dist(m.xyz, pa.xyz), 2)}" for pa in protein
                 if pa.elem in ("N", "O", "S") and dist(m.xyz, pa.xyz) <= 2.8]
        if any(dist(m.xyz, la.xyz) <= 6.0 for la in lig):
            metal_rows.append([f"{m.resn}{m.resi}" + (f":{m.chain}" if m.chain else ""), len(coord), "; ".join(coord[:6])])
    near_waters = sum(1 for w in waters if any(dist(w.xyz, la.xyz) <= 3.5 for la in lig))

    # keep the closest contact per (type, residue, ligand atom)
    best = {}
    for h in hits:
        k = (h[0], h[1], h[2])
        if k not in best or h[4] < best[k][4]:
            best[k] = h
    hits = sorted(best.values(), key=lambda h: (h[0], h[4]))
    per_res = defaultdict(lambda: defaultdict(int))
    for h in hits:
        per_res[h[1]][h[0]] += 1
    counts = defaultdict(int)
    for h in hits:
        counts[h[0].split(" (")[0]] += 1

    res = Result()
    lig_label = f"{key[0]} {key[2]}" + (f" chain {key[1]}" if key[1] else "")
    res.summary = {
        "headline": [{"label": "Structure", "value": label}, {"label": "Ligand", "value": lig_label},
                     {"label": "Binding-site residues (≤4.5 Å)", "value": len(site)}] +
                    [{"label": k, "value": v} for k, v in sorted(counts.items())] +
                    ([{"label": "Waters within 3.5 Å", "value": near_waters}] if near_waters else []),
        "tables": [
            table("Interactions", ["Type", "Residue", "Ligand atom", "Protein atom", "Distance (Å)", "Angle"], hits),
            table("Per-residue summary", ["Residue", "Interactions"],
                  [[r, ", ".join(f"{k} ×{v}" for k, v in kinds.items())] for r, kinds in sorted(per_res.items(), key=lambda kv: site.get(kv[0], 9))]),
            table("Binding site (closest heavy-atom distance)", ["Residue", "Distance (Å)"], [[r, r3(d, 2)] for r, d in sorted(site.items(), key=lambda kv: kv[1])], limit=60),
        ],
        "viewer": {"style": "complex", "ligand": key[0], "ligand_resi": key[2], "ligand_chain": key[1], "highlight": list(per_res.keys())[:40]},
        "notes": ["Hydrogen positions are not used: H-bonds and salt bridges are geometric candidates (heavy-atom distances).",
                  "Other ligand candidates in this entry: " + ", ".join(f"{c[0]} {c[2]}{(' ' + c[1]) if c[1] else ''}" for c in all_cands[:8])],
    }
    if metal_rows:
        res.summary["tables"].append(table("Metal ions near the ligand", ["Metal", "Coordinating atoms (≤2.8 Å)", "Partners"], metal_rows))
    res.add_csv("interactions.csv", ["type", "residue", "ligand_atom", "protein_atom", "distance_A", "angle"], hits)
    res.add_csv("binding_site.csv", ["residue", "min_distance_A"], [[r, r3(d, 3)] for r, d in sorted(site.items(), key=lambda kv: kv[1])])
    complex_lines = [a.line for a in atoms if a.rec == "ATOM" or id(a) in lig_ids or a in metals]
    data = ("\n".join(complex_lines) + "\nEND\n").encode()
    res.files["complex.pdb"] = data
    res.viewer = ("pdb", data)
    return res

"""T05 · Binding Pocket Finder (fpocket 4, MIT licence).

Detects cavities, ranks them by fpocket score and druggability, lists lining
residues and proposes a docking box (centre/size) for each pocket.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

from .common import Result, ToolError, clean_pdb_lines, fetch_structure, r3, table

VERSION = "1.0.0"
MAX_POCKETS_SHOWN = 10


def fpocket_binary() -> str:
    here = Path(__file__).resolve().parent.parent / "bin" / "fpocket"
    for cand in (os.environ.get("NVX_FPOCKET"), str(here), shutil.which("fpocket")):
        if cand and Path(cand).is_file() and os.access(cand, os.X_OK):
            return cand
    raise ToolError("Pocket engine (fpocket) is not installed on this worker.")


def parse_info(text: str) -> dict[int, dict[str, float]]:
    pockets: dict[int, dict[str, float]] = {}
    current = None
    for line in text.splitlines():
        m = re.match(r"^Pocket\s+(\d+)\s*:", line)
        if m:
            current = int(m.group(1))
            pockets[current] = {}
            continue
        if current is not None and ":" in line:
            key, _, val = line.partition(":")
            try:
                pockets[current][key.strip()] = float(val.strip())
            except ValueError:
                pass
    return pockets


def pocket_geometry(pqr: Path):
    xs, ys, zs, rs = [], [], [], []
    for line in pqr.read_text().splitlines():
        if line.startswith(("ATOM", "HETATM")):
            parts = line.split()
            try:
                x, y, z, _, rad = map(float, parts[-5:])
            except ValueError:
                continue
            xs.append(x); ys.append(y); zs.append(z); rs.append(rad)
    if not xs:
        return None
    centre = [sum(xs) / len(xs), sum(ys) / len(ys), sum(zs) / len(zs)]
    pad = 4.0
    size = [min(30.0, max(15.0, (max(v) - min(v)) + 2 * pad)) for v in (xs, ys, zs)]
    return centre, size


def lining_residues(atm: Path) -> list[str]:
    seen = []
    for line in atm.read_text().splitlines():
        if line.startswith("ATOM"):
            key = f"{line[17:20].strip()}{line[22:26].strip()}{(':' + line[21]) if line[21].strip() else ''}"
            if key not in seen:
                seen.append(key)
    return seen


def run(params: dict, workdir: Path) -> Result:
    ident = str(params.get("structure", "")).strip()
    chain = str(params.get("chain", "")).strip().upper() or None
    if chain and not re.fullmatch(r"[A-Z0-9]", chain):
        raise ToolError("Chain must be a single letter or digit.")
    upload = params.get("_upload_path")
    if upload:
        label, raw = "upload", Path(upload).read_bytes()
    else:
        label, raw = fetch_structure(ident)
    # Standard fpocket usage: waters removed, hetero groups kept (results then match fpocket reference output).
    lines = clean_pdb_lines(raw, keep_hetero=True, chain=chain)
    pdb = workdir / "protein.pdb"
    pdb.write_text("\n".join(lines) + "\nEND\n")

    proc = subprocess.run([fpocket_binary(), "-f", str(pdb)], cwd=workdir, capture_output=True, text=True, timeout=150)
    out_dir = workdir / "protein_out"
    info = out_dir / "protein_info.txt"
    if proc.returncode != 0 or not info.is_file():
        raise ToolError("Pocket detection failed for this structure.")
    pockets = parse_info(info.read_text())
    if not pockets:
        raise ToolError("No pockets were detected.")

    rows, details = [], []
    ranked = sorted(pockets.items(), key=lambda kv: kv[0])
    for pid, props in ranked[:MAX_POCKETS_SHOWN]:
        geo = pocket_geometry(out_dir / "pockets" / f"pocket{pid}_vert.pqr")
        residues = lining_residues(out_dir / "pockets" / f"pocket{pid}_atm.pdb")
        centre, size = geo if geo else ([None] * 3, [None] * 3)
        drug = props.get("Druggability Score", 0.0)
        rows.append([pid, r3(props.get("Score")), r3(drug), "high" if drug >= 0.7 else "medium" if drug >= 0.4 else "low",
                     r3(props.get("Volume"), 0), int(props.get("Number of Alpha Spheres", 0)), r3(props.get("Hydrophobicity score"), 1),
                     len(residues), ", ".join(str(r3(c, 2)) for c in centre) if geo else "–", " × ".join(str(r3(s, 1)) for s in size) if geo else "–"])
        details.append({"pocket": pid, "properties": props, "lining_residues": residues,
                        "box_center": [r3(c, 3) for c in centre] if geo else None, "box_size": [r3(s, 1) for s in size] if geo else None})

    best = details[0]
    top_drug = max(details, key=lambda d: d["properties"].get("Druggability Score", 0))
    res = Result()
    res.summary = {
        "headline": [
            {"label": "Structure", "value": label + (f" · chain {chain}" if chain else "")},
            {"label": "Pockets detected", "value": len(pockets)},
            {"label": "Top-ranked pocket", "value": f"#{best['pocket']} · score {r3(best['properties'].get('Score'))}"},
            {"label": "Most druggable", "value": f"#{top_drug['pocket']} · {r3(top_drug['properties'].get('Druggability Score'))}"},
        ],
        "tables": [
            table("Ranked pockets", ["Pocket", "fpocket score", "Druggability", "Class", "Volume (Å³)", "α-spheres",
                                     "Hydrophobicity", "Residues", "Box centre (x, y, z)", "Box size (Å)"], rows,
                  note="Box = α-sphere extent + 4 Å padding, clamped to 15–30 Å; use it as a starting point for docking."),
            table(f"Lining residues · pocket {best['pocket']} ({len(best['lining_residues'])})", ["Residues"],
                  [[", ".join(best["lining_residues"][i:i + 8])] for i in range(0, len(best["lining_residues"]), 8)]),
        ],
        "viewer": {"style": "pockets", "pockets": [d["pocket"] for d in details[:5]]},
        "docking_box": {"pocket": best["pocket"], "center": best["box_center"], "size": best["box_size"]},
        "notes": ["Druggability ≥ 0.7 suggests a pocket able to bind drug-like molecules (fpocket druggability model).",
                  "Waters were removed and other hetero groups kept, as in standard fpocket usage; cryptic or induced-fit pockets may be missed."],
    }
    res.add_json("pockets.json", details)
    res.add_csv("pockets.csv", ["pocket", "score", "druggability", "class", "volume", "alpha_spheres", "hydrophobicity",
                                "n_residues", "box_center", "box_size"], rows)
    res.add_text("fpocket_info.txt", info.read_text())
    out_pdb = out_dir / "protein_out.pdb"
    if out_pdb.is_file():
        data = out_pdb.read_bytes()
        res.files["protein_with_pockets.pdb"] = data
        res.viewer = ("pdb", data)
    return res

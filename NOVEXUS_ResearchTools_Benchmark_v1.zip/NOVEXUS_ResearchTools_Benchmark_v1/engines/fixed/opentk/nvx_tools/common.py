"""Shared helpers for the Novexus Open Toolkit (v0.24).

Design rules
- Every tool is a pure function ``run(params, workdir) -> Result``.
- Inputs arrive already validated by WordPress; they are validated again here
  (defence in depth) because the agent must never trust remote input.
- Outbound HTTP only to allowlisted scientific hosts, HTTPS, no redirects,
  bounded size and timeout.
- No visitor identity, IP or secret ever enters results or metadata.
"""
from __future__ import annotations

import hashlib
import io
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

TOOLKIT_VERSION = "0.24.0"

ALLOWED_HOSTS = {
    "files.rcsb.org",
    "data.rcsb.org",
    "alphafold.ebi.ac.uk",
    "rest.uniprot.org",
    "www.ebi.ac.uk",
    "pubchem.ncbi.nlm.nih.gov",
}

MAX_REMOTE_BYTES = 12_000_000
DISCLAIMER = (
    "Research use only (RUO). Computational predictions are not experimental "
    "measurements and must not be used for clinical or diagnostic decisions."
)


class ToolError(Exception):
    """User-facing, sanitised error. Message is shown to the visitor."""


@dataclass
class Result:
    """Container returned by every tool.

    summary  -> small JSON rendered on the web page (<= ~250 kB)
    files    -> relative path -> bytes, packed into the downloadable ZIP
    viewer   -> optional (format, bytes) structure for the 3D viewer
    """

    summary: dict[str, Any] = field(default_factory=dict)
    files: dict[str, bytes] = field(default_factory=dict)
    viewer: tuple[str, bytes] | None = None

    def add_text(self, name: str, text: str) -> None:
        self.files[name] = text.encode("utf-8")

    def add_json(self, name: str, obj: Any) -> None:
        self.files[name] = json.dumps(obj, indent=2, ensure_ascii=False).encode("utf-8")

    def add_csv(self, name: str, columns: list[str], rows: list[list[Any]]) -> None:
        buf = io.StringIO()
        buf.write(",".join(_csv(c) for c in columns) + "\n")
        for row in rows:
            buf.write(",".join(_csv(v) for v in row) + "\n")
        self.files[name] = buf.getvalue().encode("utf-8")


def _csv(value: Any) -> str:
    text = "" if value is None else str(value)
    # Neutralise spreadsheet formula injection.
    if text[:1] in ("=", "+", "-", "@") and not re.fullmatch(r"-?\d+(\.\d+)?([eE]-?\d+)?", text):
        text = "'" + text
    if any(ch in text for ch in [",", '"', "\n"]):
        text = '"' + text.replace('"', '""') + '"'
    return text


def table(title: str, columns: list[str], rows: list[list[Any]], note: str | None = None, limit: int = 200) -> dict:
    block = {"title": title, "columns": columns, "rows": rows[:limit]}
    if len(rows) > limit:
        block["truncated"] = f"Showing {limit} of {len(rows)} rows. The ZIP contains the full table."
    if note:
        block["note"] = note
    return block


def r3(x: Any, nd: int = 3) -> Any:
    try:
        return round(float(x), nd)
    except (TypeError, ValueError):
        return x


# ----------------------------------------------------------------- inputs
SMILES_RE = re.compile(r"^[A-Za-z0-9@+\-\[\]\(\)=#$/\\%.:*]{1,400}$")
NAME_RE = re.compile(r"[^A-Za-z0-9_.\-]+")


def _parses(smi: str) -> bool:
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")
    try:
        return Chem.MolFromSmiles(smi) is not None
    finally:
        RDLogger.EnableLog("rdApp.*")


def parse_smiles_list(text: str, max_items: int) -> list[tuple[str, str]]:
    """Accepts 'SMILES' or 'SMILES name' or 'name,SMILES'-free text lines."""
    if not isinstance(text, str):
        raise ToolError("Molecule list must be text.")
    out: list[tuple[str, str]] = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"[\s,;\t]+", line, maxsplit=1)
        smi = parts[0]
        name = parts[1].strip() if len(parts) > 1 else ""
        # FIX v0.26.1: plain words such as "aspirin" also match SMILES_RE, so the regex alone
        # could not detect "name SMILES" order. Decide by whether RDKit can parse the token.
        first_ok = bool(SMILES_RE.match(smi)) and _parses(smi)
        if not first_ok and len(parts) > 1:
            second = parts[1].strip()
            if SMILES_RE.match(second) and _parses(second):
                smi, name = second, parts[0]
                first_ok = True
        if not SMILES_RE.match(smi):
            raise ToolError(f"Line {len(out) + 1}: not a valid SMILES string.")
        name = NAME_RE.sub("_", name)[:40] or f"mol_{len(out) + 1}"
        out.append((smi, name))
        if len(out) > max_items:
            raise ToolError(f"Free tier accepts at most {max_items} molecules per job.")
    if not out:
        raise ToolError("Enter at least one SMILES string.")
    return out


def mol_from_smiles(smi: str):
    from rdkit import Chem

    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ToolError(f"RDKit could not parse SMILES: {smi[:60]}")
    if mol.GetNumHeavyAtoms() > 150:
        raise ToolError("Molecules larger than 150 heavy atoms are outside the free tier.")
    return mol


FASTA_ALLOWED_PROT = set("ACDEFGHIKLMNPQRSTVWYBXZUO*-")
FASTA_ALLOWED_NUC = set("ACGTUNRYKMSWBDHV-")


def parse_fasta(text: str, max_seqs: int, max_len: int) -> list[tuple[str, str]]:
    if not isinstance(text, str) or not text.strip():
        raise ToolError("Paste at least one sequence.")
    records: list[tuple[str, list[str]]] = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            records.append((NAME_RE.sub("_", line[1:].strip())[:40] or f"seq{len(records) + 1}", []))
        else:
            if not records:
                records.append(("seq1", []))
            records[-1][1].append(re.sub(r"[\s\d]", "", line).upper())
    seqs = [(n, "".join(p)) for n, p in records if "".join(p)]
    if not seqs:
        raise ToolError("No sequence found.")
    if len(seqs) > max_seqs:
        raise ToolError(f"Free tier accepts at most {max_seqs} sequences.")
    for name, seq in seqs:
        if len(seq) > max_len:
            raise ToolError(f"{name}: longer than the free limit of {max_len} residues.")
        bad = set(seq) - FASTA_ALLOWED_PROT - FASTA_ALLOWED_NUC
        if bad:
            raise ToolError(f"{name}: unexpected characters {''.join(sorted(bad))[:10]}.")
    return seqs


def seq_type(seq: str) -> str:
    s = seq.replace("-", "")
    if s and sum(c in "ACGTUN" for c in s) / len(s) > 0.9:
        return "dna"
    return "protein"


PDB_ID_RE = re.compile(r"^[0-9][A-Za-z0-9]{3}$")
UNIPROT_RE = re.compile(r"^([OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9]([A-Z][A-Z0-9]{2}[0-9]){1,2})$")


# ----------------------------------------------------------------- network
def http_get(url: str, timeout: int = 20, accept: str = "*/*", max_bytes: int = MAX_REMOTE_BYTES) -> bytes:
    import requests

    u = urlparse(url)
    if u.scheme != "https" or u.hostname not in ALLOWED_HOSTS or u.port or u.username:
        raise ToolError("Remote data source is not on the Novexus allowlist.")
    try:
        with requests.get(
            url,
            timeout=timeout,
            allow_redirects=False,
            stream=True,
            headers={"Accept": accept, "User-Agent": f"Novexus-Toolkit/{TOOLKIT_VERSION}"},
        ) as r:
            if r.status_code == 404:
                raise ToolError("Identifier not found at the public data source.")
            if r.status_code != 200:
                raise ToolError(f"Public data source answered HTTP {r.status_code}. Try again later.")
            buf = bytearray()
            for chunk in r.iter_content(65536):
                buf.extend(chunk)
                if len(buf) > max_bytes:
                    raise ToolError("Remote file exceeds the free-tier size limit.")
            return bytes(buf)
    except requests.RequestException:
        raise ToolError(f"Could not reach {u.hostname}. The public data source may be down; please try again later.") from None


def http_json(url: str, timeout: int = 20) -> Any:
    return json.loads(http_get(url, timeout=timeout, accept="application/json").decode("utf-8"))


def fetch_structure(identifier: str) -> tuple[str, bytes]:
    """Returns (label, PDB-format bytes) for a PDB ID or UniProt (AlphaFold DB)."""
    ident = identifier.strip()
    if PDB_ID_RE.match(ident):
        data = http_get(f"https://files.rcsb.org/download/{ident.upper()}.pdb", timeout=30)
        if b"ATOM" not in data:
            raise ToolError("This entry has no legacy PDB-format file (very large structures are mmCIF-only).")
        return ident.upper(), data
    up = ident.upper()
    if UNIPROT_RE.match(up):
        meta = http_json(f"https://alphafold.ebi.ac.uk/api/prediction/{up}")
        if not isinstance(meta, list) or not meta or "pdbUrl" not in meta[0]:
            raise ToolError("No AlphaFold DB model is available for this UniProt accession.")
        url = meta[0]["pdbUrl"]
        if urlparse(url).hostname != "alphafold.ebi.ac.uk":
            raise ToolError("Unexpected AlphaFold download location.")
        return f"AF-{up}", http_get(url, timeout=30)
    raise ToolError("Enter a 4-character PDB ID (e.g. 1HSG) or a UniProt accession (e.g. P00533).")


# ----------------------------------------------------------------- PDB helpers
WATER = {"HOH", "WAT", "DOD", "H2O"}
METALS = {"ZN", "MG", "CA", "MN", "FE", "FE2", "CU", "CU1", "CO", "NI", "CD", "HG", "NA", "K", "LI", "SR", "BA", "PT", "AU"}
COMMON_ADDITIVES = {"SO4", "PO4", "GOL", "EDO", "PEG", "ACT", "DMS", "CL", "BR", "IOD", "NO3", "FMT", "MPD", "TRS", "EPE", "MES", "PG4", "1PE", "BME", "ACY", "IMD", "NH4", "SCN", "CIT", "FLC"}


def polymer_het_residues(text: str) -> set[tuple[str, str, str]]:
    """HETATM residues that carry backbone N/CA/C (e.g. MSE, SEP, TPO, PTR): part of the chain."""
    names: dict[tuple[str, str, str], set[str]] = {}
    for raw in text.splitlines():
        if raw.startswith("HETATM"):
            key = (raw[17:20].strip(), raw[21:22], raw[22:27].strip())
            names.setdefault(key, set()).add(raw[12:16].strip())
    return {k for k, v in names.items() if {"N", "CA", "C"} <= v}


def clean_pdb_lines(data: bytes, keep_hetero: bool = False, chain: str | None = None) -> list[str]:
    lines = []
    seen_model = False
    text = data.decode("utf-8", "replace")
    polymer_het = polymer_het_residues(text)
    for raw in text.splitlines():
        rec = raw[:6]
        if rec.startswith("MODEL"):
            if seen_model:
                break
            seen_model = True
            continue
        if rec.startswith("ENDMDL"):
            break
        if rec not in ("ATOM  ", "HETATM"):
            continue
        if chain and raw[21:22].strip() != chain:
            continue
        alt = raw[16:17]
        if alt not in (" ", "A"):
            continue
        resn = raw[17:20].strip()
        if rec == "HETATM" and (resn, raw[21:22], raw[22:27].strip()) in polymer_het:
            raw = "ATOM  " + raw[6:]
        elif rec == "HETATM" and (resn in WATER or not keep_hetero):
            continue
        lines.append(raw.rstrip("\n"))
    if not lines:
        raise ToolError("No usable atoms found (check the chain identifier).")
    if len(lines) > 60000:
        raise ToolError("Structure is larger than the free-tier limit (60,000 atoms).")
    return lines


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def now_utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def software_versions() -> dict[str, str]:
    versions = {"novexus_toolkit": TOOLKIT_VERSION}
    for mod in ("rdkit", "Bio", "numpy", "primer3", "dimorphite_dl", "meeko"):
        try:
            m = __import__(mod)
            versions[mod] = getattr(m, "__version__", "unknown")
        except Exception:  # noqa: BLE001 - optional dependency
            continue
    return versions


def write_workfile(workdir: Path, name: str, data: bytes) -> Path:
    path = workdir / name
    path.write_bytes(data)
    return path

"""T08 · Sequence Alignment (pairwise Needleman–Wunsch / Smith–Waterman, MSA by MAFFT).
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .common import Result, ToolError, parse_fasta, r3, seq_type

VERSION = "1.0.0"
MAX_SEQS = 20
MAX_LEN = 2000


def _aligner(kind: str, mode: str):
    from Bio import Align
    from Bio.Align import substitution_matrices

    al = Align.PairwiseAligner()
    al.mode = mode
    if kind == "protein":
        al.substitution_matrix = substitution_matrices.load("BLOSUM62")
    else:
        al.substitution_matrix = substitution_matrices.load("NUC.4.4")
    al.open_gap_score = -10.0
    al.extend_gap_score = -0.5
    return al


def _stats(a: str, b: str, kind: str):
    from Bio.Align import substitution_matrices

    m = substitution_matrices.load("BLOSUM62") if kind == "protein" else None
    ident = sim = gaps = 0
    for x, y in zip(a, b):
        if x == "-" or y == "-":
            gaps += 1
        elif x == y:
            ident += 1
            sim += 1
        elif m is not None:
            try:
                if m[x][y] > 0:
                    sim += 1
            except (KeyError, IndexError):
                pass
    L = len(a)
    return ident, sim, gaps, L


def _match_line(a: str, b: str, kind: str) -> str:
    from Bio.Align import substitution_matrices

    m = substitution_matrices.load("BLOSUM62") if kind == "protein" else None
    out = []
    for x, y in zip(a, b):
        if x == y and x != "-":
            out.append("|")
        elif x != "-" and y != "-" and m is not None:
            try:
                out.append(":" if m[x][y] > 0 else ".")
            except (KeyError, IndexError):
                out.append(" ")
        else:
            out.append(" ")
    return "".join(out)


def _blocks(rows: list[tuple[str, str]], width: int = 60) -> str:
    name_w = max(len(n) for n, _ in rows) + 2
    L = len(rows[0][1])
    out = []
    for i in range(0, L, width):
        for n, s in rows:
            out.append(f"{n:<{name_w}}{s[i:i + width]}")
        out.append("")
    return "\n".join(out)


def pairwise(seqs, mode: str):
    (n1, s1), (n2, s2) = seqs
    kind = "protein" if seq_type(s1) == "protein" or seq_type(s2) == "protein" else "dna"
    al = _aligner(kind, mode)
    aln = al.align(s1.replace("-", ""), s2.replace("-", ""))[0]
    a, b = aln[0], aln[1]
    ident, sim, gaps, L = _stats(a, b, kind)
    text = _blocks([(n1, a), ("", _match_line(a, b, kind)), (n2, b)])
    head = [{"label": "Mode", "value": "global (Needleman–Wunsch)" if mode == "global" else "local (Smith–Waterman)"},
            {"label": "Score", "value": r3(aln.score, 1)}, {"label": "Length", "value": L},
            {"label": "Identity", "value": f"{ident}/{L} ({r3(100 * ident / L, 1)} %)"},
            {"label": "Gaps", "value": f"{gaps}/{L} ({r3(100 * gaps / L, 1)} %)"}]
    if kind == "protein":
        head.insert(4, {"label": "Similarity", "value": f"{sim}/{L} ({r3(100 * sim / L, 1)} %)"})
    return head, text, kind


def msa(seqs, workdir: Path):
    exe = shutil.which("mafft")
    if not exe:
        raise ToolError("Multiple alignment engine (MAFFT) is not installed on this worker.")
    fin = workdir / "input.fasta"
    fin.write_text("".join(f">{n}\n{s.replace('-', '')}\n" for n, s in seqs))
    proc = subprocess.run([exe, "--auto", "--quiet", "--thread", "1", str(fin)], capture_output=True, text=True, timeout=150)
    if proc.returncode != 0 or ">" not in proc.stdout:
        raise ToolError("MAFFT alignment failed.")
    aligned, cur = [], None
    for line in proc.stdout.splitlines():
        if line.startswith(">"):
            cur = [line[1:].strip(), []]
            aligned.append(cur)
        elif cur:
            cur[1].append(line.strip().upper())
    return [(n, "".join(p)) for n, p in aligned], proc.stdout


def run(params: dict, workdir: Path) -> Result:
    mode = params.get("mode", "auto")
    if mode not in ("auto", "global", "local", "msa"):
        raise ToolError("Unknown alignment mode.")
    seqs = parse_fasta(str(params.get("sequences", "")), MAX_SEQS, MAX_LEN)
    if len(seqs) < 2:
        raise ToolError("Provide at least two sequences.")
    res = Result()
    if mode in ("global", "local") or (mode == "auto" and len(seqs) == 2):
        if len(seqs) != 2:
            raise ToolError("Pairwise mode needs exactly two sequences; choose MSA for more.")
        head, text, kind = pairwise(seqs, "local" if mode == "local" else "global")
        res.summary = {"headline": head, "alignment": text,
                       "notes": [f"Scoring: {'BLOSUM62' if kind == 'protein' else 'NUC.4.4'}, gap open −10, extend −0.5 (EMBOSS-style defaults)."]}
        res.add_text("pairwise_alignment.txt", text)
        return res

    aligned, fasta_out = msa(seqs, workdir)
    names = [n for n, _ in aligned]
    L = len(aligned[0][1])
    matrix = []
    for _, a in aligned:
        row = []
        for _, b in aligned:
            pairs = [(x, y) for x, y in zip(a, b) if x != "-" and y != "-"]
            row.append(r3(100 * sum(x == y for x, y in pairs) / len(pairs), 1) if pairs else 0.0)
        matrix.append(row)
    consensus, conserved = [], 0
    for i in range(L):
        col = [s[i] for _, s in aligned]
        res_col = [c for c in col if c != "-"]
        if res_col and len(res_col) == len(col) and len(set(res_col)) == 1:
            consensus.append("*")
            conserved += 1
        else:
            consensus.append(" ")
    text = _blocks(aligned + [("consensus", "".join(consensus))])
    res.summary = {
        "headline": [{"label": "Sequences", "value": len(aligned)}, {"label": "Alignment length", "value": L},
                     {"label": "Fully conserved columns", "value": f"{conserved} ({r3(100 * conserved / L, 1)} %)"},
                     {"label": "Engine", "value": "MAFFT --auto"}],
        "alignment": text,
        "charts": [{"type": "heatmap", "title": "Percent identity matrix", "labels": names, "values": matrix, "max": 100}],
        "notes": ["'*' marks columns identical in all sequences. Percent identity ignores gap positions."],
    }
    res.add_text("msa.fasta", fasta_out)
    res.add_text("msa_blocks.txt", text)
    res.add_csv("percent_identity.csv", ["name"] + names, [[n] + row for n, row in zip(names, matrix)])
    return res

"""Novexus Open Toolkit v0.24 — ten lightweight drug-discovery / bioinformatics tools.

The registry is the single source of truth for tool ids, versions and wall-time
caps. WordPress validates the same ids; unknown ids are rejected on both sides.
"""
from __future__ import annotations

import importlib

# id: (module, wall-time seconds, needs network)
REGISTRY = {
    "admet": ("admet", 90, False),
    "similarity": ("similarity", 90, False),
    "chemspace": ("chemspace", 90, False),
    "ligprep": ("ligprep", 150, False),
    "pocket": ("pocket", 180, True),
    "interact": ("interact", 120, True),
    "protparam": ("protparam", 60, True),
    "align": ("align", 180, False),
    "target": ("target", 120, True),
    "primer": ("primer", 60, False),
}


def load(tool_id: str):
    if tool_id not in REGISTRY:
        raise KeyError(tool_id)
    return importlib.import_module(f"nvx_tools.{REGISTRY[tool_id][0]}")

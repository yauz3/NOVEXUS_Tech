"""T07 · Protein Sequence Analyzer (ProtParam-style).

Molecular weight, theoretical pI, net charge at pH 7.4, extinction coefficients,
instability index, aliphatic index, GRAVY, aromaticity, composition and a
Kyte–Doolittle hydropathy profile.
"""
from __future__ import annotations

from pathlib import Path

from .common import UNIPROT_RE, Result, ToolError, http_get, parse_fasta, r3, seq_type, table

VERSION = "1.0.0"
MAX_SEQS = 10
MAX_LEN = 5000
KD = {"A": 1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C": 2.5, "Q": -3.5, "E": -3.5, "G": -0.4, "H": -3.2, "I": 4.5, "L": 3.8,
      "K": -3.9, "M": 1.9, "F": 2.8, "P": -1.6, "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V": 4.2}


def _fetch_uniprot(acc: str) -> str:
    return http_get(f"https://rest.uniprot.org/uniprotkb/{acc}.fasta", timeout=20, accept="text/plain", max_bytes=200_000).decode()


def analyse(name: str, seq: str) -> dict:
    from Bio.SeqUtils.ProtParam import ProteinAnalysis

    clean = "".join(c for c in seq if c in KD)
    if len(clean) < 5:
        raise ToolError(f"{name}: needs at least 5 standard amino acids.")
    pa = ProteinAnalysis(clean)
    n = len(clean)
    comp = {aa: clean.count(aa) for aa in sorted(KD)}
    mole = {aa: 100.0 * c / n for aa, c in comp.items()}
    aliphatic = mole["A"] + 2.9 * mole["V"] + 3.9 * (mole["I"] + mole["L"])
    ext_red, ext_cys = pa.molar_extinction_coefficient()
    mw = pa.molecular_weight()
    helix, turn, sheet = pa.secondary_structure_fraction()
    instab = pa.instability_index()
    window = 9 if n >= 9 else n
    profile = []
    for i in range(0, n - window + 1):
        seg = clean[i:i + window]
        profile.append(sum(KD[c] for c in seg) / window)
    tm_like = [i + window // 2 + 1 for i in range(0, max(0, n - 19 + 1)) if sum(KD[c] for c in clean[i:i + 19]) / 19 >= 1.6]
    segments = []
    for pos in tm_like:
        if segments and pos - segments[-1][1] <= 1:
            segments[-1][1] = pos
        else:
            segments.append([pos, pos])
    return {
        "name": name, "length": n, "skipped_nonstandard": len(seq.replace("-", "").replace("*", "")) - n,
        "mw_da": r3(mw, 2), "pi": r3(pa.isoelectric_point(), 2), "charge_ph74": r3(pa.charge_at_pH(7.4), 2),
        "ext_coeff_reduced": ext_red, "ext_coeff_cystines": ext_cys,
        "abs01_reduced": r3(ext_red / mw, 3) if mw else None, "abs01_cystines": r3(ext_cys / mw, 3) if mw else None,
        "instability_index": r3(instab, 2), "stable": instab < 40, "aliphatic_index": r3(aliphatic, 2),
        "gravy": r3(pa.gravy(), 3), "aromaticity": r3(pa.aromaticity(), 3),
        "helix_frac": r3(helix, 3), "turn_frac": r3(turn, 3), "sheet_frac": r3(sheet, 3),
        "composition": comp, "mole_percent": {k: r3(v, 2) for k, v in mole.items()},
        "hydropathy": [r3(v, 2) for v in profile], "hydropathy_window": window,
        "hydrophobic_segments": [f"{a - 9}-{b + 9}" for a, b in segments],
    }


def run(params: dict, workdir: Path) -> Result:
    text = str(params.get("sequences", "")).strip()
    acc = str(params.get("uniprot", "")).strip().upper()
    if acc:
        if not UNIPROT_RE.match(acc):
            raise ToolError("Invalid UniProt accession.")
        text = _fetch_uniprot(acc)
    seqs = parse_fasta(text, MAX_SEQS, MAX_LEN)
    results, warnings = [], []
    for name, seq in seqs:
        if seq_type(seq) == "dna":
            warnings.append(f"{name}: looks like a nucleotide sequence; skipped (use the Primer or Alignment tool).")
            continue
        try:
            results.append(analyse(name, seq))
        except ToolError as exc:
            warnings.append(str(exc))
    if not results:
        raise ToolError("No protein sequence could be analysed.")

    res = Result()
    main = [[r["name"], r["length"], r["mw_da"], r["pi"], r["charge_ph74"], r["ext_coeff_reduced"], r["ext_coeff_cystines"],
             r["instability_index"], "stable" if r["stable"] else "unstable", r["aliphatic_index"], r["gravy"], r["aromaticity"]] for r in results]
    first = results[0]
    comp_rows = [[aa, first["composition"][aa], first["mole_percent"][aa]] for aa in sorted(KD, key=lambda a: -first["composition"][a])]
    res.summary = {
        "headline": [{"label": "Sequences", "value": len(results)}, {"label": f"{first['name']} length", "value": f"{first['length']} aa"},
                     {"label": "Molecular weight", "value": f"{r3(first['mw_da'] / 1000, 2)} kDa"},
                     {"label": "Theoretical pI", "value": first["pi"]},
                     {"label": "Instability index", "value": f"{first['instability_index']} ({'stable' if first['stable'] else 'unstable'})"}],
        "tables": [
            table("Physicochemical parameters", ["Name", "Length", "MW (Da)", "pI", "Charge pH 7.4", "ε280 reduced", "ε280 cystines",
                                                 "Instability", "Class", "Aliphatic idx", "GRAVY", "Aromaticity"], main,
                  note="ε280 in M⁻¹cm⁻¹ (Pace et al.); instability index < 40 predicts a stable protein in vitro (Guruprasad et al.)."),
            table(f"Amino-acid composition · {first['name']}", ["Residue", "Count", "Mol %"], comp_rows),
        ],
        "charts": [{"type": "line", "title": f"Kyte–Doolittle hydropathy · {first['name']} (window {first['hydropathy_window']})",
                    "x_label": "Residue", "y_label": "Hydropathy", "values": first["hydropathy"], "threshold": 1.6}],
        "notes": ["Segments with a 19-residue mean hydropathy ≥ 1.6 are potential transmembrane helices: " +
                  (", ".join(first["hydrophobic_segments"]) or "none detected") + "."],
    }
    if warnings:
        res.summary["warnings"] = warnings
    res.add_json("protparam.json", results)
    res.add_csv("protparam.csv", ["name", "length", "mw_da", "pi", "charge_ph74", "ext_reduced", "ext_cystines", "instability", "aliphatic", "gravy", "aromaticity"],
                [[r["name"], r["length"], r["mw_da"], r["pi"], r["charge_ph74"], r["ext_coeff_reduced"], r["ext_coeff_cystines"],
                  r["instability_index"], r["aliphatic_index"], r["gravy"], r["aromaticity"]] for r in results])
    return res

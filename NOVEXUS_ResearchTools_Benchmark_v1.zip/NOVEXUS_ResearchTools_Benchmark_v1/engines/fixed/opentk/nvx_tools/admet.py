"""T01 · ADMET & Drug-likeness Profiler.

Physicochemical descriptors, five classic drug-likeness rule sets, lead-likeness,
QED, synthetic accessibility, PAINS/Brenk structural alerts, an absorption/CNS
property map and the proprietary Novexus Developability Index (NDI, beta).

NDI internals are documented only in METHODS_INTERNAL_TR.md (not published).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from .common import Result, ToolError, mol_from_smiles, parse_smiles_list, r3, table

VERSION = "1.0.0"
MAX_FREE = 50

_sascorer = None
_catalogs = None


def _sa(mol):
    global _sascorer
    if _sascorer is None:
        from rdkit.Chem import RDConfig

        sys.path.append(os.path.join(RDConfig.RDContribDir, "SA_Score"))
        import sascorer  # type: ignore

        _sascorer = sascorer
    return _sascorer.calculateScore(mol)


def _alerts(mol):
    global _catalogs
    from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams

    if _catalogs is None:
        _catalogs = {}
        for label, cat in (("PAINS", FilterCatalogParams.FilterCatalogs.PAINS), ("Brenk", FilterCatalogParams.FilterCatalogs.BRENK)):
            p = FilterCatalogParams()
            p.AddCatalog(cat)
            _catalogs[label] = FilterCatalog(p)
    out = {}
    for label, catalog in _catalogs.items():
        out[label] = [e.GetDescription() for e in catalog.GetMatches(mol)]
    return out


def _ndi(qed, sa, rule_pass, n_alerts, absorption_ok):
    sa_term = max(0.0, min(1.0, 1.0 - (sa - 1.0) / 9.0))
    alert_term = 1.0 - min(n_alerts, 3) / 3.0
    score = 0.30 * qed + 0.20 * sa_term + 0.20 * rule_pass + 0.15 * alert_term + 0.15 * (1.0 if absorption_ok else 0.0)
    return round(100.0 * max(0.0, min(1.0, score)), 1)


def profile(smi: str, name: str) -> dict:
    from rdkit import Chem
    from rdkit.Chem import Crippen, Descriptors, Lipinski, QED, rdMolDescriptors

    mol = mol_from_smiles(smi)
    mw = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)  # Wildman–Crippen (WLOGP-type)
    mr = Crippen.MolMR(mol)
    tpsa = rdMolDescriptors.CalcTPSA(mol)
    hbd = Lipinski.NumHDonors(mol)
    hba = Lipinski.NumHAcceptors(mol)
    rotb = rdMolDescriptors.CalcNumRotatableBonds(mol)
    rings = rdMolDescriptors.CalcNumRings(mol)
    arom = rdMolDescriptors.CalcNumAromaticRings(mol)
    heavy = mol.GetNumHeavyAtoms()
    atoms_total = Chem.AddHs(mol).GetNumAtoms()
    fsp3 = rdMolDescriptors.CalcFractionCSP3(mol)
    charge = Chem.GetFormalCharge(mol)
    carbons = sum(1 for a in mol.GetAtoms() if a.GetSymbol() == "C")
    hetero = sum(1 for a in mol.GetAtoms() if a.GetSymbol() not in ("C", "H"))
    stereo = len(Chem.FindMolChiralCenters(mol, includeUnassigned=True, useLegacyImplementation=False))
    qed = QED.qed(mol)
    sa = _sa(mol)
    alerts = _alerts(mol)

    lip_viol = sum([mw > 500, logp > 5, hbd > 5, hba > 10])
    rules = {
        "Lipinski (Ro5)": lip_viol <= 1,
        "Veber": rotb <= 10 and tpsa <= 140,
        "Egan": logp <= 5.88 and tpsa <= 131.6,
        "Ghose": 160 <= mw <= 480 and -0.4 <= logp <= 5.6 and 40 <= mr <= 130 and 20 <= atoms_total <= 70,
        "Muegge": 200 <= mw <= 600 and -2 <= logp <= 5 and tpsa <= 150 and rings <= 7 and carbons > 4 and hetero > 1 and rotb <= 15 and hba <= 10 and hbd <= 5,
    }
    lead_like = 250 <= mw <= 350 and logp <= 3.5 and rotb <= 7
    absorption_ok = rules["Egan"]
    cns_likely = tpsa <= 90 and mw <= 450 and 1.0 <= logp <= 4.0 and hbd <= 3
    rule_pass = sum(rules.values()) / len(rules)
    n_alerts = len(alerts["PAINS"]) + len(alerts["Brenk"])
    ndi = _ndi(qed, sa, rule_pass, n_alerts, absorption_ok)
    return {
        "name": name,
        "smiles": Chem.MolToSmiles(mol),
        "formula": rdMolDescriptors.CalcMolFormula(mol),
        "mw": r3(mw, 2), "logp": r3(logp, 2), "mr": r3(mr, 2), "tpsa": r3(tpsa, 1),
        "hbd": hbd, "hba": hba, "rotb": rotb, "rings": rings, "aromatic_rings": arom,
        "heavy_atoms": heavy, "fsp3": r3(fsp3, 2), "formal_charge": charge, "stereocentres": stereo,
        "qed": r3(qed, 3), "sa_score": r3(sa, 2),
        "lipinski_violations": lip_viol,
        "rules": rules, "lead_like": lead_like,
        "absorption_rule": absorption_ok, "cns_heuristic": cns_likely,
        "pains": alerts["PAINS"], "brenk": alerts["Brenk"],
        "ndi": ndi,
    }


def _band(ndi: float) -> str:
    return "favourable" if ndi >= 70 else "moderate" if ndi >= 50 else "challenging"


def run(params: dict, workdir: Path) -> Result:
    mols = parse_smiles_list(params.get("molecules", ""), MAX_FREE)
    profiles = []
    failed = []
    for smi, name in mols:
        try:
            profiles.append(profile(smi, name))
        except ToolError as exc:
            failed.append([name, str(exc)])
    if not profiles:
        raise ToolError("None of the molecules could be parsed. " + (failed[0][1] if failed else ""))

    res = Result()
    rule_names = list(profiles[0]["rules"].keys())
    main_cols = ["Name", "MW", "WLOGP", "TPSA", "HBD", "HBA", "RotB", "QED", "SA", "Ro5 viol.", "Rules passed", "Alerts", "NDI (beta)"]
    main_rows = []
    for p in profiles:
        main_rows.append([
            p["name"], p["mw"], p["logp"], p["tpsa"], p["hbd"], p["hba"], p["rotb"], p["qed"], p["sa_score"],
            p["lipinski_violations"], f"{sum(p['rules'].values())}/{len(rule_names)}",
            len(p["pains"]) + len(p["brenk"]), f"{p['ndi']} · {_band(p['ndi'])}",
        ])
    rule_rows = [[p["name"]] + ["✓" if p["rules"][k] else "✗" for k in rule_names] + ["✓" if p["lead_like"] else "✗", "✓" if p["absorption_rule"] else "✗", "✓" if p["cns_heuristic"] else "✗"] for p in profiles]
    alert_rows = [[p["name"], "PAINS", a] for p in profiles for a in p["pains"]] + [[p["name"], "Brenk", a] for p in profiles for a in p["brenk"]]

    best = max(profiles, key=lambda p: p["ndi"])
    res.summary = {
        "headline": [
            {"label": "Molecules profiled", "value": len(profiles)},
            {"label": "Pass Lipinski (≤1 violation)", "value": sum(p["rules"]["Lipinski (Ro5)"] for p in profiles)},
            {"label": "Structural alerts (any)", "value": sum(1 for p in profiles if p["pains"] or p["brenk"])},
            {"label": "Top NDI", "value": f"{best['ndi']} ({best['name']})"},
        ],
        "tables": [
            table("Drug-likeness overview", main_cols, main_rows),
            table("Rule sets", ["Name"] + rule_names + ["Lead-like", "Absorption rule (Egan)", "CNS heuristic"], rule_rows,
                  note="Rule thresholds follow the original publications. The CNS column is a simple TPSA/MW/logP/HBD heuristic, not a BBB permeability prediction."),
        ],
        "charts": [{
            "type": "scatter", "title": "Absorption / CNS property map", "x_label": "WLOGP (Crippen)", "y_label": "TPSA (Å²)",
            "x_range": [-3, 8], "y_range": [0, 200],
            "boxes": [
                {"x0": -3, "x1": 5.88, "y0": 0, "y1": 131.6, "label": "Egan absorption region", "tone": "soft"},
                {"x0": 1.0, "x1": 4.0, "y0": 0, "y1": 90, "label": "CNS heuristic", "tone": "gold"},
            ],
            "points": [{"x": p["logp"], "y": p["tpsa"], "label": p["name"]} for p in profiles],
        }],
        "notes": [
            "NDI (Novexus Developability Index, beta) is a proprietary 0–100 composite used for triage only; ≥70 favourable, 50–69 moderate, <50 challenging.",
            "SA score: 1 (easy) – 10 (very difficult) synthetic accessibility estimate.",
        ],
    }
    if alert_rows:
        res.summary["tables"].append(table("Structural alerts", ["Name", "Catalogue", "Alert"], alert_rows,
                                           note="Alerts flag substructures associated with assay interference or reactivity; they are not proof of a problem."))
    if failed:
        res.summary["warnings"] = [f"{n}: {e}" for n, e in failed]

    full_cols = ["name", "smiles", "formula", "mw", "logp", "mr", "tpsa", "hbd", "hba", "rotb", "rings", "aromatic_rings",
                 "heavy_atoms", "fsp3", "formal_charge", "stereocentres", "qed", "sa_score", "lipinski_violations"] + \
                [f"rule_{k}" for k in rule_names] + ["lead_like", "absorption_rule", "cns_heuristic", "pains", "brenk", "ndi"]
    full_rows = []
    for p in profiles:
        full_rows.append([p[c] for c in full_cols[:19]] + [p["rules"][k] for k in rule_names] +
                         [p["lead_like"], p["absorption_rule"], p["cns_heuristic"], "; ".join(p["pains"]), "; ".join(p["brenk"]), p["ndi"]])
    res.add_csv("admet_profile.csv", full_cols, full_rows)
    res.add_json("admet_profile.json", profiles)
    return res

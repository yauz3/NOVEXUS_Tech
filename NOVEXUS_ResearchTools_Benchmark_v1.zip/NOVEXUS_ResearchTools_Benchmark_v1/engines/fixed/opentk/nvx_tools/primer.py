"""T10 · PCR Primer Designer (Primer3 engine via primer3-py).
"""
from __future__ import annotations

import re
from pathlib import Path

from .common import Result, ToolError, r3, table

VERSION = "1.0.0"
MAX_LEN = 10000


def _clean(seq: str) -> str:
    lines = [l for l in seq.replace("\r", "").split("\n") if not l.startswith(">")]
    s = re.sub(r"[\s\d]", "", "".join(lines)).upper().replace("U", "T")
    if not s:
        raise ToolError("Paste a DNA template sequence.")
    if set(s) - set("ACGTN"):
        raise ToolError("Template may contain only A, C, G, T or N.")
    if not 60 <= len(s) <= MAX_LEN:
        raise ToolError(f"Template length must be 60–{MAX_LEN} bp in the free tier.")
    return s


def run(params: dict, workdir: Path) -> Result:
    import primer3

    seq = _clean(str(params.get("sequence", "")))
    try:
        pmin = int(params.get("product_min", 100))
        pmax = int(params.get("product_max", 300))
        tm_opt = float(params.get("tm_opt", 60.0))
        size_opt = int(params.get("size_opt", 20))
        n_ret = int(params.get("num_return", 5))
        t_start = params.get("target_start")
        t_len = params.get("target_length")
        t_start = int(t_start) if str(t_start or "").strip() else None
        t_len = int(t_len) if str(t_len or "").strip() else None
    except (TypeError, ValueError):
        raise ToolError("Primer settings must be numbers.")
    if not (50 <= pmin < pmax <= min(len(seq), 3000)):
        raise ToolError("Product size range must satisfy 50 ≤ min < max ≤ template length (max 3000).")
    if not 52 <= tm_opt <= 68 or not 16 <= size_opt <= 28 or not 1 <= n_ret <= 10:
        raise ToolError("Free tier: optimal Tm 52–68 °C, primer length 16–28 nt, 1–10 pairs.")

    seq_args = {"SEQUENCE_ID": "novexus_template", "SEQUENCE_TEMPLATE": seq}
    if t_start is not None and t_len is not None:
        if not (1 <= t_start and t_start + t_len - 1 <= len(seq) and t_len >= 1):
            raise ToolError("Target region lies outside the template.")
        seq_args["SEQUENCE_TARGET"] = [t_start - 1, t_len]
    global_args = {
        "PRIMER_OPT_SIZE": size_opt, "PRIMER_MIN_SIZE": max(15, size_opt - 4), "PRIMER_MAX_SIZE": min(30, size_opt + 4),
        "PRIMER_OPT_TM": tm_opt, "PRIMER_MIN_TM": tm_opt - 3, "PRIMER_MAX_TM": tm_opt + 3,
        "PRIMER_MIN_GC": 35.0, "PRIMER_MAX_GC": 65.0, "PRIMER_MAX_POLY_X": 4, "PRIMER_GC_CLAMP": 1,
        "PRIMER_PRODUCT_SIZE_RANGE": [[pmin, pmax]], "PRIMER_NUM_RETURN": n_ret, "PRIMER_EXPLAIN_FLAG": 1,
    }
    out = primer3.bindings.design_primers(seq_args, global_args)
    n = out.get("PRIMER_PAIR_NUM_RETURNED", 0)
    if not n:
        raise ToolError("Primer3 found no acceptable pair. Widen the product range or relax Tm/length. " +
                        str(out.get("PRIMER_PAIR_EXPLAIN", ""))[:160])
    rows, csv_rows = [], []
    for i in range(n):
        L, R = out[f"PRIMER_LEFT_{i}_SEQUENCE"], out[f"PRIMER_RIGHT_{i}_SEQUENCE"]
        lpos, rpos = out[f"PRIMER_LEFT_{i}"], out[f"PRIMER_RIGHT_{i}"]
        het = primer3.calc_heterodimer(L, R)
        hp_l, hp_r = primer3.calc_hairpin(L), primer3.calc_hairpin(R)
        row = [i + 1, L, R, f"{lpos[0] + 1}", f"{rpos[0] + 1}", out[f"PRIMER_PAIR_{i}_PRODUCT_SIZE"],
               r3(out[f"PRIMER_LEFT_{i}_TM"], 1), r3(out[f"PRIMER_RIGHT_{i}_TM"], 1),
               r3(out[f"PRIMER_LEFT_{i}_GC_PERCENT"], 1), r3(out[f"PRIMER_RIGHT_{i}_GC_PERCENT"], 1),
               r3(het.dg / 1000, 2), r3(min(hp_l.dg, hp_r.dg) / 1000, 2), r3(out[f"PRIMER_PAIR_{i}_PENALTY"], 2)]
        rows.append(row)
        csv_rows.append(row)
    best = rows[0]
    res = Result()
    res.summary = {
        "headline": [{"label": "Template length", "value": f"{len(seq)} bp"}, {"label": "Pairs returned", "value": n},
                     {"label": "Best product", "value": f"{best[5]} bp"}, {"label": "Best pair Tm", "value": f"{best[6]} / {best[7]} °C"}],
        "tables": [table("Primer pairs", ["Pair", "Forward 5′→3′", "Reverse 5′→3′", "Fwd start", "Rev start (3′ end)", "Product (bp)",
                                          "Tm F", "Tm R", "GC% F", "GC% R", "Heterodimer ΔG", "Worst hairpin ΔG", "Penalty"], rows,
                         note="ΔG in kcal/mol at 37 °C (Primer3 thermodynamic model); values below about −9 kcal/mol deserve attention.")],
        "notes": ["Check primer specificity against your organism's genome (e.g. BLAST) before ordering."],
    }
    res.add_csv("primer_pairs.csv", ["pair", "forward", "reverse", "fwd_start", "rev_start", "product_bp", "tm_f", "tm_r", "gc_f", "gc_r",
                                     "heterodimer_dg", "hairpin_dg", "penalty"], csv_rows)
    res.add_text("primer3_explain.txt", "\n".join(f"{k}: {out.get(k)}" for k in ("PRIMER_LEFT_EXPLAIN", "PRIMER_RIGHT_EXPLAIN", "PRIMER_PAIR_EXPLAIN")))
    return res

"""T02 · Similarity Search & Clustering.

Ranks a library against a query by fingerprint similarity and groups the
library with Butina clustering.
"""
from __future__ import annotations

from pathlib import Path

from .common import Result, ToolError, mol_from_smiles, parse_smiles_list, r3, table

VERSION = "1.0.0"
MAX_FREE = 200
FINGERPRINTS = {"morgan2": "Morgan r=2 (ECFP4-like, 2048 bit)", "featmorgan2": "Feature Morgan r=2 (FCFP4-like)",
                "maccs": "MACCS keys (166)", "rdkit": "RDKit topological (2048 bit)"}
METRICS = {"tanimoto", "dice"}


def fingerprint(mol, kind: str):
    from rdkit.Chem import MACCSkeys, rdFingerprintGenerator

    if kind == "morgan2":
        return rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048).GetFingerprint(mol)
    if kind == "featmorgan2":
        gen = rdFingerprintGenerator.GetMorganGenerator(
            radius=2, fpSize=2048, atomInvariantsGenerator=rdFingerprintGenerator.GetMorganFeatureAtomInvGen())
        return gen.GetFingerprint(mol)
    if kind == "maccs":
        return MACCSkeys.GenMACCSKeys(mol)
    if kind == "rdkit":
        return rdFingerprintGenerator.GetRDKitFPGenerator(fpSize=2048).GetFingerprint(mol)
    raise ToolError("Unknown fingerprint type.")


def run(params: dict, workdir: Path) -> Result:
    from rdkit import DataStructs
    from rdkit.ML.Cluster import Butina

    fp_kind = params.get("fingerprint", "morgan2")
    metric = params.get("metric", "tanimoto")
    if fp_kind not in FINGERPRINTS or metric not in METRICS:
        raise ToolError("Unsupported fingerprint or metric.")
    try:
        cutoff = float(params.get("cluster_cutoff", 0.6))
    except (TypeError, ValueError):
        raise ToolError("Cluster similarity cut-off must be a number.")
    if not 0.3 <= cutoff <= 0.95:
        raise ToolError("Cluster similarity cut-off must be between 0.30 and 0.95.")

    query_text = (params.get("query") or "").strip()
    library = parse_smiles_list(params.get("library", ""), MAX_FREE)
    sim_fn = DataStructs.BulkTanimotoSimilarity if metric == "tanimoto" else DataStructs.BulkDiceSimilarity

    names, smiles, fps, failed = [], [], [], []
    for smi, name in library:
        try:
            fps.append(fingerprint(mol_from_smiles(smi), fp_kind))
            names.append(name)
            smiles.append(smi)
        except ToolError as exc:
            failed.append(f"{name}: {exc}")
    if len(fps) < 2:
        raise ToolError("At least two valid library molecules are required.")

    res = Result()
    tables, headline = [], [{"label": "Library molecules", "value": len(fps)}, {"label": "Fingerprint", "value": FINGERPRINTS[fp_kind]}]
    ranked = []
    if query_text:
        qsmi = parse_smiles_list(query_text, 1)[0][0]
        qfp = fingerprint(mol_from_smiles(qsmi), fp_kind)
        sims = sim_fn(qfp, fps)
        ranked = sorted(zip(names, smiles, sims), key=lambda t: -t[2])
        rows = [[i + 1, n, s, r3(v)] for i, (n, s, v) in enumerate(ranked)]
        tables.append(table(f"Ranking against query ({metric.title()})", ["Rank", "Name", "SMILES", "Similarity"], rows))
        headline.append({"label": "Best match", "value": f"{ranked[0][0]} ({r3(ranked[0][2])})"})
        headline.append({"label": "Hits ≥ 0.70", "value": sum(1 for r in ranked if r[2] >= 0.7)})
        res.add_csv("query_ranking.csv", ["rank", "name", "smiles", metric], [[i + 1, n, s, r3(v, 4)] for i, (n, s, v) in enumerate(ranked)])

    # Butina clustering on distance = 1 - similarity
    dists = []
    for i in range(1, len(fps)):
        sims = sim_fn(fps[i], fps[:i])
        dists.extend(1.0 - x for x in sims)
    clusters = Butina.ClusterData(dists, len(fps), 1.0 - cutoff, isDistData=True)
    clusters = sorted(clusters, key=len, reverse=True)
    crow, member_rows = [], []
    for cid, members in enumerate(clusters, start=1):
        centroid = members[0]
        crow.append([cid, len(members), names[centroid], smiles[centroid]])
        for m in members:
            member_rows.append([cid, names[m], smiles[m], "centroid" if m == centroid else ""])
    singletons = sum(1 for c in clusters if len(c) == 1)
    tables.append(table(f"Butina clusters (similarity ≥ {cutoff})", ["Cluster", "Size", "Centroid", "Centroid SMILES"], crow))
    headline += [{"label": "Clusters", "value": len(clusters)}, {"label": "Singletons", "value": singletons}]

    # mean pairwise similarity -> library diversity
    mean_sim = 1.0 - (sum(dists) / len(dists)) if dists else 1.0
    headline.append({"label": "Mean pairwise similarity", "value": r3(mean_sim)})

    if len(fps) <= 40:
        matrix = [[r3(v, 2) for v in sim_fn(fps[i], fps)] for i in range(len(fps))]
        heat = {"type": "heatmap", "title": f"{metric.title()} similarity matrix", "labels": names, "values": matrix}
    else:
        heat = None
        matrix = None

    res.summary = {"headline": headline, "tables": tables, "charts": [heat] if heat else [],
                   "notes": ["Similarity values depend on the fingerprint; compare values only within one fingerprint type."]}
    if failed:
        res.summary["warnings"] = failed
    res.add_csv("clusters.csv", ["cluster", "name", "smiles", "role"], member_rows)
    if matrix:
        res.add_csv("similarity_matrix.csv", ["name"] + names, [[n] + row for n, row in zip(names, matrix)])
    return res

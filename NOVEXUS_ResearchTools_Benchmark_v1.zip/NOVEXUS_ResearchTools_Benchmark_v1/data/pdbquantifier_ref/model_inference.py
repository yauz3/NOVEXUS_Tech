#!/usr/bin/env python3
"""PDB-Quantifier exact trained ADS Isolation Forest inference.
Only loads the trusted supplied repo's joblib file. Separate from docking.
"""
from __future__ import annotations
import hashlib, importlib.util, json, math, os, re, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import joblib, numpy as np, pandas as pd, requests

HERE=Path(__file__).resolve().parent
MAX_CANDIDATES=12

# Reuse original repository feature extraction byte-for-byte.
spec=importlib.util.spec_from_file_location('pdbq_upstream_features',HERE/'1_prepare_training_set.py')
features=importlib.util.module_from_spec(spec)
spec.loader.exec_module(features)

class Model:
    def __init__(self):
        path=HERE/'isolationforest_ads.joblib'
        self.artifact_hash=hashlib.sha256(path.read_bytes()).hexdigest()
        saved=joblib.load(path)  # Trusted packaged upstream model ONLY.
        self.pipeline=saved['pipeline']
        self.columns=saved['feature_cols']
        self.q=saved['train_quantiles']
        assert len(self.columns)==25
    def score(self, rows):
        X=pd.DataFrame(rows).reindex(columns=self.columns)
        preds=self.pipeline.predict(X)
        scores=self.pipeline.decision_function(X)
        q=self.q
        out=[]
        for row,p,s in zip(rows,preds,scores):
            score=float(np.clip((s-q['q05'])/max(1e-8,q['q95']-q['q05']),0,1))
            tier=('low' if s<q['q20'] else 'moderate' if s<q['q50'] else 'acceptable' if s<q['q80'] else 'high')
            rec=dict(row)
            rec.update(decision_score=round(float(s),7),conformity_score_0_1=round(score,6),
                       conformity_tier=tier,if_is_inlier=bool(p==1),
                       missing_feature_count=sum(1 for c in self.columns if pd.isna(row.get(c))))
            out.append(rec)
        return sorted(out,key=lambda x:(-x['decision_score'],x['pdb_id']))

# Bounded network calls. A sequential 12x(2x15s) wait could exhaust the 420s
# WordPress job lease and appear indefinitely stuck to a visitor.
HTTP_TIMEOUT=(4,9)  # connect, read timeout per request
MAX_WORKERS=3         # moderate concurrency; respect RCSB infrastructure

def get_json(url):
    if not (url.startswith('https://rest.uniprot.org/uniprotkb/') or
            url.startswith('https://data.rcsb.org/rest/v1/core/entry/')):
        raise ValueError('Unapproved metadata host')
    for attempt in range(2):
        try:
            r=requests.get(url,headers={'User-Agent':'Novexus-PDBQuantifier/0.22.1 (https://novexus.tech)',
                'Accept':'application/json'},timeout=HTTP_TIMEOUT,allow_redirects=False)
            if r.status_code==200:
                if len(r.content)>2_000_000:return None
                return r.json()
            if r.status_code not in (429,502,503,504):return None
        except (requests.RequestException,ValueError):pass
        if attempt==0:time.sleep(.5)
    return None

def coverage_intervals(s):
    return [(int(a),int(b)) for a,b in re.findall(r'(\d+)\s*[-–]\s*(\d+)',str(s or '')) if int(a)>0 and int(a)<=int(b) and int(b)-int(a)<30000]

def coverage_overlap(first,second):
    aa=coverage_intervals(first);bb=coverage_intervals(second)
    if not aa or not bb:return None
    covered=sum(b-a+1 for a,b in aa)
    if covered<=0:return None
    inter=sum(max(0,min(a[1],b[1])-max(a[0],b[0])+1) for a in aa for b in bb)
    total_b=sum(y-x+1 for x,y in bb)
    return inter/max(1,min(covered,total_b))

def numeric(row,name):
    v=row.get(name)
    try: return None if v is None or not math.isfinite(float(v)) else float(v)
    except (ValueError,TypeError):return None

def analyze(payload, model, progress_cb=None):
    uid=str(payload['uniprot'])
    if not re.fullmatch(r'[A-Z0-9]{6}(?:[A-Z0-9]{4})?',uid):raise ValueError('Invalid UniProt accession')
    n=int(payload['count']);assert 1<=n<=10
    uniprot=get_json('https://rest.uniprot.org/uniprotkb/'+uid+'.json')
    if not isinstance(uniprot,dict):raise RuntimeError('UniProt metadata unavailable')
    candidates=[];seen=set()
    for x in uniprot.get('uniProtKBCrossReferences',[]):
        if x.get('database')!='PDB':continue
        ident=str(x.get('id','')).upper()
        if not re.fullmatch(r'[0-9A-Z]{4}',ident) or ident in seen:continue
        seen.add(ident)
        props={p.get('key'):p.get('value') for p in x.get('properties',[]) if isinstance(p,dict)}
        v=props.get('Resolution','')
        rm=re.search(r'\d+(?:\.\d+)?',str(v))
        candidates.append({'pdb_id':ident,'method':str(props.get('Method','')),
                           'positions':str(props.get('Positions',props.get('Chains',''))),
                           'resolution_hint':float(rm.group()) if rm else None})
    if not candidates: raise ValueError('UniProt accession has no cross-referenced PDBs')
    # Bounded reproducible screening; cannot claim best of entire UniProt archive.
    candidates.sort(key=lambda x:(x['resolution_hint'] is None,x['resolution_hint'] if x['resolution_hint'] is not None else 1000,x['pdb_id']))
    scanned=candidates[:MAX_CANDIDATES]
    input_rows=[];excluded=[]
    if progress_cb:progress_cb('Retrieving RCSB data: 0/'+str(len(scanned)))
    def read_one(item):
        entry=get_json('https://data.rcsb.org/rest/v1/core/entry/'+item['pdb_id'])
        if not entry:return item,None,'RCSB entry unavailable'
        row=features.extract_entry_features(entry)
        if row is None:return item,None,'Non-experimental or no protein entity'
        row['positions']=item['positions']
        reflns=(entry.get('reflns') or [{}])[0]
        row['completeness']=features.first_number(reflns.get('percent_possible_obs'))
        return item,row,None
    # map preserves the deterministic scan order, while I/O is bounded to three workers.
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        for index,(item,row,error) in enumerate(pool.map(read_one,scanned),1):
            if error:excluded.append({'pdb_id':item['pdb_id'],'reason':error})
            else:input_rows.append(row)
            if progress_cb and (index%3==0 or index==len(scanned)):
                progress_cb('RCSB structures retrieved: '+str(index)+'/'+str(len(scanned)))
    if not input_rows:raise RuntimeError('No usable experimental RCSB entries; check RCSB connectivity and metadata availability')
    if progress_cb:progress_cb('Running pretrained 25-feature Isolation Forest')
    scored=model.score(input_rows)
    if progress_cb:progress_cb('Applying quality filters and ranking')
    eligible=[]
    cols={'resolution_max':('resolution_A','max'),'r_free_max':('r_free','max'),
          'r_work_max':('r_work','max'),'completeness_min':('completeness','min'),
          'clashscore_max':('clashscore','max'),'rama_outliers_max':('ramachandran_outliers_pct','max'),
          'rotamer_outliers_max':('rotamer_outliers_pct','max'),'rsrz_outliers_max':('rsrz_outliers_pct','max'),
          'min_conformity':('conformity_score_0_1','min')}
    for row in scored:
        reason=None
        if payload.get('method') not in (None,'any') and str(payload['method']).lower() not in row['exp_method'].lower():
            reason='Experimental method filter'
        for key,(feature,side) in cols.items():
            cutoff=payload.get(key)
            if cutoff is None or cutoff=='':continue
            x=numeric(row,feature)
            if x is None: reason='Missing required '+feature;break
            if (side=='max' and x>float(cutoff)) or (side=='min' and x<float(cutoff)):
                reason=feature+' cutoff';break
        if payload.get('require_validation') and any(numeric(row,x) is None for x in ['clashscore','ramachandran_outliers_pct','rotamer_outliers_pct']):
            reason='Validation fields missing'
        if reason:excluded.append({'pdb_id':row['pdb_id'],'reason':reason})
        else:eligible.append(row)
    chosen=[];redundant=[]
    for row in eligible:
        reason=None
        if payload.get('diversity'):
            for prev in chosen:
                coverage=coverage_overlap(row['positions'],prev['positions'])
                if coverage is not None and coverage>=0.95:
                    reason='UniProt residue coverage overlaps '+prev['pdb_id'];break
                if coverage is None and payload.get('prefix_fallback') and row['pdb_id'][:3]==prev['pdb_id'][:3]:
                    reason='Weak PDB-prefix heuristic matches '+prev['pdb_id'];break
        if reason:redundant.append({'pdb_id':row['pdb_id'],'reason':reason})
        elif len(chosen)<n:chosen.append(row)
    # Strict JSON: numpy nan can make nonstandard JSON.
    def clean(x):
        if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
        if isinstance(x,list):return [clean(v) for v in x]
        if isinstance(x,(np.integer,)):return int(x)
        if isinstance(x,(np.floating,)):x=float(x)
        if isinstance(x,(float,)) and not math.isfinite(x):return None
        return x
    return clean({'uniprot':uid,'total_candidates':len(candidates),'evaluated':len(input_rows),
        'eligible':len(eligible),'ranked':scored,'selected':chosen,'excluded':excluded,'redundant':redundant,
        'model':{'model_type':'IsolationForest','n_features':len(model.columns),'model_sha256':model.artifact_hash,
                 'reference':'ADS 85 experimental structures','training_year_reference':2026,
                 'model_quantiles':model.q,'inlier_rule':'pipeline.predict() == 1'},
        'warnings':['Scores measure resemblance to ADS reference metadata, not experimental absolute structure quality.',
                    'The exact pretrained 25-feature Isolation Forest and ADS training quantiles were used.',
                    f'Up to {MAX_CANDIDATES} PDBs per UniProt are selected for the metadata pre-screen, initially by resolution. The ranking is not exhaustive.',
                    'Experimental-method availability and missing RCSB validation measurements can affect scoring.',
                    'Optional diversity uses UniProt residue coverage, not true 3D conformational clustering.']})

def selftest(model):
    source=HERE/'test_set_1.csv'
    reference=HERE/'test_set_1_scored.csv'
    if not source.exists() or not reference.exists():raise RuntimeError('Validation fixtures missing')
    src=pd.read_csv(source);exp=pd.read_csv(reference)
    observed=model.pipeline.decision_function(src[model.columns])
    err=float(np.max(np.abs(observed-exp['if_decision_score'].to_numpy())))
    inlier=np.mean(model.pipeline.predict(src[model.columns])==1)
    print(json.dumps({'rows':len(src),'max_decision_score_difference':err,'inlier_fraction':inlier,'ok':err<1e-10}))
    if err>=1e-10:raise SystemExit('Model does not reproduce supplied scored test set')

if __name__=='__main__':
    m=Model()
    if '--self-test' in sys.argv:selftest(m)
    elif '--input-json' in sys.argv:
        p=Path(sys.argv[sys.argv.index('--input-json')+1]);print(json.dumps(analyze(json.loads(p.read_text()),m),allow_nan=False))
    else:print('Use --self-test or --input-json PATH')

# PDB-Quantifier v0.22 · Gerçek Isolation Forest modeli

**Bu paket mevcut Vina, MEGADOCK, docking agent veya WordPress gizli anahtarını DEĞİŞTİRMEZ.**

## Ubuntu'da ayrı terminal (dördüncü terminal)

1. Bu Ubuntu ZIP'ini `~/Downloads` klasörüne indir.
2. Aşağıdaki komutları çalıştır:

```bash
mkdir -p ~/novexus/pdbquantifier
unzip -oq ~/Downloads/Novexus_PDBQuantifier_Ubuntu_v0.22_NEW_ONLY.zip -d ~/novexus/pdbquantifier
cd ~/novexus/pdbquantifier/PDBQuantifier_ML
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python pdbquantifier_agent.py --self-test
python pdbquantifier_agent.py --doctor
python pdbquantifier_agent.py
```

Model için scikit-learn 1.6.1 sabittir. `--self-test`, GitHub deposunun `test_set_1_scored.csv` referans skorlarını sayısal olarak yeniden üretmelidir. Model dosyası kaynağı: github.com/yauz3/PDB-Quantifier.

Ajan `~/.config/novexus-bridge/config.json` dosyasındaki MEVCUT HTTPS adresini ve token'ı yalnızca okur. Kimlik bilgilerini ekrana yazdırmaz. WordPress'ten iş çeker; dışarıdan gelen bağlantı açmaz.

> WordPress güncelleme paketi yüklenmeden agent'ın iş çekmesi mümkün değildir. WordPress PATCH dosyası yalnızca mevcut `novexus-compute-bridge` dizininin üzerine kopyalanmalıdır; Plugin Upload üzerinden yalnızca delta ZIP yüklemek doğru değildir.

#!/usr/bin/env python3
"""Dedicated PDB-Quantifier inference worker. Reuses local Novexus agent secret,
never modifies docking API/agent/worker, listens on no port.
"""
from __future__ import annotations
import json, logging, os, sys, time
from pathlib import Path
from urllib.parse import urlparse
import requests
from model_inference import Model,analyze,selftest

CONFIG=Path.home()/'.config/novexus-bridge/config.json'
LOG=logging.getLogger('novexus-pdbq')

def load_config():
    if not CONFIG.is_file():raise RuntimeError('Novexus agent config not present; do not regenerate token')
    if CONFIG.stat().st_mode&0o077:raise RuntimeError('Novexus secret file permissions not secure')
    cfg=json.loads(CONFIG.read_text())
    url=cfg['wordpress_api'].rstrip('/')+'/'
    u=urlparse(url)
    if u.scheme!='https' or u.username or u.password or not u.netloc:raise RuntimeError('Only HTTPS WordPress API allowed')
    token=cfg['token']
    if len(token)<40:raise RuntimeError('Novexus agent token missing')
    return url,token

def run():
    url,token=load_config()
    model=Model()
    sess=requests.Session()
    sess.headers.update({'X-Novexus-Agent-Token':token,'Cache-Control':'no-store','User-Agent':'Novexus-PDBQuantifier-Agent/0.22'})
    print('PDB-Quantifier model loaded; artifact sha256:',model.artifact_hash)
    print('Separate worker polling via outbound HTTPS only. Ctrl+C stops just this worker.')
    while True:
        try:
            # Don't automatically retry a pull: a lost response may have claimed a job.
            r=sess.post(url+'pdbquantifier/worker/pull',timeout=25,json={})
            if r.status_code!=200:
                LOG.error('Worker pull HTTP %d; check v0.22 WordPress delta and agent secret',r.status_code)
                time.sleep(15);continue
            job=r.json().get('job')
            if job:
                jid=job['id']
                LOG.info('Executing PDB-Quantifier ML: %s',jid[:8])
                started=time.monotonic()
                def progress(stage):
                    LOG.info('PDBQ %s: %s',jid[:8],stage)
                    try:
                        response=sess.post(url+'pdbquantifier/worker/progress/'+jid,
                            json={'stage':stage},timeout=12)
                        if response.status_code!=200:
                            LOG.warning('PDBQ progress HTTP %d for %s',response.status_code,jid[:8])
                    except requests.RequestException as exc:
                        LOG.warning('PDBQ progress transport %s for %s',type(exc).__name__,jid[:8])
                try:
                    result=analyze(job['input'],model,progress_cb=progress)
                    payload={'ok':True,'result':result}
                    LOG.info('PDBQ %s calculated %d structures in %.1f sec',
                        jid[:8],len(result.get('ranked',[])),time.monotonic()-started)
                except Exception as exc:
                    LOG.exception('PDB-Quantifier failed for %s',jid[:8])
                    payload={'ok':False,'error':str(exc)[:200]}
                # Explicitly report whether WordPress accepted the final result.
                accepted=False
                for attempt in range(3):
                    try:
                        done=sess.post(url+'pdbquantifier/worker/result/'+jid,json=payload,timeout=45)
                        if done.status_code==200:
                            accepted=True
                            LOG.info('PDBQ %s status DELIVERED: %s (%.1f sec)',
                                jid[:8],'COMPLETED' if payload['ok'] else 'FAILED',time.monotonic()-started)
                            break
                        LOG.error('PDBQ %s result rejected HTTP %d: %s',jid[:8],done.status_code,done.text[:240])
                        if done.status_code in (400,413,422):
                            # The scientific result was not accepted. Explicitly mark
                            # the job FAILED rather than leaving it RUNNING until lease expiry.
                            reason='WordPress rejected model results (HTTP '+str(done.status_code)+'). Contact support with job ID '+jid[:8]
                            try:
                                fallback=sess.post(url+'pdbquantifier/worker/result/'+jid,
                                    json={'ok':False,'error':reason},timeout=18)
                                if fallback.status_code==200:
                                    accepted=True
                                    LOG.error('PDBQ %s marked FAILED after rejected results',jid[:8])
                            except requests.RequestException:
                                LOG.exception('PDBQ %s could not report rejected results',jid[:8])
                            break
                        if done.status_code in (401,403,404,409):break
                    except requests.RequestException as exc:
                        LOG.error('PDBQ %s result transport error: %s',jid[:8],type(exc).__name__)
                    time.sleep(3*(attempt+1))
                if not accepted:
                    LOG.error('PDBQ %s RESULT NOT ACKNOWLEDGED by WordPress; inspect Recent PDB-Quantifier jobs',jid[:8])
        except requests.RequestException as exc:
            LOG.error('WordPress HTTPS polling error: %s',type(exc).__name__)
        except (ValueError,KeyError) as exc:
            LOG.error('Unexpected WordPress response: %s',type(exc).__name__)
        time.sleep(5)

if __name__=='__main__':
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    if '--self-test' in sys.argv:
        m=Model();selftest(m)
    elif '--doctor' in sys.argv:
        print('Agent config:',CONFIG,'present=',CONFIG.exists())
        url,token=load_config();print('WordPress HTTPS origin:',urlparse(url).netloc)
        print('Local artifact loaded and valid:',Model().artifact_hash)
    else:run()

# Bulgular ve öneriler

Tam koşu: 32 test, iki sürüm, tohum 2026. Ölçüm ortamı: Python 3.13.17, RDKit 2026.09.1,
Biopython 1.88, primer3-py 2.4.0, dimorphite-dl 2.1.0, Meeko 0.8.0.

| | original | fixed |
|---|---|---|
| GOOD | 23 | 25 |
| MEDIUM | 2 | 2 |
| LOW | 4 | 2 |
| Çalıştırılamadı (ağ / fpocket) | 3 | 3 |

18 araç bağımsız referans uygulamalarla **birebir** eşleşiyor (`validity_pass_rate` = 1.00).
594 saldırgan girdide (27 araç × 22 girdi) hiçbir araç kontrolsüz hata vermedi. 54 tekrarlanabilirlik
kontrolünün tamamı geçti.

## Ücretsiz katman gerçekten aynı işi yapıyor

Tier'lı 20 aracın tamamını, FREE sınırına sığan aynı girdiyle iki katmanda da çalıştırdım:

- **18 araç birebir aynı sonucu** veriyor (17'si bayt bayt aynı, CRISPR aynı değerleri
  daha az satırla döndürüyor: 20/34).
- **2 araçta ücretsiz katman dar**, ama yanlış değil: PAINS taraması FREE'de 3 katalog
  kullanıyor, PRO'da Brenk ekleniyor; restriction map FREE'de 8, PRO'da 20 enzim tarıyor.
  Ücretsiz katmanın raporladığı her uyarı ve her kesim yeri PRO'da da raporlanıyor.

Yani ücretsiz katman ucuz bir algoritma koymuyor; girdi boyutunu ve iki araçta katalog
genişliğini sınırlıyor. Bu, makalede "ücretsiz" iddiasını destekleyen ölçülmüş bulgu.

**Yanıt süreleri:** 30 aracın medyanı 14 ms, 27'si 100 ms altında, en yavaşı 0.97 s
(3B ligand hazırlama — konformer üretimi ve kuvvet alanı optimizasyonu yapıyor).
Bu süreler PRO sınırlarındaki daha büyük girdilerle ölçüldü.

## Siteden kaldırılması önerilen: PCR Primer Candidate Screen (micro24)

Döndürdüğü primer çiftlerinin **%3.0'ı** (596 çiftten 18'i) temel QC'yi geçiyor. 576 primer
57–63 °C penceresinin dışında, 401'inde saç tokası Tm'si ≥ 47 °C. Kök neden Tm hesabının
Mg²⁺ ve dNTP içermeyen varsayılan tuz koşullarıyla yapılması: 300 primerde Primer3'e göre
ortalama 5.81 °C düşük çıkıyor. Tampon koşulları düzeltilince (50 mM Na⁺, 1.5 mM Mg²⁺,
0.6 mM dNTP, 25/25 nM oligo) Biopython Tm'si Primer3 ile **tam olarak** aynı sonucu veriyor
ve QC geçme oranı %58.9'a çıkıyor. Kalan başarısızlıkların tamamı (272) saç tokası taraması
yapılmamasından; bu, aracın tasarımında yok.

Aynı işi yapan Primer3 tabanlı **PCR Primer Designer** 525 çiftin %100'ünde QC'yi geçiyor ve
her şablonda çift üretiyor (micro24: %58). Aynı kategoride iki araç tutmanın bir faydası yok.
**Öneri: micro24 primer aracını yayından çıkar, kullanıcıları Primer3 tabanlı olana yönlendir.**

## Sıralaması kaldırılması veya değiştirilmesi önerilen: SpCas9 Guide Explorer

PAM tarama ve koordinatlar kusursuz (5310 guide'da hata yok, `site_enumeration_validity` = 1.00),
yani kod doğru çalışıyor. Sorun sıralama ölçütünde: araç guide'ları GC %50'ye yakınlığa göre
sıralıyor. Doench ve ark. 2016 verisinde bu sıralamanın ölçülen aktiviteyle korelasyonu
**ρ = 0.152**, en aktif %20'yi ayırt etme AUC'si **0.562** (rastgele 0.5). Aynı dosyadaki
Rule Set 2 tahminleri ρ = 0.715 ve AUC = 0.832 alıyor.

İki seçenek:
1. Sıralamayı kaldır, çıktıyı sırasız "aday listesi" olarak sun ve GC'nin aktivite göstergesi
   olmadığını açıkça yaz. Düşük maliyet, dürüst çözüm.
2. Yayımlanmış bir skorlama modeli ekle (Rule Set 2 / Azimuth veya DeepSpCas9). Makale için
   gerçek bir katkı olur çünkü "önce/sonra" ölçümü elimizde hazır.

## Düzeltilen dört hata

| Araç | Metrik | Önce | Sonra | Kök neden |
|---|---|---|---|---|
| Compound Parent & Duplicate Finder | duplikasyon F1 | 0.630 | **1.000** | `FragmentParent` yük bırakıyordu: sodyum tuzu 0/60, amonyum klorür 0/117 eşleşme. `ChargeParent` ile tamamı eşleşiyor |
| Ligand 3D Preparation | pH 7.4 yük doğruluğu | 0.676 | **0.882** | Üç ayrı hata: (a) Dimorphite'ın `precision=0.5` ile döndürdüğü ilk varyant baskın tür değil, (b) tautomer sayıcı C=O komşusu sp3 stereomerkezleri siliyordu (6 molekülün 4'ünde enantiyomer kaybı), (c) "kanonik tautomer" en kararlı tautomer değil (progesteron 4-en-3-on → 5-en-3-on) |
| Functional Group Explorer | mikro-F1 | 0.915 | **0.969** | `fr_heteroaromatic` RDKit'te mevcut değil; kod `getattr(..., None)` ile sessizce atlıyordu. Heteroaromatik grup hiç raporlanmıyordu (grup F1 = 0.00) |
| Protein Motif Scanner | PROSITE F1 | 0.938 | **1.000** | N-glikozilasyon kalıbı `N[^P][ST]` idi; PROSITE PS00001 dördüncü pozisyonda da prolini dışlar (`N-{P}-[ST]-{P}`). Yanlış pozitifler |

Ek olarak micro24 Pairwise Alignment, kimlik puanı (+2/−1) yerine BLOSUM62 ve EMBOSS boşluk
cezalarına (−10/−0.5) geçirildi: Q skoru 0.931 → 0.958, kimlik yüzdesi hatası %60 ayrışmada
0.058 → 0.011.

## Düzeltilmeyen, raporlanan sorunlar

**Align aracı DNA'da zayıf.** Protein Q = 0.958 ama DNA ortalaması 0.647; %50 ayrışmada 0.300,
%60'ta 0.103. Sebep NUC.4.4 matrisiyle −10/−0.5 boşluk cezasının birlikte kullanılması. Bu
değerler EMBOSS `needle` varsayılanlarıyla aynı olduğu için "hata" demek doğru olmaz, ama yüksek
ayrışmalı DNA için uygun değil. DNA modunda boşluk cezalarının ayrı ayarlanması gerekir.

**ESOL, yayımlanmış sürümden sapıyor.** Delaney 1128 molekülünde RMSE = 1.099 (R² = 0.725),
veri setinin kendi ESOL kolonu aynı moleküllerde RMSE = 0.910. İkisi arasındaki uyum RMSE'si
0.493, yani sistematik bir fark var. Denklem katsayıları yayımlanmış haliyle aynı; fark logP
kaynağından geliyor (Crippen MolLogP ve Delaney'nin kullandığı Daylight clogP aynı şey değil).
Araç hâlâ MEDIUM bandında ve kullanılabilir; dokümanda hangi logP'nin kullanıldığı yazılmalı.

**PAINS tarama, bazı bilinen kemotipleri kaçırıyor.** 13 PAINS örneğinin 10'unu yakalıyor
(duyarlılık 0.769); kurkumin, hidrokinon ve benzilidin-tiazolidindion kaçıyor. Özgüllük 1.00
(57 onaylı ilaçta tek yanlış pozitif yok). Bu, RDKit'in PAINS A/B/C katalogunun kapsamıyla
ilgili, kodla değil. PRO katmanındaki Brenk katalogu 57 ilacın 9'unu işaretliyor.

**NDI dışarıdan doğrulanamıyor.** ADMET aracının "Novexus Developability Index" bileşik skoru
yayımlanmamış ve dışsal bir doğrulaması yok. Sadece aralığı ve bileşen aritmetiği doğrulandı.
İkincil metriklerdeki "ilaç vs endüstriyel kimyasal" AUC değeri (0.731) zayıf bir vekil ölçüttür,
doğrulama değildir. Makalede bu açıkça belirtilmeli; aksi halde hakem haklı olarak itiraz eder.

## Yapı kalite skorlaması (PDB-Quantifier) — ölçüldü

Model kendi referans skorlarını birebir yeniden üretiyor: conformity farkı 3.3×10⁻¹⁶,
tier uyumu 27/27. İki sorun çıktı.

**25 özniteliğin 11'i skorlanan satırlarda tamamen boş** (hücrelerin %44'ü) — ve bunlar
modelin varlık sebebi olan kristalografik doğrulama göstergelerinin tamamı: R-free,
R-work, R-observed, clashscore, Ramachandran, rotamer, RSRZ, DCC R/Rfree. Pipeline
eksikleri eğitim ortalamasıyla dolduruyor, yani o yapılara kalite verisi olmadan kalite
notu verilmiş. Hata yok, uyarı yok. Modelin kendi doğrulama kaydı da bunu destekliyor:
eğitim ile testler arasında anlamlı dağılım kayması (KS p = 1.1×10⁻³ ve 2.1×10⁻⁸),
conformity ortalaması 0.64 → 0.37 → 0.32.

Üretim kodunda bu veriler RCSB'den çekiliyor ve eksikse reddeden bir `require_validation`
kontrolü var — ama opsiyonel ve varsayılan olarak kapalı. Kod zaten `missing_feature_count`
hesaplıyor, sadece göstermiyor. **İki satırlık düzeltme:** kontrolü varsayılan yap, eksik
öznitelik sayısını skorla birlikte göster. Dağıtılmış davranışı değiştirdiği için
uygulamadım.

**Model scikit-learn 1.6.1'e kilitli.** Yeni sürümde `AttributeError` ile patlıyor, sürüm
hatası olarak değil. Rutin bir bağımlılık güncellemesi skorlamayı sebebi anlaşılmaz
biçimde bozar. Benchmark bunu yakalayıp gereken sürümü söylüyor.

## Henüz ölçülmeyen üç araç

| Araç | Gereken | Hazır metrik |
|---|---|---|
| Binding Pocket Finder | `fpocket` + RCSB erişimi | 10 holo yapıda DCC ≤ 4 Å top-1 başarısı (ligand kaldırılarak) |
| Protein–Ligand Interaction Profiler | PLIP + RCSB erişimi | PLIP 2.x'e karşı (etkileşim tipi, rezidü) F1 |
| Target & Bioactivity Finder | ChEMBL erişimi | 12 onaylı ilacın bilinen hedefi için top-10 isabet oranı |

Görev kodları pakette hazır. Ubuntu sunucunda `sudo apt install fpocket`,
`pip install plip openbabel-wheel` kurup `python3 run_benchmark.py --tools pocket,interact,target`
çalıştırman yeterli.

## Sitede bırakma kararı için özet

- **Bırakılabilir (25 araç):** fixed sürümdeki tüm GOOD araçlar.
- **Bırakılabilir, dokümana not eklenerek (2):** ESOL (logP kaynağı), LigPrep (salisilik asit gibi
  komşu asidik grupları olan moleküllerde yükü kontrol et).
- **Karar gerekli (2):** micro24 Primer (kaldırmayı öneriyorum), CRISPR Guide (sıralamayı
  kaldır veya yayımlanmış model ekle).
- **Ölçüm bekliyor (3):** Pocket, Interact, Target.

#!/usr/bin/env python3
"""NOVEXUS Research Tools — benchmark runner.

  python3 run_benchmark.py --check            # environment report, nothing else
  python3 run_benchmark.py --fetch            # download the two public datasets
  python3 run_benchmark.py                    # full run, both variants
  python3 run_benchmark.py --quick            # smaller samples (a few minutes)
  python3 run_benchmark.py --variant fixed    # one variant only
  python3 run_benchmark.py --tools esol_estimator,primer_design
  python3 run_benchmark.py --offline          # skip the three network tools

Writes results/benchmark_<timestamp>.{json,csv} and results/report_<timestamp>.html
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import shutil
import statistics
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))

PKG = ROOT.name
try:
    from bench.engines import TOOLS, VARIANTS
    from bench.metrics import STATISTICS, THRESHOLDS, bootstrap_ci, interval_for, verdict
    from bench.tasks import chem_tasks, dock_tasks, seq_tasks, struct_tasks
except ImportError:  # running from inside the package directory
    sys.path.insert(0, str(ROOT))
    from bench.engines import TOOLS, VARIANTS  # noqa: F811
    from bench.metrics import STATISTICS, THRESHOLDS, bootstrap_ci, interval_for, verdict  # noqa: F811
    from bench.tasks import chem_tasks, dock_tasks, seq_tasks, struct_tasks  # noqa: F811

ALL_TASKS = {**chem_tasks.TASKS, **seq_tasks.TASKS, **struct_tasks.TASKS, **dock_tasks.TASKS}
NETWORK = ("pocket", "interact", "target", "redock", "pocket_p2rank", "structselect")
GROUP = {t: ("Drug-likeness & ADMET" if t in ("druglikeness", "structural_alerts", "formula_mass", "functional_groups", "esol_estimator", "admet")
             else "Virtual screening & chemical space" if t in ("chemical_similarity", "scaffold_analysis", "chemical_diversity", "compound_cleanup", "similarity", "chemspace")
             else "Structure & binding" if t in ("ligand_efficiency", "ligprep", "target", "pocket", "interact", "peptide_profile")
             else "Protein & peptide" if t in ("protein_properties", "motif_scanner", "variant_compare", "protparam", "sequence_alignment", "align")
             else "DNA & genomics" if t in ("primer_design", "dna_quality", "orf_finder", "crispr_guide", "restriction_map", "primer")
             else "Docking & structure services" if t in ("redock", "pocket_p2rank", "pdbquantifier", "structselect")
             else "Cross-cutting") for t in ALL_TASKS}
SOURCE = {}
for _t, (_fam, _i) in TOOLS.items():
    SOURCE[_t] = {"micro24": "A (micro24)", "micro25": "B (micro25)", "opentk": "C (Open Toolkit)"}[_fam]
SOURCE["robustness"] = SOURCE["determinism"] = SOURCE["tier_parity"] = "all"
for _t in ("redock", "pocket_p2rank", "pdbquantifier", "structselect"):
    SOURCE[_t] = "platform"

DATASETS = {
    "delaney-processed.csv": "https://raw.githubusercontent.com/deepchem/deepchem/master/datasets/delaney-processed.csv",
    "FC_plus_RES_withPredictions.csv": "https://raw.githubusercontent.com/MicrosoftResearch/Azimuth/master/azimuth/data/FC_plus_RES_withPredictions.csv",
}


def fetch(data_dir: Path):
    import urllib.request
    data_dir.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for name, url in DATASETS.items():
        dest = data_dir / name
        if dest.is_file():
            print(f"  present  {name}")
        else:
            print(f"  download {name} ... ", end="", flush=True)
            try:
                with urllib.request.urlopen(url, timeout=120) as r, open(dest, "wb") as fh:
                    shutil.copyfileobj(r, fh)
                print("ok")
            except Exception as exc:  # noqa: BLE001
                print(f"FAILED ({exc})")
                continue
        manifest[name] = {"url": url, "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(), "bytes": dest.stat().st_size}
    (data_dir / "DATA_MANIFEST.json").write_text(json.dumps(manifest, indent=2))
    print(f"\nSHA-256 manifest: {data_dir / 'DATA_MANIFEST.json'}")
    return manifest


def environment(data_dir: Path):
    env = {"python": sys.version.split()[0], "platform": platform.platform(), "cpu_count": __import__("os").cpu_count(),
           "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "packages": {}, "binaries": {}, "datasets": {}}
    for mod in ("rdkit", "Bio", "numpy", "scipy", "sklearn", "primer3", "dimorphite_dl", "meeko", "peptides", "pyteomics", "plip"):
        try:
            m = __import__(mod)
            env["packages"][mod] = getattr(m, "__version__", "installed")
        except ImportError:
            env["packages"][mod] = None
    for exe in ("fpocket", "mafft"):
        p = shutil.which(exe)
        env["binaries"][exe] = p or None
    for name in DATASETS:
        f = data_dir / name
        env["datasets"][name] = hashlib.sha256(f.read_bytes()).hexdigest()[:16] if f.is_file() else None
    return env


def check(env):
    print("Environment\n" + "-" * 60)
    print(f"  python   {env['python']}  ({env['platform']})")
    req = {"rdkit", "Bio", "numpy", "scipy", "sklearn", "primer3", "dimorphite_dl", "meeko"}
    refs = {"peptides", "pyteomics", "plip"}
    for k, v in env["packages"].items():
        tag = "REQUIRED" if k in req else "reference" if k in refs else ""
        print(f"  {'OK ' if v else 'MISSING'} {k:14s} {v or ''} {tag}")
    for k, v in env["binaries"].items():
        print(f"  {'OK ' if v else 'MISSING'} {k:14s} {v or '(pocket / MSA benchmarks will be skipped)'}")
    for k, v in env["datasets"].items():
        print(f"  {'OK ' if v else 'MISSING'} {k:34s} {v or '(run --fetch)'}")
    missing = [k for k in req if not env["packages"][k]]
    if missing:
        print(f"\nInstall the required packages first:\n  pip install {' '.join('rdkit biopython numpy scipy scikit-learn primer3-py dimorphite_dl meeko'.split())}")
    if not all(env["packages"][k] for k in refs):
        print("\nReference libraries for independent comparison:\n  pip install peptides pyteomics plip openbabel-wheel")
    return not missing


def run(args):
    data_dir = ROOT / "data"
    env = environment(data_dir)
    if args.check:
        check(env)
        return 0
    if args.fetch:
        fetch(data_dir)
        return 0
    full_env = check(env)
    if not full_env and not args.tools:
        return 2
    if not full_env:
        print("\n  (--tools given: continuing with the packages that are present; "
              "benchmarks needing a missing package will report DEPENDENCY_MISSING)\n")
    names = [t.strip() for t in args.tools.split(",")] if args.tools else list(ALL_TASKS)
    unknown = [n for n in names if n not in ALL_TASKS]
    if unknown:
        print(f"Unknown tool(s): {unknown}\nAvailable: {', '.join(ALL_TASKS)}")
        return 2
    if args.offline:
        names = [n for n in names if n not in NETWORK]
    variants = [args.variant] if args.variant else list(VARIANTS)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    out_dir = ROOT / "results"
    out_dir.mkdir(exist_ok=True)
    results = {"environment": env, "thresholds": THRESHOLDS["metrics"], "quick_mode": args.quick, "seed": args.seed, "runs": {}}
    print(f"\nRunning {len(names)} benchmarks x {len(variants)} variant(s)"
          f"{' [quick]' if args.quick else ''}\n" + "=" * 74)
    for variant in variants:
        results["runs"][variant] = {}
        for i, name in enumerate(names, 1):
            ctx = {"variant": variant, "quick": args.quick, "data_dir": data_dir, "root": ROOT, "seed": args.seed,
                   "exhaustiveness": args.exhaustiveness, "pdbq_dir": args.pdbq_dir,
                   "structselect_cli": args.structselect_cli}
            print(f"[{variant:8s} {i:2d}/{len(names)}] {name:22s} ", end="", flush=True)
            t0 = time.perf_counter()
            try:
                res = ALL_TASKS[name](ctx)
            except Exception:  # noqa: BLE001
                res = {"status": "CRASH", "error": traceback.format_exc()[-1500:]}
            res["wall_seconds"] = round(time.perf_counter() - t0, 2)
            res["group"] = GROUP[name]
            res["source"] = SOURCE.get(name, "")
            if res.get("primary_value") is not None and res.get("primary_metric"):
                res["verdict"] = verdict(res["primary_metric"], res["primary_value"])
                ci = method = None
                boot = res.pop("bootstrap", None)   # {"unit": str, "stat": key, "samples": [...]}
                if boot and boot.get("stat") in STATISTICS:
                    ci = bootstrap_ci(boot["samples"], STATISTICS[boot["stat"]], seed=args.seed,
                                      stratified=bool(boot.get("stratified")))
                    if ci:
                        method = ("stratified " if boot.get("stratified") else "") + \
                                 f"percentile bootstrap over {boot.get('unit', 'units')} " \
                                 f"(n={len(boot['samples'])}, 4000 resamples)"
                    # a degenerate interval means every unit gave the same outcome, not that
                    # the uncertainty is zero: fall back to a Wilson bound over the units
                    if ci and ci[0] == ci[1] and res["primary_value"] in (0.0, 1.0):
                        from bench.metrics import wilson as _w
                        w = _w(res["primary_value"], len(boot["samples"]))
                        if w:
                            ci, method = w, (f"Wilson bound over {len(boot['samples'])} "
                                             f"{boot.get('unit', 'units')}; the bootstrap is "
                                             f"degenerate because every unit gave the same outcome")
                if ci is None:
                    ci = interval_for(res["primary_metric"], res["primary_value"], res.get("n"))
                    if ci:
                        method = "Wilson" if res["primary_metric"] in __import__(
                            "bench.metrics", fromlist=["x"]).PROPORTION_METRICS else \
                            ("Hanley--McNeil" if res["primary_metric"] in __import__(
                                "bench.metrics", fromlist=["x"]).AUC_METRICS else "Fisher z")
                        method += " interval over the reported n"
                if ci:
                    res["ci95"] = [round(ci[0], 4), round(ci[1], 4)]
                    res["ci95_method"] = method
            else:
                res["verdict"] = res.get("status", "ERROR")
            results["runs"][variant][name] = res
            v = res.get("primary_value")
            print(f"{res['verdict']:16s} {('%.4f' % v) if isinstance(v, float) else '-':>9s}  {res['wall_seconds']:6.1f}s")
            if res.get("error"):
                print(f"{'':12s}  -> {str(res['error']).splitlines()[-1][:110]}")

    js = out_dir / f"benchmark_{stamp}.json"
    js.write_text(json.dumps(results, indent=1, default=str))
    cs = out_dir / f"benchmark_{stamp}.csv"
    with open(cs, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["variant", "tool", "group", "engine_source", "metric", "value", "ci95_low", "ci95_high", "verdict", "n", "seconds_per_call", "wall_seconds", "reference", "secondary_json"])
        for variant, rs in results["runs"].items():
            for name, r in rs.items():
                ci = r.get("ci95") or [None, None]
                w.writerow([variant, name, r.get("group"), r.get("source"), r.get("primary_metric"), r.get("primary_value"),
                            ci[0], ci[1],
                            r.get("verdict"), r.get("n"), r.get("seconds_per_call"), r.get("wall_seconds"),
                            r.get("reference", ""), json.dumps(r.get("secondary", {}), default=str)])
    html = out_dir / f"report_{stamp}.html"
    html.write_text(render_html(results, names, variants))
    summary(results, names, variants)
    print(f"\nResults\n  {js}\n  {cs}\n  {html}")
    return 0


def summary(results, names, variants):
    print("\n" + "=" * 74 + "\nSummary\n" + "=" * 74)
    for variant in variants:
        counts = {}
        for n in names:
            counts[results["runs"][variant][n]["verdict"]] = counts.get(results["runs"][variant][n]["verdict"], 0) + 1
        line = "  ".join(f"{k}: {v}" for k, v in sorted(counts.items()))
        print(f"  {variant:9s} {line}")
    low = [(v, n, results["runs"][v][n]) for v in variants for n in names if results["runs"][v][n]["verdict"] in ("LOW", "MEDIUM")]
    if low:
        print("\n  Needs attention:")
        for v, n, r in low:
            print(f"    [{v}] {n:22s} {r['verdict']:7s} {r.get('primary_metric')} = {r.get('primary_value')}")
    if len(variants) == 2:
        print("\n  original -> fixed changes:")
        for n in names:
            a = results["runs"]["original"][n].get("primary_value")
            b = results["runs"]["fixed"][n].get("primary_value")
            if isinstance(a, float) and isinstance(b, float) and abs(a - b) > 1e-9:
                print(f"    {n:22s} {a:.4f} -> {b:.4f}")


CSS = """
:root{--bg:#fbfbfa;--fg:#20201e;--mut:#6b6b66;--line:#e3e3df;--card:#fff;
--good:#1a7f4b;--goodbg:#e8f5ee;--med:#8a6400;--medbg:#fdf4e0;--low:#a32020;--lowbg:#fbeaea;--na:#5b6472;--nabg:#eef1f5}
@media(prefers-color-scheme:dark){:root{--bg:#17171a;--fg:#e8e8e4;--mut:#9a9a93;--line:#2e2e33;--card:#1f1f23;
--good:#5fd49a;--goodbg:#16302a;--med:#e5be6a;--medbg:#332a16;--low:#f0908c;--lowbg:#3a1f1f;--na:#9fb0c4;--nabg:#232a33}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
font:15px/1.55 ui-sans-serif,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:40px 16px 80px}
h1{font-size:26px;margin:0 0 4px;letter-spacing:-.01em}h2{font-size:18px;margin:38px 0 12px;letter-spacing:-.01em}
.sub{color:var(--mut);font-size:13px;margin-bottom:26px}
.cards{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0 8px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 16px;min-width:130px;flex:1}
.card .k{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}
.card .v{font-size:23px;font-weight:600;margin-top:3px;font-variant-numeric:tabular-nums}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden;font-size:13.5px}
th,td{padding:8px 11px;text-align:left;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut);font-weight:600;background:var(--bg)}
tr:last-child td{border-bottom:none}
td.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.b{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11.5px;font-weight:600;white-space:nowrap}
.GOOD{background:var(--goodbg);color:var(--good)}.MEDIUM{background:var(--medbg);color:var(--med)}
.LOW{background:var(--lowbg);color:var(--low)}.other{background:var(--nabg);color:var(--na)}
.grp td{background:var(--bg);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut)}
details{margin:3px 0 0}summary{cursor:pointer;color:var(--mut);font-size:12px}
pre{margin:6px 0 0;padding:9px;background:var(--bg);border:1px solid var(--line);border-radius:7px;
font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap;word-break:break-word;max-height:290px;overflow:auto}
.ref{color:var(--mut);font-size:12px;max-width:430px}
.delta{font-weight:600}.up{color:var(--good)}.down{color:var(--low)}
footer{margin-top:40px;color:var(--mut);font-size:12px;border-top:1px solid var(--line);padding-top:14px}
@media(max-width:720px){.ref{display:none}}
"""


def render_html(results, names, variants):
    import html as H

    def esc(x):
        return H.escape(str(x))

    def badge(v):
        cls = v if v in ("GOOD", "MEDIUM", "LOW") else "other"
        return f'<span class="b {cls}">{esc(v)}</span>'

    env = results["environment"]
    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'>",
             "<meta name='viewport' content='width=device-width,initial-scale=1'>",
             "<title>Novexus Research Tools Benchmark</title><style>", CSS, "</style></head><body><div class='wrap'>",
             "<h1>Novexus Research Tools &mdash; benchmark report</h1>",
             f"<div class='sub'>{esc(env['timestamp_utc'])} &middot; Python {esc(env['python'])} &middot; "
             f"RDKit {esc(env['packages'].get('rdkit'))} &middot; Biopython {esc(env['packages'].get('Bio'))}"
             f"{' &middot; quick mode' if results['quick_mode'] else ''}</div>"]

    for variant in variants:
        rs = results["runs"][variant]
        c = {}
        for n in names:
            c[rs[n]["verdict"]] = c.get(rs[n]["verdict"], 0) + 1
        parts.append(f"<h2>{esc(variant)}</h2><div class='cards'>")
        for k in ("GOOD", "MEDIUM", "LOW"):
            parts.append(f"<div class='card'><div class='k'>{k.lower()}</div><div class='v'>{c.get(k, 0)}</div></div>")
        skipped = sum(v for k, v in c.items() if k not in ("GOOD", "MEDIUM", "LOW"))
        parts.append(f"<div class='card'><div class='k'>not run</div><div class='v'>{skipped}</div></div>"
                     f"<div class='card'><div class='k'>benchmarks</div><div class='v'>{len(names)}</div></div></div>")
        parts.append("<table><thead><tr><th>Tool</th><th>Source</th><th>Primary metric</th><th class='num'>Value</th>"
                     "<th>Verdict</th><th class='num'>n</th><th class='num'>s/call</th><th class='ref'>Reference</th></tr></thead><tbody>")
        last = None
        for n in sorted(names, key=lambda x: (list(GROUP.values()).count(None) or 0, GROUP[x], x)):
            r = rs[n]
            if r["group"] != last:
                last = r["group"]
                parts.append(f"<tr class='grp'><td colspan='8'>{esc(last)}</td></tr>")
            v = r.get("primary_value")
            vs = f"{v:.4f}" if isinstance(v, float) else "&ndash;"
            sec = json.dumps(r.get("secondary", {}), indent=1, default=str)
            det = ""
            if r.get("secondary") or r.get("failures") or r.get("error"):
                blocks = []
                if r.get("error"):
                    blocks.append("ERROR: " + str(r["error"]))
                if r.get("secondary"):
                    blocks.append(sec)
                if r.get("failures"):
                    blocks.append("failures (first 25):\n" + "\n".join(str(x) for x in r["failures"][:25]))
                det = f"<details><summary>details</summary><pre>{esc(chr(10).join(blocks))}</pre></details>"
            parts.append(f"<tr><td><strong>{esc(n)}</strong>{det}</td><td>{esc(r.get('source', ''))}</td>"
                         f"<td>{esc(r.get('primary_metric') or '')}</td><td class='num'>{vs}</td><td>{badge(r['verdict'])}</td>"
                         f"<td class='num'>{esc(r.get('n') or '')}</td>"
                         f"<td class='num'>{('%.2f' % r['seconds_per_call']) if isinstance(r.get('seconds_per_call'), float) else ''}</td>"
                         f"<td class='ref'>{esc(r.get('reference', ''))}</td></tr>")
        parts.append("</tbody></table>")

    if len(variants) == 2:
        rows = []
        for n in names:
            a = results["runs"]["original"][n].get("primary_value")
            b = results["runs"]["fixed"][n].get("primary_value")
            if isinstance(a, float) and isinstance(b, float) and abs(a - b) > 1e-9:
                m = results["runs"]["original"][n]["primary_metric"]
                lower = THRESHOLDS["metrics"][m]["direction"] == "lower"
                better = (b < a) if lower else (b > a)
                rows.append(f"<tr><td><strong>{esc(n)}</strong></td><td>{esc(m)}</td><td class='num'>{a:.4f}</td>"
                            f"<td class='num'>{b:.4f}</td><td class='num delta {'up' if better else 'down'}'>"
                            f"{'+' if b > a else ''}{b - a:.4f}</td>"
                            f"<td>{badge(results['runs']['original'][n]['verdict'])} &rarr; {badge(results['runs']['fixed'][n]['verdict'])}</td></tr>")
        if rows:
            parts.append("<h2>original &rarr; fixed</h2><table><thead><tr><th>Tool</th><th>Metric</th>"
                         "<th class='num'>original</th><th class='num'>fixed</th><th class='num'>&Delta;</th><th>Verdict</th></tr></thead><tbody>"
                         + "".join(rows) + "</tbody></table>")

    parts.append("<h2>Thresholds</h2><table><thead><tr><th>Metric</th><th>Direction</th><th class='num'>GOOD</th>"
                 "<th class='num'>MEDIUM</th></tr></thead><tbody>")
    for k, t in results["thresholds"].items():
        parts.append(f"<tr><td>{esc(k)}</td><td>{esc(t['direction'])} is better</td>"
                     f"<td class='num'>{t['good']}</td><td class='num'>{t['medium']}</td></tr>")
    parts.append("</tbody></table>")
    parts.append(f"<h2>Environment</h2><pre>{esc(json.dumps(env, indent=1))}</pre>")
    parts.append("<footer>Generated by run_benchmark.py. Verdicts come from bench/thresholds.json; "
                 "every metric and its reference source is documented in METRICS.md.</footer></div></body></html>")
    return "".join(parts)


def main():
    ap = argparse.ArgumentParser(description="Benchmark the 30 Novexus research tools.")
    ap.add_argument("--check", action="store_true", help="environment report only")
    ap.add_argument("--fetch", action="store_true", help="download the public datasets")
    ap.add_argument("--quick", action="store_true", help="smaller samples")
    ap.add_argument("--offline", action="store_true", help="skip the three network-dependent tools")
    ap.add_argument("--variant", choices=list(VARIANTS), help="run one variant only")
    ap.add_argument("--tools", help="comma-separated subset")
    ap.add_argument("--seed", type=int, default=2026, help="random seed (default 2026)")
    ap.add_argument("--exhaustiveness", type=int, default=8, help="Vina exhaustiveness for --tools redock")
    ap.add_argument("--pdbq-dir", help="directory holding isolationforest_ads.joblib and test_set_1_scored.csv")
    ap.add_argument("--structselect-cli", help="path to the structure-selection CLI script")
    sys.exit(run(ap.parse_args()))


if __name__ == "__main__":
    main()

# Metrics, reference sources and verdict thresholds

Every tool is measured against a reference that is **independent of the code under test**.
Where a tool wraps a library (RDKit, Biopython, Primer3), the reference is either a different
library, a re-implementation written from the original publication, or experimental data — never
the same call the tool makes. Thresholds live in `bench/thresholds.json` and can be edited; the
runner re-reads them, so a changed threshold only changes the verdict, never the measurement.

## Confidence intervals

Every primary metric carries a 95 % interval, and every interval records the method that
produced it (`ci95_method`).

**Preferred: percentile bootstrap over the benchmark's own sampling unit** (4000 resamples,
seeded). A benchmark declares its unit by returning a `bootstrap` block, and the runner
resamples whole units rather than individual checks:

| Benchmark | Sampling unit | Statistic |
|---|---|---|
| `esol_estimator` | molecules | RMSE |
| `functional_groups` | molecules | pooled micro-F1 |
| `chemical_similarity`, `similarity` | query molecules | mean AUC |
| `primer_design`, `primer` | templates (clustered) | pooled pass rate |
| `sequence_alignment`, `align` | sequence pairs | mean Q |
| `crispr_guide` | guides | Spearman ρ |

Clustering matters. The primer QC rate pools several pairs per template; treating pairs as
independent gives roughly ±0.04, while resampling templates gives [0.500, 0.675] for the
corrected screen. The wider interval is the honest one.

**Fallback, where a benchmark exposes no unit:** Wilson score for proportions,
Hanley–McNeil for AUC, Fisher *z* for rank correlation, computed over the reported `n`.
These assume independent trials and are labelled as such, so a reader can see which
intervals rest on that assumption.

Intervals appear in the result JSON as `ci95` and `ci95_method`, in the CSV as
`ci95_low` / `ci95_high`, and in the paper's Appendix A. Changing a threshold never changes
an interval.

## Verdict rule

`GOOD` / `MEDIUM` / `LOW` compare the primary metric with two cut-offs. For `direction: higher`,
GOOD means `value >= good`; for `direction: lower` (only `esol_rmse_logS`), GOOD means `value <= good`.
A benchmark that could not run reports its reason instead (`NETWORK_REQUIRED`,
`DEPENDENCY_MISSING`, `DATA_MISSING`, `ERROR`, `CRASH`) and is never silently scored.

## Why these cut-offs

| Metric | GOOD | MEDIUM | Basis for the cut-off |
|---|---|---|---|
| `validity_pass_rate` | 0.99 | 0.95 | A deterministic calculator reproducing a closed-form reference has no legitimate reason to disagree; anything below 0.95 means a systematic defect, not noise. |
| `robustness_rate` | 0.99 | 0.90 | A public web endpoint must never fail uncontrolled. The only acceptable outcomes are a result or a sanitised rejection. |
| `group_micro_f1` | 0.90 | 0.75 | Functional-group perception on unambiguous textbook cases; 0.90 leaves room for defensible convention differences (is a carbamate an amide?) but not for missing group types. |
| `motif_f1_vs_prosite` | 0.95 | 0.85 | Regular-expression motif matching is exact work; a deviation means the pattern does not implement the cited definition. |
| `duplicate_pair_f1` | 0.95 | 0.85 | Salt/charge stripping to a common parent is the tool's stated purpose; missing a sodium salt defeats it. |
| `alignment_accuracy_q` | 0.90 | 0.75 | Q (fraction of true residue pairs recovered) averaged over 10–60 % divergence. Published pairwise aligners sit near 0.95 in this range; below 0.75 the alignment is misleading. |
| `balanced_accuracy` | 0.85 | 0.70 | Structural-alert catalogues are deliberately imperfect; the balance between flagging known PAINS chemotypes and not flagging approved drugs is the useful measure. |
| `charge_state_accuracy` | 0.90 | 0.75 | Dominant protonation state at pH 7.4 drives docking and PDBQT charges; a wrong net charge changes the pose. |
| `primer_qc_pass_rate` | 0.90 | 0.75 | A primer pair that fails basic Tm, hairpin, dimer or 3′-uniqueness QC wastes bench time; most returned pairs should be orderable. |
| `esol_rmse_logS` (lower) | 1.00 | 1.30 | Delaney's original ESOL reports RMSE ≈ 0.95–1.00 logS on this set; a re-implementation should land in that band. |
| `crispr_spearman` | 0.40 | 0.20 | Published on-target models reach ρ ≈ 0.4–0.7 on Doench 2016 data. Below 0.20 a ranking carries almost no information about activity. |
| `pocket_top1_success_dcc4` | 0.60 | 0.40 | fpocket's own published top-1 DCC ≤ 4 Å success on holo structures is ≈ 0.6–0.7. |
| `interaction_f1_vs_plip` | 0.75 | 0.55 | Interaction engines legitimately disagree (hydrogens, cut-offs); 0.75 agreement with PLIP indicates the same binding-site picture. |
| `target_top10_hit_rate` | 0.70 | 0.50 | The query drug is itself in ChEMBL, so retrieving its known target in the top 10 is the minimum bar for evidence retrieval. |
| `class_retrieval_auc` | 0.80 | 0.70 | Leave-one-out retrieval of same-class drugs; a usable similarity search should rank congeners above unrelated drugs. |
| `maxmin_ratio` | 0.95 | 0.85 | Ratio of the tool's achieved min-pairwise distance to RDKit `MaxMinPicker` on identical fingerprints; 1.0 = identical diversity. |

## Reference source per tool

### Independent-reference calculators (exact agreement expected)

| Tool | Reference | What is checked |
|---|---|---|
| `formula_mass` | IUPAC 2013 atomic weights and NIST monoisotopic masses summed over 57 literature molecular formulas | formula string, monoisotopic mass (ppm), average mass, per-element counts |
| `druglikeness` | same formula-derived masses; Ro5/Veber logic re-derived from Lipinski 1997 / Veber 2002 | MW, heavy-atom count, rule arithmetic |
| `admet` | as above plus Egan 2000, Ghose 1999, Muegge 2001 thresholds | 9 checks per molecule incl. QED/SA/NDI range validity |
| `ligand_efficiency` | LE = 2.303·R·T·pKi/HA (Hopkins 2004), LipE = pKi − cLogP (Leeson 2007); HA from formula | LE, LipE, heavy atoms, pKi input validation |
| `scaffold_analysis` | independent graph-pruning Bemis–Murcko (ring + linker atoms + exocyclic double-bonded atoms) | canonical scaffold SMILES per molecule |
| `chemspace` | scikit-learn `StandardScaler` + `PCA` on the tool's own exported descriptor matrix | PC1/PC2 variance, per-molecule scores (|r| > 0.999), scaffold count |
| `chemical_diversity` | RDKit `MaxMinPicker` on identical Morgan2/1024 fingerprints; 500 random subsets as a floor | achieved min-pairwise distance, reported pairwise statistics |
| `protein_properties`, `protparam` | `pyteomics` average masses; `peptides` instability index and Kyte–Doolittle GRAVY; Ikai 1980 aliphatic index; Pace 1995 ε280; ExPASy ProtParam values for ubiquitin and hen lysozyme | MW, pI, instability, GRAVY, aliphatic index, extinction coefficients, aromaticity |
| `peptide_profile` | `pyteomics` mass, `peptides` GRAVY, liability rules re-derived from the tool's own stated definitions | mass, GRAVY, all four liability flags |
| `variant_compare` | BLOSUM62 (Henikoff 1992) table lookup on random proteins with known substitutions | substitution list, positions, scores, identity %, unequal-length rejection |
| `restriction_map` | REBASE recognition sites and top-strand cut offsets for 20 enzymes, including type IIS BsaI in both orientations, with planted sites | cut positions (1-based) and counts per enzyme |
| `dna_quality` | independent recomputation (GC excluding N, homopolymer run, Shannon entropy) on sequences with planted N blocks and homopolymers | all five reported statistics |
| `orf_finder` | independent six-frame ORF enumeration plus planted genes of 60–200 codons | total count, returned subset, longest ORF, planted-gene recall |

### Predictive and heuristic tools (measured against data or a published model)

| Tool | Reference | Primary metric |
|---|---|---|
| `esol_estimator` | Delaney 2004 measured aqueous solubility (MoleculeNet `delaney-processed`, n = 1128) | RMSE in logS; also R², MAE, and RMSE of the dataset's own published ESOL column |
| `crispr_guide` | Doench et al. 2016 FC+RES sgRNA activity ranks (n = 5310, Azimuth repository); Rule Set 2 predictions in the same file as an upper reference | Spearman ρ of the tool's implicit ranking vs measured activity; AUC for the top-20 % active class |
| `structural_alerts` | 13 textbook PAINS chemotypes (Baell & Holloway 2010 families) vs 57 approved drugs | balanced accuracy (recall on PAINS exemplars, specificity on drugs) |
| `chemical_similarity`, `similarity` | leave-one-out retrieval of same-pharmacological-class drugs (11 classes, 57 drugs) | mean ROC-AUC; also EF5 %, BEDROC20, P@5, and Butina-vs-class ARI |
| `functional_groups` | 35 molecules with hand-curated textbook labels over 20 group types | micro-F1 (plus per-group F1) |
| `motif_scanner` | loop-based matcher of PROSITE PS00001 (N-{P}-[ST]-{P}), PS00006, PS00005 and the tool's own YxxΦ / RxR definitions | F1 at (motif, position) level |
| `compound_cleanup` | 57 drugs × generated salt / charge / random-SMILES variants (same parent) with stereo-inverted negative controls | pairwise duplicate-detection F1 |
| `ligprep` | 34 drugs and probes whose dominant net charge at pH 7.4 follows from literature pKa values | net-charge accuracy; also embedding success, stereo/tautomer retention, PDBQT yield |
| `sequence_alignment`, `align` | simulated evolution with a **known true alignment**: BLOSUM62-weighted substitutions at 10–60 % divergence, indel rate = divergence/10 | Q = fraction of true residue pairs recovered, per divergence level |
| `primer_design`, `primer` | Primer3 thermodynamics (`calc_tm`, `calc_hairpin`, `calc_homodimer`, `calc_heterodimer`, Primer3's own 47 °C limits) plus 3′-decamer uniqueness on **both** strands; templates at GC 30–70 % | fraction of returned pairs passing all QC criteria |
| `pocket` | DCC criterion (Chen et al. 2011): distance from the predicted pocket centre to the crystallographic ligand centroid on 10 holo structures, **ligand removed before prediction** | top-1 success at DCC ≤ 4 Å |
| `interact` | PLIP 2.x (Adasme et al. 2021) on the same complexes, matched at (interaction type, residue) level | F1; also binding-site residue Jaccard |
| `target` | known primary target of 12 approved drugs (ChEMBL target names) | top-10 hit rate; also top-1 and median rank |

### Cross-cutting

| Benchmark | Protocol | Metric |
|---|---|---|
| `robustness` | 22 hostile or malformed inputs per tool (injection strings, control and bidirectional Unicode characters, null bytes, numeric overflow, 5000-line and 5000-character payloads, deeply nested SMILES, path traversal, XML entity expansion) × 27 offline tools = 594 calls | fraction producing a result or a *controlled* rejection; an uncaught exception counts as a failure |
| `determinism` | each tool called twice with identical input, then once with whitespace/CRLF-padded equivalent input | fraction of byte-identical outcomes |
| `tier_parity` | each of the 20 tiered tools run at FREE and at PRO on one input sized within the FREE cap, so the tier is the only difference | fraction of tools whose free-tier result is identical, or the same values with fewer rows |

`tier_parity` classifies each tool as IDENTICAL, PREFIX (same values, fewer rows
returned) or NARROWER (the free tier evaluates a smaller catalogue, so the science
differs). Two tools are NARROWER by design and this is not a defect: the structural
alert screen adds the Brenk catalogue only at the paid tier, and the restriction
mapper covers 8 enzymes at the free tier against 20 at the paid tier. The benchmark
is scored MEDIUM at 0.900 rather than GOOD for exactly this reason.

## Docking and structure-service benchmarks (tier B)

These are implemented and released but need resources beyond a plain Python install. Each
reports `DEPENDENCY_MISSING` or `NETWORK_REQUIRED` with the exact requirement rather than
being silently skipped.

| Benchmark | Reference | Primary metric | Needs |
|---|---|---|---|
| `redock` | co-crystallised poses of a published diverse set; symmetry-corrected heavy-atom RMSD of the top-scored pose, box centred on the crystallographic ligand | fraction with RMSD ≤ 2 Å | AutoDock Vina, Meeko, obabel, RCSB access |
| `pocket_p2rank` | DCC criterion (Chen 2011), ligand removed before prediction | top-1 DCC ≤ 4 Å success | P2Rank, RCSB access |
| `dock_protein_protein` | bound-form re-docking of reference complexes, scored with DockQ (Basu & Wallner 2016) and assigned a CAPRI class | acceptable-or-better rate | deployer-supplied rigid-body engine (`NVX_PP_DOCK_BIN`) |
| `dock_peptide` | same protocol on short-partner complexes, **reported separately and never pooled with protein–protein** | acceptable-or-better rate | as above |
| `structselect` | two identical runs per accession must give identical ranked output | determinism rate | UniProt/RCSB access, the CLI in its own venv |
| `pdbquantifier` | the model's own shipped reference scores recomputed from the packaged pipeline; feature completeness measured on the same rows | check pass rate | scikit-learn pinned to the artifact's version |

The DockQ implementation is in `bench/tasks/dock_tasks.py` and is independently usable. It
was verified to return 1.0 for a structure scored against itself and to fall monotonically
through the CAPRI classes (high → medium → acceptable → incorrect) as one partner is
displaced by 0.5–12 Å.

`pdbquantifier` reports two things beyond the pass rate: how many of the 25 model features
were entirely absent from the scored rows, and whether the artifact loads at all under the
installed scikit-learn. Both proved informative — see FINDINGS_TR.md.

## Known self-consistency caveats

Two measurements are **not** fully independent and are reported as such:

1. `primer` (Primer3 engine) is QC-checked with Primer3's own thermodynamic functions. Its Tm, hairpin
   and dimer results are therefore partly self-consistent; only the 3′-uniqueness and coordinate
   checks are independent. The same QC applied to `primer_design`, which uses Biopython Tm, *is*
   independent.
2. `admet`'s NDI (Novexus Developability Index) is a proprietary composite with no published
   external validation. Only its range and its component arithmetic are verified. The
   drug-vs-industrial-chemical AUC in the secondary metrics is a weak proxy, not a validation.

## Reproducibility

All randomised tasks derive from a single `--seed` (default 2026), so a rerun on the same
package and library versions reproduces every number. The exact library versions, binaries and
dataset SHA-256 digests are recorded in the `environment` block of each result JSON.

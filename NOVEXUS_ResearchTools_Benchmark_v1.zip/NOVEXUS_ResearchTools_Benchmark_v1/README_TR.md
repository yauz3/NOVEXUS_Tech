# NOVEXUS Tech V0 — Benchmark Paketi v1.1

Platform modüllerinin bilimsel doğruluğunu bağımsız referanslara karşı ölçen test paketi.
30 araştırma aracı bu ortamda ölçülür; docking ve yapı servisleri için benchmark'lar
yazılıdır ve senin makinende koşar.
Her araç iki sürümde ölçülür: **original** (v0.26 kaynak kodu, birebir) ve **fixed** (bu çalışmada
yapılan düzeltmeler). Böylece her düzeltmenin etkisi sayısal olarak görünür.

## Hızlı başlangıç

```bash
unzip NOVEXUS_ResearchTools_Benchmark_v1.zip
cd NOVEXUS_ResearchTools_Benchmark_v1

# 1) Gerekli paketler
pip install rdkit biopython numpy scipy scikit-learn primer3-py dimorphite_dl meeko
# Bağımsız referans kütüphaneleri (olmadan ilgili testler atlanır)
pip install peptides pyteomics plip openbabel-wheel
# Harici programlar (opsiyonel; yoksa pocket ve MSA testleri atlanır)
sudo apt install fpocket mafft

# 2) Ortam kontrolü — neyin eksik olduğunu söyler
python3 run_benchmark.py --check

# 3) Açık veri setlerini indir (ESOL + Doench CRISPR, ~600 KB, SHA-256 kaydedilir)
python3 run_benchmark.py --fetch

# 4) Tam koşu (iki sürüm, 32 test, yaklaşık 2–4 dakika)
python3 run_benchmark.py
```

Her birincil metrik 95 % güven aralığıyla birlikte raporlanır (oranlarda Wilson, AUC'de
Hanley–McNeil, korelasyonda Fisher z). JSON'da `ci95`, CSV'de `ci95_low`/`ci95_high`.

Sonuçlar `results/` altına üç dosya olarak yazılır:

- `report_<zaman>.html` — açılıp okunacak rapor (karanlık mod uyumlu, her test için açılır detay)
- `benchmark_<zaman>.csv` — makale tablosu için düz veri
- `benchmark_<zaman>.json` — tüm ikincil metrikler, hata listeleri, ortam bilgisi

## Diğer çalıştırma biçimleri

```bash
python3 run_benchmark.py --quick                      # küçük örneklem, ~1 dakika
python3 run_benchmark.py --offline                    # ağ gerektiren 3 aracı atla
python3 run_benchmark.py --variant fixed              # tek sürüm
python3 run_benchmark.py --tools esol_estimator,primer_design
python3 run_benchmark.py --seed 7                     # başka tohum (tekrarlanabilirlik testi)
```

## Docking ve yapı servisleri (kendi makinende)

Bu dördü ek program veya ağ erişimi ister; bu ortamda koşmadılar.

```bash
# Yapı kalite skorlaması — çevrimdışı çalışır, ama model scikit-learn 1.6.1'e kilitli
python3 -m venv .venv-pdbq && .venv-pdbq/bin/pip install scikit-learn==1.6.1 pandas joblib numpy
.venv-pdbq/bin/python run_benchmark.py --tools pdbquantifier --pdbq-dir data/pdbquantifier_ref

# Redocking başarısı (Astex) — AutoDock Vina + Meeko + obabel + RCSB erişimi gerekir
python3 run_benchmark.py --tools redock --exhaustiveness 8

# Cep bulma (P2Rank) — prank kurulu olmalı
python3 run_benchmark.py --tools pocket_p2rank

# Yapı seçimi — kendi venv'inde çalışan CLI'ın yolunu ver
python3 run_benchmark.py --tools structselect --structselect-cli /yol/full_pdbminer_v09.py
```

Eksik program varsa test `DEPENDENCY_MISSING` yazar ve neyin kurulması gerektiğini söyler;
sessizce atlamaz.

## Verdict nasıl okunur

| Verdict | Anlamı |
|---|---|
| `GOOD` | Eşiğin üstünde; araç sitede kalabilir |
| `MEDIUM` | Kullanılabilir ama iyileştirme gerekli |
| `LOW` | Geliştirme veya kaldırma kararı gerekir |
| `NETWORK_REQUIRED` | RCSB / UniProt / ChEMBL erişimi yok |
| `DEPENDENCY_MISSING` | fpocket, PLIP veya mafft kurulu değil |
| `DATA_MISSING` | `--fetch` çalıştırılmamış |

Eşikler `bench/thresholds.json` içindedir ve serbestçe değiştirilebilir; runner dosyayı her
koşuda yeniden okur. Eşiği değiştirmek yalnızca verdict'i değiştirir, ölçümü değiştirmez.
Her eşiğin literatür gerekçesi `METRICS.md` içinde tablo halindedir.

## Paket içeriği

```
run_benchmark.py              Çalıştırıcı, HTML/CSV/JSON rapor üreteci
METRICS.md                    Her metrik, referans kaynağı ve eşik gerekçesi
FINDINGS_TR.md                Bulgular ve öneriler (Türkçe özet)
bench/
  engines.py                  30 aracın iki sürüme tek arayüzden çağrılması
  metrics.py                  RMSE, R², AUC, EF, BEDROC, F1, Spearman, verdict
  thresholds.json             Eşikler (düzenlenebilir)
  curated/
    drugs.tsv                 57 onaylı ilaç, 11 farmakolojik sınıf, formülleriyle doğrulanmış
    protonation_ph74.tsv      34 molekülün pH 7.4'teki baskın yükü, literatür pKa gerekçesiyle
    functional_groups.json    35 molekül, 20 fonksiyonel grup, elle etiketlenmiş
    pains_exemplars.tsv       13 PAINS kemotipi
  tasks/
    chem_tasks.py             14 kimyasal araç
    seq_tasks.py              13 dizi aracı
    struct_tasks.py           3 yapı/veritabanı aracı + robustness + determinism
engines/
  original/                   v0.26 kaynak kodu, SHA-256 ile doğrulanmış kopya
  fixed/                      düzeltilmiş sürüm, her yama kod içinde yorumlanmış
  ORIGINAL_SHA256.txt         orijinal dosyaların özetleri
data/                         indirilen açık veri setleri + DATA_MANIFEST.json
results/                      koşu çıktıları
```

`engines/original/` içindeki dosyalar v0.26 paketindeki kaynakların birebir kopyasıdır:

```bash
sha256sum -c engines/ORIGINAL_SHA256.txt   # engines/original/ içinden çalıştır
```

## Tekrarlanabilirlik

Rastgelelik içeren tüm testler tek bir tohumdan (`--seed`, varsayılan 2026) türetilir. Aynı
kütüphane sürümleriyle tekrar koşmak aynı sayıları verir. Kütüphane sürümleri, harici programlar
ve veri seti SHA-256 özetleri her sonuç JSON'unun `environment` bloğuna yazılır.

## Veri setleri ve lisanslar

| Dosya | Kaynak | Lisans |
|---|---|---|
| `delaney-processed.csv` | Delaney 2004, MoleculeNet / DeepChem deposu | MIT (depo) |
| `FC_plus_RES_withPredictions.csv` | Doench ve ark. 2016, Microsoft Azimuth deposu | BSD-3 (depo) |

Küratörlü setler (`bench/curated/`) bu çalışmada literatürden derlenmiştir ve pakete dahildir.
PDB yapıları ve ChEMBL kayıtları koşu anında resmî API'lerden çekilir, pakete gömülmez.
